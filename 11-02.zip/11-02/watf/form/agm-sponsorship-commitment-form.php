<?php

/**
 * AGM Sponsorship Commitment Form shortcode.
 *
 * Mirrors the provided layout using Bootstrap grid classes and exposes
 * a shortcode so the form can be dropped onto any page or post.
 *
 * Usage: [agm_sponsorship_form]
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!function_exists('watf_register_agm_sponsorship_form_shortcode')) {
	/**
	 * Register the shortcode at init.
	 */
	function watf_register_agm_sponsorship_form_shortcode()
	{
		add_shortcode('agm_sponsorship_form', 'watf_render_agm_sponsorship_form_shortcode');
	}
	add_action('init', 'watf_register_agm_sponsorship_form_shortcode');
}

if (!function_exists('watf_render_agm_sponsorship_form_shortcode')) {
	/**
	 * Render the AGM Sponsorship Commitment Form.
	 *
	 * @param array<string, mixed> $atts Shortcode attributes.
	 * @return string
	 */
	function watf_render_agm_sponsorship_form_shortcode($atts = [])
	{
		$atts = shortcode_atts(
			[
				'online_payment_url' => '',
				'check_payable_to'   => 'The Washington Airports Task Force, 44701 Propeller Court, Suite 100, Dulles, VA 20166.',
				'email_event'        => 'Lisa@washingtonairports.com',
				'email_sponsorship'  => 'Mark@washingtonairports.com',
			],
			$atts,
			'agm_sponsorship_form'
		);

		$sponsor_levels = apply_filters(
			'watf_agm_sponsorship_levels',
			[
				// ''          => __('Select', 'watf'),
				''          => __('Select', 'watf'),
				'premier'   => __('Premier Sponsor', 'watf'),
				'platinum'  => __('Platinum Sponsor', 'watf'),
				'gold'      => __('Gold Sponsor', 'watf'),
				'silver'    => __('Silver Sponsor', 'watf'),
				'bronze'    => __('Bronze Sponsor', 'watf'),
			]
		);

		$states = apply_filters(
			'watf_us_states_options',
			[
				''   => __('Select', 'watf'),
				'AL' => __('Alabama', 'watf'),
				'AK' => __('Alaska', 'watf'),
				'AZ' => __('Arizona', 'watf'),
				'AR' => __('Arkansas', 'watf'),
				'CA' => __('California', 'watf'),
				'CO' => __('Colorado', 'watf'),
				'CT' => __('Connecticut', 'watf'),
				'DE' => __('Delaware', 'watf'),
				'DC' => __('District of Columbia', 'watf'),
				'FL' => __('Florida', 'watf'),
				'GA' => __('Georgia', 'watf'),
				'HI' => __('Hawaii', 'watf'),
				'ID' => __('Idaho', 'watf'),
				'IL' => __('Illinois', 'watf'),
				'IN' => __('Indiana', 'watf'),
				'IA' => __('Iowa', 'watf'),
				'KS' => __('Kansas', 'watf'),
				'KY' => __('Kentucky', 'watf'),
				'LA' => __('Louisiana', 'watf'),
				'ME' => __('Maine', 'watf'),
				'MD' => __('Maryland', 'watf'),
				'MA' => __('Massachusetts', 'watf'),
				'MI' => __('Michigan', 'watf'),
				'MN' => __('Minnesota', 'watf'),
				'MS' => __('Mississippi', 'watf'),
				'MO' => __('Missouri', 'watf'),
				'MT' => __('Montana', 'watf'),
				'NE' => __('Nebraska', 'watf'),
				'NV' => __('Nevada', 'watf'),
				'NH' => __('New Hampshire', 'watf'),
				'NJ' => __('New Jersey', 'watf'),
				'NM' => __('New Mexico', 'watf'),
				'NY' => __('New York', 'watf'),
				'NC' => __('North Carolina', 'watf'),
				'ND' => __('North Dakota', 'watf'),
				'OH' => __('Ohio', 'watf'),
				'OK' => __('Oklahoma', 'watf'),
				'OR' => __('Oregon', 'watf'),
				'PA' => __('Pennsylvania', 'watf'),
				'RI' => __('Rhode Island', 'watf'),
				'SC' => __('South Carolina', 'watf'),
				'SD' => __('South Dakota', 'watf'),
				'TN' => __('Tennessee', 'watf'),
				'TX' => __('Texas', 'watf'),
				'UT' => __('Utah', 'watf'),
				'VT' => __('Vermont', 'watf'),
				'VA' => __('Virginia', 'watf'),
				'WA' => __('Washington', 'watf'),
				'WV' => __('West Virginia', 'watf'),
				'WI' => __('Wisconsin', 'watf'),
				'WY' => __('Wyoming', 'watf'),
			]
		);

		$online_payment_url = esc_url($atts['online_payment_url']);
		$check_payable_to   = esc_html($atts['check_payable_to']);
		$email_event        = sanitize_email($atts['email_event']);
		$email_sponsorship  = sanitize_email($atts['email_sponsorship']);

		$form_status = '';
		if (isset($_GET['agm_sponsorship_status'])) {
			$form_status = sanitize_key(wp_unslash($_GET['agm_sponsorship_status']));
		}

		$promo_code         = '';
		$attendee_form_url  = '';
		if (isset($_GET['promo_code'])) {
			$promo_code = sanitize_text_field(wp_unslash($_GET['promo_code']));
		}
		if (isset($_GET['attendee_form_url'])) {
			$attendee_form_url = esc_url_raw(wp_unslash($_GET['attendee_form_url']));
		}

		$notice_html = '';
		if ($form_status === 'success') {
			$success_message = esc_html__('Thank you for your commitment! A WATF representative will reach out shortly.', 'watf');

			$extra_details = '';
			if ($promo_code !== '') {
				$extra_details .= '<div class="fw-semibold mb-1">' . esc_html__('Promo Code:', 'watf') . ' ' . esc_html($promo_code) . '</div>';
			}
			if ($attendee_form_url !== '') {
				$extra_details .= '<div class="fw-semibold">' . esc_html__('Sponsorship Attendee Registration Link:', 'watf') . ' <a href="' . esc_url($attendee_form_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html($attendee_form_url) . '</a></div>';
			}

			$notice_html = sprintf(
				'<div class="alert alert-success" role="alert">%s%s</div>',
				$success_message,
				$extra_details !== '' ? '<div class="mt-2">' . $extra_details . '</div>' : ''
			);
		} elseif ($form_status === 'error') {
			$notice_html = sprintf(
				'<div class="alert alert-danger" role="alert">%s</div>',
				esc_html__('We were unable to save your sponsorship. Please review the form and try again.', 'watf')
			);
		}

		ob_start();
?>
		<div class="watf-agm-sponsorship-form container px-3 pb-5">
			<?php if ($notice_html !== '') : ?>
				<div class="row mb-3">
					<div class="col-12">
						<?php echo $notice_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
						?>
					</div>
				</div>
			<?php endif; ?>

			<p class="para1 text-center mb-2">To sponsor this year’s WATF AGM, select your Sponsor Level in the below form.</p>
			<h3 class="mb-1 text-center form-heading"><?php echo esc_html__('Annual General Meeting Sponsorship Commitment', 'watf'); ?></h3>
			<p class="pay_online text-dark py-2"><span>TO PAY BY CHECK</span>, make payable to: The Washington Airports Task Force, 44701 Propeller Court, Suite 100, Dulles, VA 20166. <span>TO PAY ONLINE</span> , visit our <a class="link" href="https://tinyurl.com/y5mjcxy4">AGM Sponsorship Online Payment Form.</a></p>
			<p class="text-muted mb-4 text-start req-field"><span class="text-danger">*</span> <?php echo esc_html__('Indicates required fields.', 'watf'); ?></p>

			<div class="row g-4 align-items-stretch">
				<div class="col-12 col-lg-8">
					<?php if ($online_payment_url) : ?>
						<p class="text-danger mb-2 fw-semibold">
							<?php
							$payment_text = sprintf(
								/* translators: %s: payment page link */
								__('To pay online, please visit our <a href="%s" target="_blank" rel="noopener noreferrer">AGM Sponsorship Online Payment Form</a>.', 'watf'),
								esc_url($online_payment_url)
							);
							echo wp_kses($payment_text, ['a' => ['href' => [], 'target' => [], 'rel' => []]]);
							?>
						</p>
					<?php endif; ?>					
				</div>
				
			</div>

			<form id="watf-agm-sponsorship-form" class="agm-registration-form needs-validation" method="post">
				<?php wp_nonce_field('watf_submit_agm_sponsorship', 'watf_agm_sponsorship_nonce'); ?>

				<div class="row g-4">
					<div class="col-12 col-md-7 justify-content-start">
						<p class="fw-bold para2">
							<?php echo esc_html__('YES, we would like to sponsor this year\'s WATF AGM.', 'watf'); ?>
						</p>
					</div>
					<div class="col-12 col-md-4">
						<label for="watf-sponsor-level" class="form-label fw-semibold">
							<?php echo wp_kses_post(__('Sponsor Level<span class="text-danger">*</span>', 'watf')); ?>
						</label>
						<select id="watf-sponsor-level" class="form-select" name="sponsor_level" required>
							<?php foreach ($sponsor_levels as $value => $label) : ?>
								<option value="<?php echo esc_attr($value); ?>"><?php echo esc_html($label); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="col-12 col-md-2">
						<label for="watf-prefix" class="form-label"><?php echo esc_html__('Prefix', 'watf'); ?></label>
						<input type="text" class="form-control" id="watf-prefix" name="prefix" maxlength="20">
					</div>

				<div class="col-12 col-md-5">
					<label for="watf-first-name" class="form-label"><?php echo esc_html__('First Name', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="watf-first-name" name="first_name" required>
				</div>

				<div class="col-12 col-md-5">
					<label for="watf-last-name" class="form-label"><?php echo esc_html__('Last Name', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="watf-last-name" name="last_name" required>
				</div>

				<div class="col-12 col-md-6">
					<label for="watf-title" class="form-label"><?php echo esc_html__('Title', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="watf-title" name="title" required>
				</div>

				<div class="col-12 col-md-6">
					<label for="watf-organization" class="form-label"><?php echo esc_html__('Organization', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="watf-organization" name="organization" required>
				</div>

				<div class="col-12 col-md-6">
					<label for="watf-sponsor-name" class="form-label"><?php echo esc_html__('Sponsor Name', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="watf-sponsor-name" name="sponsor_name" required>
				</div>

				<div class="col-12 col-md-6">
					<label for="watf-street" class="form-label"><?php echo esc_html__('Street', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="watf-street" name="street" required>
				</div>

				<div class="col-12 col-md-6">
					<label for="watf-city" class="form-label"><?php echo esc_html__('City', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="watf-city" name="city" required>
				</div>

				<div class="col-12 col-md-3">
					<label for="watf-state" class="form-label"><?php echo esc_html__('State', 'watf'); ?><span class="text-danger">*</span></label>
					<select id="watf-state" class="form-select" name="state" required>
						<?php foreach ($states as $value => $label) : ?>
							<option value="<?php echo esc_attr($value); ?>"><?php echo esc_html($label); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="col-12 col-md-3">
					<label for="watf-zip" class="form-label"><?php echo esc_html__('Zip', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="watf-zip" name="zip" required>
				</div>

				<div class="col-12 col-md-6">
					<label for="watf-phone" class="form-label"><?php echo esc_html__('Phone', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="tel" class="form-control" id="watf-phone" name="phone" required>
				</div>

				<div class="col-12 col-md-6">
					<label for="watf-email" class="form-label"><?php echo esc_html__('Email', 'watf'); ?><span class="text-danger">*</span></label>
					<input type="email" class="form-control" id="watf-email" name="email" required>
				</div>

				<div class="col-12 d-flex flex-column">
					<label for="watf-additional-info" class="form-label"><?php echo esc_html__('Additional Information', 'watf'); ?></label>
					<textarea class="form-control" id="watf-additional-info" name="additional_information" rows="4"></textarea>
				</div>

				<div class="col-12 col-md-6 justify-content-start radio">
					<label class="form-label d-block mb-2"><?php echo esc_html__('Would you like an invoice?', 'watf'); ?><span class="text-danger">*</span></label>
					<div class="form-check form-check-inline">
						<input class="form-check-input" type="radio" name="invoice_requested" id="watf-invoice-yes" value="yes" required>
						<label class="form-check-label" for="watf-invoice-yes"><?php echo esc_html__('Yes', 'watf'); ?></label>
					</div>
					<div class="form-check form-check-inline">
						<input class="form-check-input" type="radio" name="invoice_requested" id="watf-invoice-no" value="no" required>
						<label class="form-check-label" for="watf-invoice-no"><?php echo esc_html__('No', 'watf'); ?></label>
					</div>
				</div>

				<div class="col-12 col-md-6 justify-content-start radio">
					<label class="form-label d-block mb-2"><?php echo esc_html__('Paying by Check?', 'watf'); ?><span class="text-danger">*</span></label>
					<div class="form-check form-check-inline">
						<input class="form-check-input" type="radio" name="paying_by_check" id="watf-check-yes" value="yes" required>
						<label class="form-check-label" for="watf-check-yes"><?php echo esc_html__('Yes', 'watf'); ?></label>
					</div>
					<div class="form-check form-check-inline">
						<input class="form-check-input" type="radio" name="paying_by_check" id="watf-check-no" value="no" required>
						<label class="form-check-label" for="watf-check-no"><?php echo esc_html__('No', 'watf'); ?></label>
					</div>
				</div>

				<div class="col-12 text-center ">
					<p class="para1">Upon clicking the “SUBMIT” button below to confirm your sponsorship commitment, a registration promo code will follow via email. Using this code, you will be prompted to enter all of your AGM meeting attendees.</p>
				</div>


					<div class="col-12 d-flex flex-column">
					<p class="fw-bold mb-1 text-center text-danger"><?php echo esc_html__('QUESTIONS?', 'watf'); ?></p>
					<p class="mb-0 text-center text-dark">
						<?php
						printf(
							'%s <a class="link" href="mailto:%s">%s</a>.',
							esc_html__('For event sponsorships, contact', 'watf'),
							esc_attr($email_sponsorship),
							esc_html($email_sponsorship)
						);
						?>
					</p>
					<p class="mb-3 text-center text-dark">
						<?php
						printf(
							'%s <a class="link" href="mailto:%s">%s</a>.',
							esc_html__('For event details, contact', 'watf'),
							esc_attr($email_event),
							esc_html($email_event)
						);
						?>
					</p>
					</div>

					<div class="col-12 text-center">
					<button type="submit" class="btn btn-primary px-5 button1">
						<?php echo esc_html__('Submit', 'watf'); ?>
					</button>
				</div>
				</div>
			</form>
		</div>
<?php

		return ob_get_clean();
	}
}

if (!function_exists('watf_handle_agm_sponsorship_form_submission')) {
	/**
	 * Handle AGM sponsorship form submissions.
	 */
	function watf_handle_agm_sponsorship_form_submission()
	{
		if ($_SERVER['REQUEST_METHOD'] !== 'POST') { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated
			return;
		}

		if (!isset($_POST['watf_agm_sponsorship_nonce'])) {
			return;
		}

		$redirect = wp_get_referer();
		if (!$redirect) {
			$redirect = home_url('/');
		}
		$redirect = remove_query_arg('agm_sponsorship_status', $redirect);

		if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['watf_agm_sponsorship_nonce'])), 'watf_submit_agm_sponsorship')) {
			wp_safe_redirect(add_query_arg('agm_sponsorship_status', 'error', $redirect));
			exit;
		}

		$raw = wp_unslash($_POST);

		$data = [
			'sponsor_level'          => sanitize_text_field($raw['sponsor_level'] ?? ''),
			'prefix'                 => sanitize_text_field($raw['prefix'] ?? ''),
			'first_name'             => sanitize_text_field($raw['first_name'] ?? ''),
			'last_name'              => sanitize_text_field($raw['last_name'] ?? ''),
			'title'                  => sanitize_text_field($raw['title'] ?? ''),
			'organization'           => sanitize_text_field($raw['organization'] ?? ''),
			'sponsor_name'           => sanitize_text_field($raw['sponsor_name'] ?? ''),
			'street'                 => sanitize_text_field($raw['street'] ?? ''),
			'city'                   => sanitize_text_field($raw['city'] ?? ''),
			'state'                  => sanitize_text_field($raw['state'] ?? ''),
			'zip'                    => sanitize_text_field($raw['zip'] ?? ''),
			'phone'                  => sanitize_text_field($raw['phone'] ?? ''),
			'email'                  => sanitize_email($raw['email'] ?? ''),
			'additional_information' => sanitize_textarea_field($raw['additional_information'] ?? ''),
		];

		$data['invoice_requested'] = in_array(($raw['invoice_requested'] ?? ''), ['yes', 'no'], true) ? $raw['invoice_requested'] : '';
		$data['paying_by_check']   = in_array(($raw['paying_by_check'] ?? ''), ['yes', 'no'], true) ? $raw['paying_by_check'] : '';

		$required_fields = [
			'sponsor_level',
			'first_name',
			'last_name',
			'title',
			'organization',
			'sponsor_name',
			'street',
			'city',
			'state',
			'zip',
			'phone',
			'email',
			'invoice_requested',
			'paying_by_check',
		];

		$has_error = false;
		foreach ($required_fields as $field) {
			if ($data[$field] === '') {
				$has_error = true;
				break;
			}
		}

		if (!$has_error && $data['email'] !== '' && !is_email($data['email'])) {
			$has_error = true;
		}

		if ($has_error) {
			wp_safe_redirect(add_query_arg('agm_sponsorship_status', 'error', $redirect));
			exit;
		}

		$contact_name = trim(implode(' ', array_filter([$data['prefix'], $data['first_name'], $data['last_name']])));
		if ($contact_name !== '') {
			$post_title = 'AGM Sponsorship: ' . $contact_name;
		} elseif ($data['sponsor_name'] !== '') {
			$post_title = 'AGM Sponsorship: ' . $data['sponsor_name'];
		} elseif ($data['organization'] !== '') {
			$post_title = 'AGM Sponsorship: ' . $data['organization'];
		} else {
			$post_title = 'AGM Sponsorship Submission';
		}

		$post_content = $data['additional_information'] !== '' ? $data['additional_information'] : '';

		$post_id = wp_insert_post(
			[
				'post_type'   => 'agm_sponsorship',
				'post_status' => 'publish',
				'post_title'  => $post_title,
				'post_content' => $post_content,
			],
			true
		);

		if (is_wp_error($post_id)) {
			wp_safe_redirect(add_query_arg('agm_sponsorship_status', 'error', $redirect));
			exit;
		}

		foreach ($data as $key => $value) {
			update_post_meta($post_id, $key, $value);
		}

		do_action('watf_agm_sponsorship_submitted', $post_id, $data);

		$recipients = [];
		if ($data['email'] && is_email($data['email'])) {
			$recipients[] = $data['email'];
		}
		$recipients = apply_filters('watf_agm_sponsorship_notification_recipients', $recipients, $post_id, $data);

		if (!empty($recipients)) {
			$levels = apply_filters(
				'watf_agm_sponsorship_levels',
				[
					''         => __('Select', 'watf'),
					'premier'  => __('Premier Sponsor', 'watf'),
					'platinum' => __('Platinum Sponsor', 'watf'),
					'gold'     => __('Gold Sponsor', 'watf'),
					'silver'   => __('Silver Sponsor', 'watf'),
					'bronze'   => __('Bronze Sponsor', 'watf'),
				]
			);

			$states_lookup = function_exists('agm_us_states_list') ? agm_us_states_list() : [];

			$contact_name = trim(implode(' ', array_filter([$data['prefix'], $data['first_name'], $data['last_name']])));
			$level_label  = $levels[$data['sponsor_level']] ?? ucwords(str_replace(['-', '_'], [' ', ' '], $data['sponsor_level']));
			$state_label  = $states_lookup[$data['state']] ?? strtoupper($data['state']);

			$address_lines = array_filter([
				$data['street'],
				trim($data['city'] . ($state_label ? ', ' . $state_label : '') . ($data['zip'] ? ' ' . $data['zip'] : '')),
			]);

			$field_items = [];

			$summary_fields = [
				'sponsor_level'          => __('Sponsor Level', 'watf'),
				'prefix'                 => __('Prefix', 'watf'),
				'first_name'             => __('First Name', 'watf'),
				'last_name'              => __('Last Name', 'watf'),
				'title'                  => __('Title', 'watf'),
				'organization'           => __('Organization', 'watf'),
				'sponsor_name'           => __('Sponsor Name', 'watf'),
				'street'                 => __('Street', 'watf'),
				'city'                   => __('City', 'watf'),
				'state'                  => __('State', 'watf'),
				'zip'                    => __('Zip', 'watf'),
				'phone'                  => __('Phone', 'watf'),
				'email'                  => __('Email', 'watf'),
				'additional_information' => __('Additional Information', 'watf'),
				'invoice_requested'      => __('Would you like an invoice?', 'watf'),
				'paying_by_check'        => __('Paying by Check?', 'watf'),
			];

			foreach ($summary_fields as $key => $label) {
				$value_markup = '';
				switch ($key) {
					case 'sponsor_level':
						$value_markup = $level_label;
						break;
					case 'state':
						$value_markup = $state_label;
						break;
					case 'additional_information':
						if ($data['additional_information'] !== '') {
							$value_markup = nl2br(esc_html($data['additional_information']));
						}
						break;
					case 'invoice_requested':
						$value_markup = $data['invoice_requested'] === 'yes' ? __('Yes', 'watf') : __('No', 'watf');
						break;
					case 'paying_by_check':
						$value_markup = $data['paying_by_check'] === 'yes' ? __('Yes', 'watf') : __('No', 'watf');
						break;
					case 'prefix':
						$value_markup = $data['prefix'];
						break;
					case 'first_name':
						$value_markup = $data['first_name'];
						break;
					case 'last_name':
						$value_markup = $data['last_name'];
						break;
					case 'title':
					case 'organization':
					case 'sponsor_name':
					case 'street':
					case 'city':
					case 'zip':
					case 'phone':
					case 'email':
						$value_markup = $data[$key];
						break;
				}

				if ($key === 'city' && $data['city'] !== '') {
					$value_markup = $data['city'];
				}

				if ($key === 'street' && $data['street'] !== '') {
					$value_markup = $data['street'];
				}

				if ($key === 'additional_information' && $value_markup === '') {
					continue;
				}

				if ($key === 'state' && $value_markup === '') {
					continue;
				}

				if ($key === 'sponsor_level' && $value_markup === '') {
					continue;
				}

				if ($key === 'prefix' && $value_markup === '') {
					continue;
				}

				if ($key === 'email' && $value_markup !== '') {
					$value_markup = esc_html($value_markup);
				} elseif (is_string($value_markup) && $value_markup !== '' && $key !== 'additional_information') {
					$value_markup = esc_html($value_markup);
				}

				if ($value_markup === '') {
					continue;
				}

				$field_items[] = '<li><strong>' . esc_html($label) . ':</strong> ' . $value_markup . '</li>';
			}

			$body_html = [];
			$body_html[] = '<p>' . ($contact_name !== '' ? 'Hello ' . esc_html($contact_name) . ',' : esc_html__('Hello,', 'watf')) . '</p>';
			$body_html[] = '<p>Thank you for your commitment to sponsor WATF’s <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="https://www.washingtonairports.com/agm/"><strong>2025 43rd Annual General Meeting and Williams Trophy Presentation.</strong></a> </p>';


			$body_html[] = '<p>To register your organization’s attendees, please use the following promo code and sponsorship attendee registration link. Please note that you are still able to fill out your organization’s meeting attendees even if you haven’t yet made your payment:</p>';

			// make  Promo Code
			$org =	$data['organization'];
			$prefix = strtoupper(substr($org, 0, 4));
			$promo_code = $prefix . 'AGM2025';

			$attendee_form_base = trailingslashit(home_url('/agm/2025-agm-sponsorship-registration-form'));
			$sponsor_ref       = function_exists('watf_encode_sponsor_ref') ? watf_encode_sponsor_ref($post_id) : '';
			$attendee_form_url = $sponsor_ref !== '' ? add_query_arg('sponsor_ref', $sponsor_ref, $attendee_form_base) : $attendee_form_base;

			$body_html[] = "<ul>";

			$body_html[] = ' <li><p style="text-decoration:none; color: #1A3C6B; font-weight:600;"> <strong> Promo Code: ' . $promo_code . '</strong></p></li>';

			$body_html[] = '<li><p style="text-decoration:none; color: #1A3C6B; font-weight:600;"><strong  > Sponsorship Attendee Registration Link:</strong> <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="' . esc_url($attendee_form_url) . '">' . esc_html($attendee_form_url) . '</a> </p></li>';

			$body_html[] = "</ul>";


			$body_html[] = '<p>If you have elected to receive an invoice, we will send one shortly.</p>
<p>If you are paying by check, make payable to: The Washington Airports Task Force, 44701 Propeller Court, Suite 100, Dulles, VA 20166.</p>';
			$body_html[] = '<p>If you would like to pay for your sponsorship online, <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="https://tinyurl.com/y5mjcxy4"><strong>click here</strong></a> . </p>';


			$body_html[] = '<p>We look forward to seeing you on Tuesday, December 2, 2025 from 11am-2pm at <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="https://www.invitedclubs.com/clubs/belmont-country-club"><strong> Belmont Country Club</strong></a>, 19661 Belmont Manor Ln., Ashburn, VA 20147.</p>';

			$body_html[] = '<p>Here is a summary of your sponsorship commitment:</p>';
			$body_html[] = '<p style="text-decoration:none; color: #1A3C6B; font-weight:600;">YES, we would like to sponsor this year’s WATF AGM</p>';
			// all fild value
			if (!empty($field_items)) {
				$body_html[] = '<ul style="margin:0 0 16px 18px; padding:0; list-style:disc;">' . implode('', $field_items) . '</ul>';
			}
			// all fild value



			$body_html[] = '<p>Thank you, again, for your registration. If any of the above information is incorrect, please contact Mark Treadaway at 703-572-8714 or <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="mailto:Mark@washingtonairports.com">Mark@washingtonairports.com</a></p>';

			$message = '<html><body>' . implode("\n", $body_html) . '</body></html>';
			$subject = __('WATF 43rd AGM Sponsorship Commitment Confirmation', 'watf');
			$headers = ['Content-Type: text/html; charset=UTF-8'];
			
			// from address set
			$from_email = 'info@washingtonairports.com';
			if ($from_email && is_email($from_email)) {
				$from_name = 'WATF';
				$headers[] = 'From: ' . sanitize_text_field($from_name) . ' <' . sanitize_email($from_email) . '>';
			}

			$admin_email = get_option('admin_email');
			if ($admin_email && is_email($admin_email)) {
				$headers[] = 'Cc: ' . sanitize_email($admin_email);
			}

			//    bcc_addresses set 
			$bcc_addresses = [];
			if (have_rows('bcc_addresses', 'option')) {
				while (have_rows('bcc_addresses', 'option')) {
					the_row();
					$email = sanitize_email(get_sub_field('recipient_email'));
					if (!empty($email)) {
						$bcc_addresses[] = $email;
					}
				}
			}

			if (!empty($bcc_addresses)) {
				$headers[] = 'Bcc: ' . implode(', ', $bcc_addresses);
			}

			wp_mail($recipients, $subject, $message, $headers);
		}

		$success_args = [
			'agm_sponsorship_status' => 'success',
		];

		if ($promo_code !== '') {
			$success_args['promo_code'] = $promo_code;
		}

		if ($attendee_form_url !== '') {
			$success_args['attendee_form_url'] = $attendee_form_url;
		}

		$thank_you = get_permalink(get_page_by_path('thank-you-2'));
		if (!$thank_you) {
			$thank_you = add_query_arg($success_args, $redirect);
		} else {
			$thank_you = add_query_arg($success_args, $thank_you);
		}

		wp_safe_redirect($thank_you);
		exit;
	}
	add_action('init', 'watf_handle_agm_sponsorship_form_submission');
}
