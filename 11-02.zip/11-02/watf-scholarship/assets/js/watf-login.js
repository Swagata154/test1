jQuery(function ($) {

    $('#watf-login-form').on('submit', function (e) {
        e.preventDefault();

        $.post(watf_ajax.ajax_url, {
            action: 'watf_scholarship_ajax_login',
            log: $('#watf-login-form input[name="log"]').val(),
            pwd: $('#watf-login-form input[name="pwd"]').val(),
            nonce: watf_ajax.nonce
        }, function (response) {
            if (response.success) {
                $('#watf-login-form').hide();
                $('#watf-otp-email').val(response.data.email);
                $('#watf-otp-form').show();
                $('#watf-login-message').html('<p>' + response.data.message + '</p>');
            } else {
                $('#watf-login-message').html('<p style="color:red;">' + response.data + '</p>');
            }
        });
    });

    $('#watf-otp-form').on('submit', function (e) {
        e.preventDefault();

        $.post(watf_ajax.ajax_url, {
            action: 'watf_scholarship_ajax_verify_otp',
            log: $('#watf-otp-email').val(),
            otp_code: $('#watf-otp-form input[name="otp_code"]').val(),
            nonce: watf_ajax.nonce
        }, function (response) {
            if (response.success) {
                window.location.href = response.data.redirect;
            } else {
                $('#watf-login-message').html('<p style="color:red;">' + response.data + '</p>');
            }
        });
    });

});
