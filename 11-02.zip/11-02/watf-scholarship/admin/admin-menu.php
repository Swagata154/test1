<?php

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_init', 'watf_scholarship_block_applicant_admin');
add_action('admin_menu', 'watf_scholarship_add_admin_menu');

require_once WATF_SCHOLARSHIP_PLUGIN_PATH . 'admin/applicants-page.php';

function watf_scholarship_block_applicant_admin()
{
    if (!is_user_logged_in()) {
        return;
    }

    $user = wp_get_current_user();
    if (in_array('scholarship_applicant', (array) $user->roles, true)) {
        wp_safe_redirect(home_url('/'));
        exit;
    }
}

function watf_scholarship_add_admin_menu()
{
    add_menu_page(
        'WATF Scholarship',
        'WATF Scholarship',
        'manage_options',
        'watf-scholarship',
        'watf_scholarship_render_admin_page',
        'dashicons-welcome-learn-more',
        26
    );

    add_submenu_page(
        'watf-scholarship',
        'Applicants',
        'Applicants',
        'manage_options',
        'watf-scholarship-applicants',
        'watf_scholarship_render_applicants_page'
    );
}

function watf_scholarship_render_admin_page()
{
    echo '<div class="wrap">';
    echo '<h1>' . esc_html__('WATF Scholarship', 'watf-scholarship') . '</h1>';
    echo '<p>' . esc_html__('Applicant data will appear here.', 'watf-scholarship') . '</p>';
    echo '</div>';
}
