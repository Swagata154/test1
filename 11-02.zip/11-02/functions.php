<?php

/**
 * watf functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package watf
 */

if (! defined('_S_VERSION')) {
	// Replace the version number of the theme on each release.
	define('_S_VERSION', '1.0.0');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function watf_setup()
{
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on watf, use a find and replace
		* to change 'watf' to the name of your theme in all the template files.
		*/
	load_theme_textdomain('watf', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support('title-tag');

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support('post-thumbnails');

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'primary' => esc_html__('Primary', 'watf'),
			'footer1' => esc_html__('Footer1', 'watf'),
			'footer2' => esc_html__('Footer2', 'watf'),
			'mobile-menu' => esc_html__('Mobile-menu', 'watf'),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'watf_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'watf_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function watf_content_width()
{
	$GLOBALS['content_width'] = apply_filters('watf_content_width', 640);
}
add_action('after_setup_theme', 'watf_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function watf_widgets_init()
{
	register_sidebar(
		array(
			'name'          => esc_html__('Sidebar', 'watf'),
			'id'            => 'sidebar-1',
			'description'   => esc_html__('Add widgets here.', 'watf'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action('widgets_init', 'watf_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function watf_scripts()
{
	wp_enqueue_style('watf-style', get_stylesheet_uri(), array(), _S_VERSION);
	wp_style_add_data('watf-style', 'rtl', 'replace');

	wp_enqueue_script('watf-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'watf_scripts');

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}




// Logos slider

function grantors_slider_shortcode()
{
	ob_start();

	$home_id = get_option('page_on_front'); // Home page ID
	$grantors = get_field('grantors_section', $home_id);

	if ($grantors):
		$heading = $grantors['heading'] ?? '';
?>
		<section class="grantors-section py-5">
			<div class="container-fluid p-2">
				<?php if ($heading): ?>
					<h2 class="mission_subheading mb-4"><?php echo esc_html($heading); ?></h2>
					<div class="white-banner-divider mb-5 bg-dark"></div>
				<?php endif; ?>

				<?php if (have_rows('grantors_section_logos_section', $home_id)): ?>
					<?php
					$logos = [];
					while (have_rows('grantors_section_logos_section', $home_id)) : the_row();
						$logos[] = [
							'logo'      => get_sub_field('logo'),
							'logo_link' => get_sub_field('logo_link'),
						];
					endwhile;

					$count = count($logos);

					if ($count <= 5) {
						$logos = array_merge($logos, $logos);
					}
					?>
					<div class="grantors-slider">
						<?php foreach ($logos as $item):
							$logo = $item['logo'];
							$logo_link = $item['logo_link'];
							if ($logo): ?>
								<div class="grantor-logo text-center">
									<?php if ($logo_link): ?>
										<a href="<?php echo esc_url($logo_link); ?>" target="_blank" rel="noopener">
											<img src="<?php echo esc_url($logo['url']); ?>" alt="<?php echo esc_attr($logo['alt']); ?>" class="img-fluid" />
										</a>
									<?php else: ?>
										<img src="<?php echo esc_url($logo['url']); ?>" alt="<?php echo esc_attr($logo['alt']); ?>" class="img-fluid" />
									<?php endif; ?>
								</div>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</section>
	<?php
	endif;

	return ob_get_clean();
}
add_shortcode('grantors_slider', 'grantors_slider_shortcode');



// History slider

function history_slider_shortcode()
{
	$page_id = 102;

	ob_start();

	if (have_rows('history_slides', $page_id)) : ?>
		<div class="history-slider container my-5">
			<?php while (have_rows('history_slides', $page_id)) : the_row();
				$img = get_sub_field('slides'); ?>
				<div class="slide">
					<?php if ($img): ?>
						<img src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['alt']); ?>">
					<?php endif; ?>
				</div>
			<?php endwhile; ?>
		</div>
	<?php else: ?>
		<!-- Debug: No slides found for page ID <?php echo $page_id; ?> -->
	<?php endif;

	return ob_get_clean();
}
add_shortcode('history_slider', 'history_slider_shortcode');


// Force Yoast breadcrumb links to use correct domain
add_filter('wpseo_breadcrumb_links', function ($links) {
	foreach ($links as &$link) {
		if (!empty($link['url'])) {
			// Replace old local domain with live domain
			$link['url'] = str_replace(
				'http://soumik/watf/',
				'https://watf.wpenginepowered.com/',
				$link['url']
			);
		}
	}
	return $links;
});


function add_page_excerpts()
{
	add_post_type_support('page', 'excerpt');
}
add_action('init', 'add_page_excerpts');
// [agm_checkout_popup] — shows Square checkout in a modal that auto-opens
function agm_checkout_popup_shortcode()
{
	$checkout_url = 'https://checkout.square.site/merchant/BXYY7Z3S6GE6V/checkout/EJU4ZDF5IR3H6VWO3XSSJKUB';

	ob_start(); ?>
	<style>
		/* Loader Animation */
		.loader {
			width: 60px;
			aspect-ratio: 4;
			background: radial-gradient(closest-side at calc(100%/6) 50%, #000 90%, #0000) 0/75% 100%;
			position: relative;
			animation: l15-0 1s infinite linear;
		}

		.loader::before {
			content: "";
			position: absolute;
			background: inherit;
			clip-path: inset(0 0 0 50%);
			inset: 0;
			animation: l15-1 0.5s infinite linear;
		}

		@keyframes l15-0 {

			0%,
			49.99% {
				transform: scale(1);
			}

			50%,
			100% {
				transform: scale(-1);
			}
		}

		@keyframes l15-1 {
			0% {
				transform: translateX(-37.5%) rotate(0turn);
			}

			80%,
			100% {
				transform: translateX(-37.5%) rotate(1turn);
			}
		}
	</style>

	<!-- Modal -->
	<div class="modal fade" id="agmCheckoutModal" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-sm" style="max-width:1200px;">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body p-0">
					<div style="height:80vh; position:relative; overflow:hidden;">
						<!-- Loader overlay -->
						<div id="agmLoader" style="
							position:absolute;
							inset:0;
							display:flex;
							align-items:center;
							justify-content:center;
							background:#fff;
							z-index:10;
							transition:opacity 0.4s ease;">
							<div class="loader"></div>
						</div>

						<iframe
							id="agmSquareFrame"
							src="<?php echo esc_url($checkout_url); ?>"
							title="Square Checkout"
							loading="lazy"
							style="border:0; width:100%; height:100%; display:block; opacity:0; transition:opacity 0.4s ease;"
							referrerpolicy="no-referrer-when-downgrade"
							allow="payment *; clipboard-write *">
						</iframe>
					</div>
				</div>
				<div class="modal-footer d-flex justify-content-between"></div>
			</div>
		</div>
	</div>

	<script>
		document.addEventListener('DOMContentLoaded', function() {
			const modalEl = document.getElementById('agmCheckoutModal');
			const iframe = document.getElementById('agmSquareFrame');
			const loader = document.getElementById('agmLoader');

			if (window.bootstrap && bootstrap.Modal) {
				const modal = new bootstrap.Modal(modalEl, {
					backdrop: 'static'
				});
				modal.show();

				// When iframe finishes loading
				iframe.addEventListener('load', function() {
					loader.style.opacity = '0';
					iframe.style.opacity = '1';
					setTimeout(() => loader.remove(), 400);
				});


			}
		});
	</script>
<?php
	return ob_get_clean();
}
add_shortcode('agm_checkout_popup', 'agm_checkout_popup_shortcode');


// registration_form
function agm_registration_form_shortcode()
{
	$states      = agm_us_states_list();
	$errors      = [];
	$success_ids = [];

	// ---- PROCESS SUBMIT ----
	if (isset($_POST['agm_submit'])) {
		if (!isset($_POST['agm_nonce']) || !wp_verify_nonce($_POST['agm_nonce'], 'agm_register')) {
			$errors[] = 'Security check failed. Please try again.';
		} else {
			$fields = [
				'prefix',
				'first_name',
				'last_name',
				'title',
				'organization',
				'badge_name',
				'street',
				'city',
				'state',
				'zip',
				'phone',
				'email',
				'attendee_type',
				'promo_code',
				'special_info'
			];
			foreach ($fields as $f) {
				if (!isset($_POST[$f]) || !is_array($_POST[$f])) $_POST[$f] = [];
			}

			$count = count($_POST['first_name']);
			$attendees = [];

			for ($i = 0; $i < $count; $i++) {
				$att = [
					'prefix'        => sanitize_text_field($_POST['prefix'][$i] ?? ''),
					'first_name'    => sanitize_text_field($_POST['first_name'][$i] ?? ''),
					'last_name'     => sanitize_text_field($_POST['last_name'][$i] ?? ''),
					'title'         => sanitize_text_field($_POST['title'][$i] ?? ''),
					'organization'  => sanitize_text_field($_POST['organization'][$i] ?? ''),
					'badge_name'    => sanitize_text_field($_POST['badge_name'][$i] ?? ''),
					'street'        => sanitize_text_field($_POST['street'][$i] ?? ''),
					'city'          => sanitize_text_field($_POST['city'][$i] ?? ''),
					'state'         => sanitize_text_field($_POST['state'][$i] ?? ''),
					'zip'           => sanitize_text_field($_POST['zip'][$i] ?? ''),
					'phone'         => sanitize_text_field($_POST['phone'][$i] ?? ''),
					'email'         => sanitize_email($_POST['email'][$i] ?? ''),
					'attendee_type' => sanitize_text_field($_POST['attendee_type'][$i] ?? ''),
					'promo_code'    => sanitize_text_field($_POST['promo_code'][$i] ?? ''),
					'special_info'  => sanitize_textarea_field($_POST['special_info'][$i] ?? ''),
				];

				$is_empty = implode('', array_map('strval', $att)) === '';
				if ($is_empty) continue;

				// Required validation
				if (
					$att['first_name'] === '' || $att['last_name'] === '' || $att['title'] === '' ||
					$att['organization'] === '' || $att['badge_name'] === '' || $att['street'] === '' ||
					$att['city'] === '' || $att['state'] === '' || $att['zip'] === '' ||
					$att['phone'] === '' || $att['email'] === '' || $att['attendee_type'] === ''
				) {
					$errors[] = sprintf('Attendee %d: Please fill all required fields.', $i + 1);
					continue;
				}
				if (!isset($states[$att['state']])) {
					$errors[] = sprintf('Attendee %d: Invalid state.', $i + 1);
					continue;
				}
				if (!is_email($att['email'])) {
					$errors[] = sprintf('Attendee %d: Invalid email address.', $i + 1);
					continue;
				}

				$attendees[] = $att;
			}

			if (empty($attendees)) {
				$errors[] = 'No attendee information was provided.';
			}

			if (empty($errors) && !empty($attendees)) {
				$primary = $attendees[0];

				$primary_id = wp_insert_post([
					'post_type'   => 'agm_attendee',
					'post_status' => 'publish',
					'post_title'  => 'AGM Attendee: ' . $primary['first_name'] . ' ' . $primary['last_name'],
				], true);

				if (is_wp_error($primary_id)) {
					$errors[] = sprintf('Attendee 1: Could not save (error: %s).', $primary_id->get_error_message());
				} else {
					foreach ($primary as $k => $v) {
						update_post_meta($primary_id, $k, $v);
					}
					update_post_meta($primary_id, 'registration_group', $primary_id);
					update_post_meta($primary_id, 'group_position', 1);
					update_post_meta($primary_id, 'is_primary', 1);

					$child_ids = [];
					$total_attendees = count($attendees);
					$saved_count = 1;

					for ($i = 1; $i < $total_attendees; $i++) {
						$child = $attendees[$i];

						$child_id = wp_insert_post([
							'post_type'   => 'agm_attendee',
							'post_status' => 'publish',
							'post_parent' => $primary_id,
							'post_title'  => 'AGM Attendee: ' . $child['first_name'] . ' ' . $child['last_name'],
							'menu_order'  => $i + 1,
						], true);

						if (is_wp_error($child_id)) {
							$errors[] = sprintf('Attendee %d: Could not save (error: %s).', $i + 1, $child_id->get_error_message());
							continue;
						}

						foreach ($child as $k => $v) {
							update_post_meta($child_id, $k, $v);
						}
						update_post_meta($child_id, 'registration_group', $primary_id);
						update_post_meta($child_id, 'group_position', $i + 1);
						update_post_meta($child_id, 'is_primary', 0);

						$child_ids[] = $child_id;
						$success_ids[] = $child_id;
						$saved_count++;
					}

					foreach ($child_ids as $child_id) {
						update_post_meta($child_id, 'group_total', $saved_count);
					}

					$child_ids = array_map('intval', $child_ids);

					update_post_meta($primary_id, 'additional_attendee_ids', $child_ids);
					update_post_meta($primary_id, 'group_total', $saved_count);

					if (empty($errors)) {
						$primary_email = $primary['email'] ?? '';

						if ($primary_email && is_email($primary_email)) {
							$site_name = get_bloginfo('name');
							// $subject   = sprintf('[%s] AGM Registration Confirmation', $site_name ?: 'Website');
							$subject   = "WATF 43rd AGM Registration Confirmation";

							$primary_name = trim(($primary['prefix'] ?? '') . ' ' . ($primary['first_name'] ?? '') . ' ' . ($primary['last_name'] ?? ''));

							$body_html = [];
							$body_html[] = '<p>' . ($primary_name !== '' ? 'Hello ' . esc_html($primary_name) . ',' : 'Hello,') . '</p>';
							$body_html[] = '<p>Thank you registering for WATF\'s <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="https://www.washingtonairports.com/agm/"><strong>2025 43rd Annual General Meeting and Williams Trophy Presentation</strong></a>.</p>';
							$body_html[] = '<p>If you haven\'t already, please pay for your registration by <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="https://tinyurl.com/58y23svk"><strong>clicking here</strong></a>.</p>';
							$body_html[] = '<p>We look forward to seeing you on Tuesday, December 2, 2025 from 11am-2pm at <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="https://www.invitedclubs.com/clubs/belmont-country-club"><strong>Belmont Country Club</strong></a>, 19661 Belmont Manor Ln., Ashburn, VA 20147.</p>';
							$body_html[] = '<p>Here is a summary of your registration:</p>';

							$field_labels = [
								'prefix'        => 'Prefix',
								'first_name'    => 'First Name',
								'last_name'     => 'Last Name',
								'title'         => 'Title',
								'organization'  => 'Organization',
								'badge_name'    => 'Badge Name',
								'street'        => 'Street',
								'city'          => 'City',
								'state'         => 'State',
								'zip'           => 'Zip',
								'phone'         => 'Phone',
								'email'         => 'Email',
								'attendee_type' => 'Attendee Type',
								'promo_code'    => 'Promo Code',
								//	'special_info'  => 'Special Information',
								'special_info'  => 'Special Accommodations, Dietary Restrictions, and Additional Information',
							];

							$attendee_type_labels = agm_attendee_type_labels();

							foreach ($attendees as $index => $attendee_data) {
								$field_items = [];

								foreach ($field_labels as $key => $label) {
									if (!isset($attendee_data[$key]) || $attendee_data[$key] === '') {
										continue;
									}

									$value = $attendee_data[$key];
									if ($key === 'special_info') {
										$clean = trim($value);
										if ($clean === '') {
											continue;
										}
										$value_markup = nl2br(esc_html($clean));
									} elseif ($key === 'attendee_type') {
										$normalized = strtolower((string) $value);
										$display_value = $attendee_type_labels[$normalized] ?? ucwords(str_replace(['-', '_'], [' ', ' '], $normalized));
										$value_markup = esc_html($display_value);
									} else {
										$value_markup = esc_html($value);
									}
									$field_items[] = '<li><strong>' . esc_html($label) . ':</strong> ' . $value_markup . '</li>';
								}

								if (!empty($field_items)) {
									$body_html[] = '<div style="margin-bottom:16px;"><p style="margin:0 0 6px;"><strong style="font-weight:700;">Attendee ' . ($index + 1) . ':</strong></p><ul style="margin:0; padding-left:18px;">' . implode('', $field_items) . '</ul></div>';
								}
							}

							$body_html[] = '<p>Thank you, again, for your registration. If any of the above information is incorrect, please contact Lisa Merhaut at 703-572-8714 or <a href="mailto:Lisa@washingtonairports.com">Lisa@washingtonairports.com</a>.</p>';

							$headers = ['Content-Type: text/html; charset=UTF-8'];

							// from address set
							$from_email = 'info@washingtonairports.com';
							if ($from_email && is_email($from_email)) {
								$from_name = 'WATF';
								$headers[] = 'From: ' . sanitize_text_field($from_name) . ' <' . sanitize_email($from_email) . '>';
							}

							//    cc_addresses set 
							$admin_email = get_option('admin_email');
							if ($admin_email && is_email($admin_email)) {
								$headers[] = 'Cc: ' . sanitize_email($admin_email);
							}

							//    from address set
							// $from_email = $admin_email;
							// if (empty($from_email) || !is_email($from_email)) {
							// 	$host = wp_parse_url(home_url('/'), PHP_URL_HOST);
							// 	if ($host) {
							// 		$from_email = 'no-reply@' . sanitize_text_field($host);
							// 	}
							// }


							//    bcc_addresses set 
							$bcc_addresses = [];
							if (have_rows('bcc_addresses', 'option')) {
								while (have_rows('bcc_addresses', 'option')) {
									the_row();
									$email = sanitize_email(get_sub_field('recipient_email'));
									if (!empty($email)) {
										$bcc_addresses[] = $email;
									}
								}
							}

							if (!empty($bcc_addresses)) {
								$headers[] = 'Bcc: ' . implode(', ', $bcc_addresses);
							}

							$message = '<html><body>' . implode("\n", $body_html) . '</body></html>';
							wp_mail($primary_email, $subject, $message, $headers);
						}
					}

					$success_ids[] = $primary_id;
				}
			}

			// ✅ On success: redirect so the form renders fresh (no POST data)
			if (!empty($success_ids) && empty($errors)) {
				wp_safe_redirect(home_url('/thank-you/'));
				exit;
			}
		}
	}

	// If we get here, either first load or there were errors
	if (!empty($errors)) {
		echo '<div class="alert alert-danger"><ul style="margin:0; padding-left:18px;">';
		foreach ($errors as $e) echo '<li>' . esc_html($e) . '</li>';
		echo '</ul></div>';
	}

	// Success notice after redirect (fresh page; no POST data present)
	if (isset($_GET['agm_success']) && ctype_digit((string)$_GET['agm_success'])) {
		echo '<div class="alert alert-success">Thank you! ' . intval($_GET['agm_success']) . ' attendee(s) saved.</div>';
	}

	// Helpers: only repopulate values if there are errors (so users can fix them)
	$has_errors = !empty($errors);

	ob_start(); ?>
	<div class="container px-3 pb-5">
		<form method="post" class="agm-registration-form" id="agm-form">
			<?php wp_nonce_field('agm_register', 'agm_nonce'); ?>
			<input type="hidden" name="agm_submit" value="1" />

			<h3 class="mb-1 text-center">Annual General Meeting Attendee Registration Form</h3>
			<p class="text-muted mb-4"><span class="text-danger">*</span> Indicates required fields.</p>

			<div id="attendee-forms">
				<?php
				// Show 1 blank attendee unless there are errors (then keep count to let users fix)
				$total = $has_errors && isset($_POST['first_name']) ? max(1, count((array)$_POST['first_name'])) : 1;
				for ($i = 0; $i < $total; $i++): ?>
					<div class="attendee-form mb-4">
						<div class="d-flex align-items-center gap-3 mb-3">
							<h5 class="mb-0 attendee-title ">Attendee <?php echo ($i + 1); ?></h5>
							<button type="button"
								class="remove-attendee btn btn-sm p-0<?php echo $i === 0 ? ' d-none' : ''; ?>"
								title="<?php echo esc_attr__('Remove attendee', 'watf'); ?>"
								aria-label="<?php echo esc_attr__('Remove attendee', 'watf'); ?>"
								<?php echo $i === 0 ? 'disabled' : ''; ?>>
								<i class="fa-solid fa-trash" aria-hidden="true"></i>
							</button>

						</div>

						<div class="row g-4">
							<div class="col-12 col-md-2">
								<label class="form-label">Prefix </label>
								<input type="text" name="prefix[]" class="form-control">
							</div>
							<div class="col-12 col-md-5">
								<label class="form-label">First Name <span class="text-danger">*</span></label>
								<input type="text" name="first_name[]" class="form-control" required>
							</div>
							<div class="col-12 col-md-5">
								<label class="form-label">Last Name <span class="text-danger">*</span></label>
								<input type="text" name="last_name[]" class="form-control" required>
							</div>

							<div class="col-12 col-md-6">
								<label class="form-label">Title <span class="text-danger">*</span></label>
								<input type="text" name="title[]" class="form-control" required>
							</div>
							<div class="col-12 col-md-6">
								<label class="form-label">Organization <span class="text-danger">*</span></label>
								<input type="text" name="organization[]" class="form-control organization-field" required>
							</div>

							<div class="col-12 col-md-6">
								<label class="form-label">Badge Name <span class="text-danger">*</span></label>
								<input type="text" name="badge_name[]" class="form-control badge-field" required>
							</div>
							<div class="col-12 col-md-6">
								<label class="form-label">Street <span class="text-danger">*</span></label>
								<input type="text" name="street[]" class="form-control street-field" required>
							</div>

							<div class="col-12 col-md-6">
								<label class="form-label">City <span class="text-danger">*</span></label>
								<input type="text" name="city[]" class="form-control city-field" required>
							</div>

							<div class="col-12 col-md-3">
								<label class="form-label">State <span class="text-danger">*</span></label>
								<select name="state[]" class="form-select state-field" required>
									<option value="">Select</option>
									<?php foreach ($states as $abbr => $name): ?>
										<option value="<?php echo esc_attr($abbr); ?>">
											<?php echo esc_html($name); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
							<div class="col-12 col-md-3">
								<label class="form-label">Zip <span class="text-danger">*</span></label>
								<input type="text" name="zip[]" class="form-control zip-field" required>
							</div>

							<div class="col-12 col-md-6">
								<label class="form-label">Phone <span class="text-danger">*</span></label>
								<input type="tel" name="phone[]" class="form-control" required>
							</div>
							<div class="col-12 col-md-6">
								<label class="form-label">Email <span class="text-danger">*</span></label>
								<input type="email" name="email[]" class="form-control" required>
							</div>

							<div class="col-12 col-md-6">
								<label class="form-label">Attendee Type <span class="text-danger">*</span></label>
								<select name="attendee_type[]" class="form-select" required>
									<option value="">Select</option>
									<option value="non-member">Non-Member</option>
									<option value="board-member">Board Member</option>
									<option value="sponsor">Sponsor</option>
								</select>
							</div>
							<div class="col-12 col-md-6">
								<label class="form-label">Promo Code</label>
								<input type="text" name="promo_code[]" class="form-control">
							</div>

							<div class="col-12">
								<label class="form-label">Special Accommodations, Dietary Restrictions, and Additional Information</label>
								<textarea name="special_info[]" rows="3" class="form-control"></textarea>
							</div>
						</div>
					</div>
				<?php endfor; ?>
			</div>

			<p class="click text-center"><a href="#" id="add-attendee" class="fw-bold">Click here</a> to add an additional AGM meeting attendee.</p>
			<!-- <p class="note text-center">NOTE TO DEVELOPERS: If first registrant wants to add multiple people, we need to give them the ability to either pre-populate with same general organizational info, (assuming their from the same organization). But if not from the same organization, then another full form needs to appear below the first form.</p> -->
			<p class="que text-center">QUESTIONS?</p>
			<p class="email text-center">For event sponsorships, contact <a href="mailto:Mark@washingtonairports.com">Mark@washingtonairports.com</a>.</p>
			<p class="email text-center">For event details, contact <a href="mailto:Lisa@washingtonairports.com">Lisa@washingtonairports.com</a>.</p>

			<div class="text-center mt-3">
				<button type="submit" class="btn btn-primary px-4 button1">Submit</button>
			</div>
		</form>
	</div>

	<script>
		document.addEventListener('DOMContentLoaded', function() {
			const container = document.getElementById('attendee-forms');
			const addBtn = document.getElementById('add-attendee');

			if (!container) {
				return;
			}

			const updateAttendeeSections = () => {
				const forms = container.querySelectorAll('.attendee-form');
				forms.forEach((form, index) => {
					const heading = form.querySelector('.attendee-title');
					if (heading) {
						heading.textContent = 'Attendee ' + (index + 1);
						if (index === 0) {
							heading.classList.add('d-none');
						} else {
							heading.classList.remove('d-none');
						}
					}
					const removeButton = form.querySelector('.remove-attendee');
					if (removeButton) {
						if (index === 0) {
							removeButton.classList.add('d-none');
							removeButton.setAttribute('disabled', 'disabled');
						} else {
							removeButton.classList.remove('d-none');
							removeButton.removeAttribute('disabled');
						}
					}
				});
			};

			updateAttendeeSections();

			if (addBtn) {
				addBtn.addEventListener('click', function(e) {
					e.preventDefault();

					const forms = container.querySelectorAll('.attendee-form');
					const first = forms[0];
					if (!first) {
						return;
					}

					const orgField = first.querySelector('.organization-field');
					//const badgeField = first.querySelector('.badge-field');
					const streetField = first.querySelector('.street-field');
					const cityField = first.querySelector('.city-field');
					const stateField = first.querySelector('.state-field');
					const zipField = first.querySelector('.zip-field');

					const orgVal = orgField ? orgField.value : '';
					// const badgeVal = badgeField ? badgeField.value : '';
					const streetVal = streetField ? streetField.value : '';
					const cityVal = cityField ? cityField.value : '';
					const stateVal = stateField ? stateField.value : '';
					const zipVal = zipField ? zipField.value : '';

					const clone = first.cloneNode(true);

					const cloneHeading = clone.querySelector('.attendee-title');
					if (cloneHeading) {
						cloneHeading.textContent = 'Attendee ' + (forms.length + 1);
						cloneHeading.classList.remove('d-none');
					}

					const removeBtn = clone.querySelector('.remove-attendee');
					if (removeBtn) {
						removeBtn.classList.remove('d-none');
						removeBtn.removeAttribute('disabled');
					}

					clone.querySelectorAll('input, textarea, select').forEach(el => {
						el.classList.remove('is-invalid', 'is-valid');
						if (el.classList.contains('organization-field')) el.value = orgVal;
						//	else if (el.classList.contains('badge-field')) el.value = badgeVal;
						else if (el.classList.contains('street-field')) el.value = streetVal;
						else if (el.classList.contains('city-field')) el.value = cityVal;
						else if (el.classList.contains('state-field')) el.value = stateVal;
						else if (el.classList.contains('zip-field')) el.value = zipVal;
						else if (el.tagName === 'SELECT') el.selectedIndex = 0;
						else el.value = '';
					});

					container.appendChild(clone);
					updateAttendeeSections();
				});
			}

			container.addEventListener('click', function(event) {
				const removeBtn = event.target.closest('.remove-attendee');
				if (!removeBtn) {
					return;
				}

				event.preventDefault();

				const form = removeBtn.closest('.attendee-form');
				if (!form) {
					return;
				}

				form.remove();
				updateAttendeeSections();
			});
		});
	</script>
<?php
	return ob_get_clean();
}
add_shortcode('agm_registration_form', 'agm_registration_form_shortcode');

function agm_us_states_list()
{
	return [
		'AL' => 'Alabama',
		'AK' => 'Alaska',
		'AZ' => 'Arizona',
		'AR' => 'Arkansas',
		'CA' => 'California',
		'CO' => 'Colorado',
		'CT' => 'Connecticut',
		'DE' => 'Delaware',
		'DC' => 'District of Columbia',
		'FL' => 'Florida',
		'GA' => 'Georgia',
		'HI' => 'Hawaii',
		'ID' => 'Idaho',
		'IL' => 'Illinois',
		'IN' => 'Indiana',
		'IA' => 'Iowa',
		'KS' => 'Kansas',
		'KY' => 'Kentucky',
		'LA' => 'Louisiana',
		'ME' => 'Maine',
		'MD' => 'Maryland',
		'MA' => 'Massachusetts',
		'MI' => 'Michigan',
		'MN' => 'Minnesota',
		'MS' => 'Mississippi',
		'MO' => 'Missouri',
		'MT' => 'Montana',
		'NE' => 'Nebraska',
		'NV' => 'Nevada',
		'NH' => 'New Hampshire',
		'NJ' => 'New Jersey',
		'NM' => 'New Mexico',
		'NY' => 'New York',
		'NC' => 'North Carolina',
		'ND' => 'North Dakota',
		'OH' => 'Ohio',
		'OK' => 'Oklahoma',
		'OR' => 'Oregon',
		'PA' => 'Pennsylvania',
		'RI' => 'Rhode Island',
		'SC' => 'South Carolina',
		'SD' => 'South Dakota',
		'TN' => 'Tennessee',
		'TX' => 'Texas',
		'UT' => 'Utah',
		'VT' => 'Vermont',
		'VA' => 'Virginia',
		'WA' => 'Washington',
		'WV' => 'West Virginia',
		'WI' => 'Wisconsin',
		'WY' => 'Wyoming'
	];
}

function agm_attendee_type_labels()
{
	$labels = [
		'non-member'   => 'Non-Member',
		'board-member' => 'Board Member',
		'sponsor'      => 'Sponsor',
	];

	return apply_filters('agm_attendee_type_labels', $labels);
}

// [agm_registration_form]
// 1) Register "AGM Attendee" CPT
add_action('init', function () {
	register_post_type('agm_attendee', [
		'label'           => __('AGM Attendees', 'watf'),
		'labels'          => [
			'singular_name'  => __('AGM Attendee', 'watf'),
			'menu_name'      => __('AGM Attendees', 'watf'),
			'name_admin_bar' => __('AGM Attendee', 'watf'),
			'add_new'        => '',
			'add_new_item'   => '',
			'edit_item'      => __('Attendee Details', 'watf'),
			'view_item'      => __('View Attendee', 'watf'),
			'all_items'      => __('AGM Attendees', 'watf'),
			'back_to_items'  => __('← Back to AGM Attendees', 'watf'),
		],
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'supports'        => ['title'],
		'capability_type' => 'post',
		'map_meta_cap'    => true,
		'capabilities'    => [
			'create_posts' => 'do_not_allow',
		],
		'menu_position'   => 25,
		'menu_icon'       => 'dashicons-groups',
	]);
});

define('WATF_SPONSOR_ATTENDEE_CPT', 'agm_sponsor_att');

add_action('init', function () {
	register_post_type(WATF_SPONSOR_ATTENDEE_CPT, [
		'label'           => __('AGM Sponsorship Attendees', 'watf'),
		'labels'          => [
			'singular_name' => __('AGM Sponsorship Attendee', 'watf'),
		],
		'public'          => false,
		'show_ui'         => false,
		'show_in_menu'    => false,
		'supports'        => ['title'],
		'capability_type' => 'post',
		'map_meta_cap'    => true,
	]);
});
/**
 * 1) Meta box: show & edit all attendee data
 */
add_action('add_meta_boxes', function () {
	add_meta_box(
		'agm_attendee_details',
		'Attendee Details',
		'agm_attendee_details_metabox_cb',
		'agm_attendee',
		'normal',
		'default'
	);
});

function agm_attendee_details_metabox_cb($post)
{
	wp_nonce_field('agm_attendee_save_meta', 'agm_attendee_nonce');

	$g = function ($key, $default = '') use ($post) {
		$val = get_post_meta($post->ID, $key, true);
		return $val !== '' ? $val : $default;
	};

	$states = function_exists('agm_us_states_list') ? agm_us_states_list() : [];
?>
	<style>
		.agm-grid {
			display: grid;
			grid-template-columns: repeat(2, minmax(0, 1fr));
			gap: 12px;
		}

		.agm-grid .full {
			grid-column: 1 / -1;
		}

		.agm-grid label {
			display: block;
			font-weight: 600;
			margin-bottom: 4px;
		}

		.agm-grid input,
		.agm-grid select,
		.agm-grid textarea {
			width: 100%;
		}
	</style>

	<?php
	$is_child = (int) $post->post_parent !== 0;
	?>

	<div class="agm-grid">
		<div>
			<label>Prefix</label>
			<input type="text" name="agm[prefix]" value="<?php echo esc_attr($g('prefix')); ?>">
		</div>
		<div>
			<label>Badge Name *</label>
			<input type="text" name="agm[badge_name]" value="<?php echo esc_attr($g('badge_name')); ?>">
		</div>

		<div>
			<label>First Name *</label>
			<input type="text" name="agm[first_name]" value="<?php echo esc_attr($g('first_name')); ?>">
		</div>
		<div>
			<label>Last Name *</label>
			<input type="text" name="agm[last_name]" value="<?php echo esc_attr($g('last_name')); ?>">
		</div>

		<div>
			<label>Title *</label>
			<input type="text" name="agm[title]" value="<?php echo esc_attr($g('title')); ?>">
		</div>
		<div>
			<label>Organization *</label>
			<input type="text" name="agm[organization]" value="<?php echo esc_attr($g('organization')); ?>">
		</div>

		<div class="full">
			<label>Street *</label>
			<input type="text" name="agm[street]" value="<?php echo esc_attr($g('street')); ?>">
		</div>

		<div>
			<label>City *</label>
			<input type="text" name="agm[city]" value="<?php echo esc_attr($g('city')); ?>">
		</div>
		<div>
			<label>State *</label>
			<select name="agm[state]">
				<option value="">Select</option>
				<?php foreach ($states as $abbr => $name): ?>
					<option value="<?php echo esc_attr($abbr); ?>" <?php selected($g('state'), $abbr); ?>>
						<?php echo esc_html($name); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>

		<div>
			<label>Zip *</label>
			<input type="text" name="agm[zip]" value="<?php echo esc_attr($g('zip')); ?>">
		</div>
		<div>
			<label>Attendee Type *</label>
			<select name="agm[attendee_type]">
				<?php
				$types = [
					'non-member'  => 'Non-Member',
					'board-member' => 'Board Member',
					'sponsor'     => 'Sponsor',
				];
				$cur   = $g('attendee_type');
				?>
				<option value="">Select</option>
				<?php foreach ($types as $val => $label): ?>
					<option value="<?php echo esc_attr($val); ?>" <?php selected($cur, $val); ?>>
						<?php echo esc_html($label); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>

		<div>
			<label>Phone *</label>
			<input type="text" name="agm[phone]" value="<?php echo esc_attr($g('phone')); ?>">
		</div>
		<div>
			<label>Email *</label>
			<input type="email" name="agm[email]" value="<?php echo esc_attr($g('email')); ?>">
		</div>

		<div>
			<label>Promo Code</label>
			<input type="text" name="agm[promo_code]" value="<?php echo esc_attr($g('promo_code')); ?>">
		</div>
		<div class="full">
			<label>Special Accommodations / Dietary / Additional Info</label>
			<textarea name="agm[special_info]" rows="4"><?php echo esc_textarea($g('special_info')); ?></textarea>
		</div>
	</div>

	<?php if (!$is_child): ?>
		<hr>
		<h3>Additional Attendees</h3>
		<?php
		$children = get_posts([
			'post_type'      => 'agm_attendee',
			'post_parent'    => $post->ID,
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		]);
		?>
		<?php if (!empty($children)): ?>
			<table class="widefat striped" style="margin-top: 12px;">
				<thead>
					<tr>
						<th scope="col">Name</th>
						<th scope="col">Email</th>
						<th scope="col">Organization</th>
						<th scope="col">Type</th>
						<th scope="col">Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($children as $child):
						$first = get_post_meta($child->ID, 'first_name', true);
						$last  = get_post_meta($child->ID, 'last_name', true);
						$email = get_post_meta($child->ID, 'email', true);
						$org   = get_post_meta($child->ID, 'organization', true);
						$type  = get_post_meta($child->ID, 'attendee_type', true);
					?>
						<tr>
							<td><?php echo esc_html(trim($first . ' ' . $last)); ?></td>
							<td>
								<?php if ($email): ?>
									<a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a>
								<?php else: ?>
									<span class="description">N/A</span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ($org): ?>
									<?php echo esc_html($org); ?>
								<?php else: ?>
									<span class="description">N/A</span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ($type): ?>
									<?php echo esc_html(ucfirst($type)); ?>
								<?php else: ?>
									<span class="description">N/A</span>
								<?php endif; ?>
							</td>
							<td>
								<a href="<?php echo esc_url(get_edit_post_link($child->ID)); ?>">Edit attendee</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else: ?>
			<p class="description">No additional attendees are linked to this registration.</p>
		<?php endif; ?>
	<?php else: ?>
		<?php
		$parent_link = get_edit_post_link($post->post_parent);
		if ($parent_link):
		?>
			<hr>
			<p class="description">
				This attendee is linked to the primary registrant.
				<a href="<?php echo esc_url($parent_link); ?>">View primary attendee</a>
			</p>
		<?php endif; ?>
	<?php endif; ?>
<?php
}

/**
 * 2) Save meta from meta box
 */
add_action('save_post_agm_attendee', function ($post_id, $post, $update) {
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
	if (!isset($_POST['agm_attendee_nonce']) || !wp_verify_nonce($_POST['agm_attendee_nonce'], 'agm_attendee_save_meta')) return;
	if (!current_user_can('edit_post', $post_id)) return;

	if (!isset($_POST['agm']) || !is_array($_POST['agm'])) return;

	$raw = wp_unslash($_POST['agm']); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$clean = [
		'prefix'        => sanitize_text_field($raw['prefix']        ?? ''),
		'badge_name'    => sanitize_text_field($raw['badge_name']    ?? ''),
		'first_name'    => sanitize_text_field($raw['first_name']    ?? ''),
		'last_name'     => sanitize_text_field($raw['last_name']     ?? ''),
		'title'         => sanitize_text_field($raw['title']         ?? ''),
		'organization'  => sanitize_text_field($raw['organization']  ?? ''),
		'street'        => sanitize_text_field($raw['street']        ?? ''),
		'city'          => sanitize_text_field($raw['city']          ?? ''),
		'state'         => sanitize_text_field($raw['state']         ?? ''),
		'zip'           => sanitize_text_field($raw['zip']           ?? ''),
		'attendee_type' => sanitize_text_field($raw['attendee_type'] ?? ''),
		'phone'         => sanitize_text_field($raw['phone']         ?? ''),
		'email'         => sanitize_email($raw['email']              ?? ''),
		'promo_code'    => sanitize_text_field($raw['promo_code']    ?? ''),
		'special_info'  => sanitize_textarea_field($raw['special_info'] ?? ''),
	];

	foreach ($clean as $k => $v) {
		update_post_meta($post_id, $k, $v);
	}

	// Optional: keep title in sync
	if (!empty($clean['first_name']) || !empty($clean['last_name'])) {
		remove_action('save_post_agm_attendee', __FUNCTION__, 10); // prevent recursion
		wp_update_post([
			'ID'         => $post_id,
			'post_title' => 'AGM Attendee: ' . trim($clean['first_name'] . ' ' . $clean['last_name']),
		]);
		add_action('save_post_agm_attendee', __FUNCTION__, 10, 3);
	}

	$parent_id = (int) wp_get_post_parent_id($post_id);
	if ($parent_id > 0) {
		$child_ids = get_posts([
			'post_type'      => 'agm_attendee',
			'post_parent'    => $parent_id,
			'fields'         => 'ids',
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		]);
		$child_ids = array_map('intval', $child_ids);
		$group_total = 1 + count($child_ids);

		update_post_meta($post_id, 'is_primary', 0);
		update_post_meta($post_id, 'registration_group', $parent_id);
		$position_index = array_search($post_id, $child_ids, true);
		$group_position = ($position_index === false ? 0 : (int) $position_index) + 2;
		update_post_meta($post_id, 'group_position', $group_position);
		update_post_meta($post_id, 'group_total', $group_total);

		update_post_meta($parent_id, 'group_total', $group_total);
		update_post_meta($parent_id, 'additional_attendee_ids', $child_ids);

		foreach ($child_ids as $index => $child_id) {
			update_post_meta($child_id, 'registration_group', $parent_id);
			update_post_meta($child_id, 'group_position', $index + 2);
			update_post_meta($child_id, 'group_total', $group_total);
			update_post_meta($child_id, 'is_primary', 0);
		}
	} else {
		$child_ids = get_posts([
			'post_type'      => 'agm_attendee',
			'post_parent'    => $post_id,
			'fields'         => 'ids',
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		]);
		$child_ids = array_map('intval', $child_ids);
		$group_total = 1 + count($child_ids);

		update_post_meta($post_id, 'is_primary', 1);
		update_post_meta($post_id, 'registration_group', $post_id);
		update_post_meta($post_id, 'group_position', 1);
		update_post_meta($post_id, 'group_total', $group_total);
		update_post_meta($post_id, 'additional_attendee_ids', $child_ids);

		foreach ($child_ids as $index => $child_id) {
			update_post_meta($child_id, 'registration_group', $post_id);
			update_post_meta($child_id, 'group_position', $index + 2);
			update_post_meta($child_id, 'group_total', $group_total);
			update_post_meta($child_id, 'is_primary', 0);
		}
	}
}, 10, 3);

/**
 * Export AGM attendees from the list screen.
 */
add_action('admin_head-edit.php', function () {
	$screen = function_exists('get_current_screen') ? get_current_screen() : null;
	if (!$screen || $screen->post_type !== 'agm_attendee') {
		return;
	}

	$allowed_params = ['m', 'post_status', 's', 'orderby', 'order'];
	$query_args     = ['action' => 'agm_attendees_export'];

	foreach ($allowed_params as $param) {
		if (!isset($_GET[$param])) {
			continue;
		}

		$value = sanitize_text_field(wp_unslash($_GET[$param]));
		if ($value !== '') {
			$query_args[$param] = $value;
		}
	}

	$query_args['_wpnonce'] = wp_create_nonce('agm_attendees_export');

	$export_url = add_query_arg($query_args, admin_url('admin-post.php'));
	$button_label = __('Export to Excel', 'watf');
?>
	<script>
		document.addEventListener('DOMContentLoaded', function() {
			var exportLink = document.createElement('a');
			exportLink.className = 'button button-primary';
			exportLink.href = <?php echo wp_json_encode($export_url); ?>;
			exportLink.textContent = <?php echo wp_json_encode($button_label); ?>;
			exportLink.style.marginLeft = '6px';

			var filterButton = document.querySelector('.tablenav.top .actions input[name="filter_action"]');
			if (filterButton) {
				filterButton.insertAdjacentElement('afterend', exportLink);
				return;
			}

			var actions = document.querySelector('.tablenav.top .actions');
			if (actions) {
				actions.appendChild(exportLink);
				return;
			}

			var heading = document.querySelector('.wrap h1.wp-heading-inline');
			if (!heading) {
				return;
			}

			var firstAction = document.querySelector('.wrap .page-title-action');
			if (firstAction) {
				firstAction.insertAdjacentElement('afterend', exportLink);
				return;
			}

			exportLink.className = 'page-title-action';
			exportLink.style.marginLeft = '';
			heading.insertAdjacentElement('afterend', exportLink);
		});
	</script>
<?php
});

add_action('admin_head-edit.php', function () {
	$screen = function_exists('get_current_screen') ? get_current_screen() : null;
	if (!$screen || $screen->post_type !== 'agm_sponsorship') {
		return;
	}

	$allowed_params = ['m', 'post_status', 's', 'orderby', 'order'];
	$query_args     = ['action' => 'agm_sponsorship_export'];

	foreach ($allowed_params as $param) {
		if (!isset($_GET[$param])) {
			continue;
		}

		$value = sanitize_text_field(wp_unslash($_GET[$param]));
		if ($value !== '') {
			$query_args[$param] = $value;
		}
	}

	$query_args['_wpnonce'] = wp_create_nonce('agm_sponsorship_export');

	$export_url = add_query_arg($query_args, admin_url('admin-post.php'));
	$button_label = __('Export Sponsorships', 'watf');
?>
	<script>
		document.addEventListener('DOMContentLoaded', function() {
			var exportLink = document.createElement('a');
			exportLink.className = 'button button-primary';
			exportLink.href = <?php echo wp_json_encode($export_url); ?>;
			exportLink.textContent = <?php echo wp_json_encode($button_label); ?>;
			exportLink.style.marginLeft = '6px';

			var filterButton = document.querySelector('.tablenav.top .actions input[name="filter_action"]');
			if (filterButton) {
				filterButton.insertAdjacentElement('afterend', exportLink);
			} else {
				var actions = document.querySelector('.tablenav.top .actions');
				if (actions) {
					actions.appendChild(exportLink);
				} else {
					var heading = document.querySelector('.wrap h1.wp-heading-inline');
					if (heading) {
						var firstAction = document.querySelector('.wrap .page-title-action');
						if (firstAction) {
							firstAction.insertAdjacentElement('afterend', exportLink);
						} else {
							exportLink.className = 'page-title-action';
							exportLink.style.marginLeft = '';
							heading.insertAdjacentElement('afterend', exportLink);
						}
					}
				}
			}
		});
	</script>
<?php
});

add_action('admin_post_agm_attendees_export', function () {
	if (!current_user_can('edit_posts')) {
		wp_die(__('You do not have permission to export attendees.', 'watf'));
	}

	if (!isset($_REQUEST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])), 'agm_attendees_export')) {
		wp_die(__('The export link has expired. Please reload the page and try again.', 'watf'));
	}

	$filename = 'agm-attendees-' . gmdate('Y-m-d') . '.csv';

	$filters = [];
	$allowed_params = ['m', 'post_status', 's', 'orderby', 'order'];
	foreach ($allowed_params as $param) {
		if (isset($_GET[$param])) {
			$filters[$param] = sanitize_text_field(wp_unslash($_GET[$param]));
		}
	}

	$args = [
		'post_type'      => 'agm_attendee',
		'post_status'    => ['publish', 'draft', 'pending', 'private', 'future'],
		'posts_per_page' => -1,
		'orderby'        => 'date',
		'order'          => 'ASC',
		'fields'         => 'ids',
	];

	if (!empty($filters['post_status']) && $filters['post_status'] !== 'all') {
		$args['post_status'] = $filters['post_status'];
	}

	if (!empty($filters['s'])) {
		$args['s'] = $filters['s'];
	}

	if (!empty($filters['orderby'])) {
		$allowed_orderby = ['date', 'title', 'modified'];
		if (in_array($filters['orderby'], $allowed_orderby, true)) {
			$args['orderby'] = $filters['orderby'];
		}
	}

	if (!empty($filters['order'])) {
		$order = strtoupper($filters['order']);
		if (in_array($order, ['ASC', 'DESC'], true)) {
			$args['order'] = $order;
		}
	}

	if (!empty($filters['m']) && preg_match('/^(\\d{4})(\\d{2})?$/', $filters['m'], $matches)) {
		$year  = (int) $matches[1];
		$month = isset($matches[2]) ? (int) $matches[2] : 0;

		if ($year >= 1970 && $year <= 2100) {
			$date_query = ['year' => $year];
			if ($month >= 1 && $month <= 12) {
				$date_query['monthnum'] = $month;
			}
			$args['date_query'] = [$date_query];
		}
	}

	$attendee_ids = get_posts($args);

	if (!is_array($attendee_ids)) {
		$attendee_ids = [];
	}

	nocache_headers();
	header('Content-Type: text/csv; charset=UTF-8');
	header('Content-Disposition: attachment; filename="' . $filename . '"');

	$output = fopen('php://output', 'w');
	if (!$output) {
		wp_die(__('Unable to open output stream.', 'watf'));
	}

	fwrite($output, "\xEF\xBB\xBF");

	$columns = [
		'id'             => __('Record ID', 'watf'),
		'submitted_at'   => __('Submitted At', 'watf'),
		'prefix'         => __('Prefix', 'watf'),
		'first_name'     => __('First Name', 'watf'),
		'last_name'      => __('Last Name', 'watf'),
		'title'          => __('Title', 'watf'),
		'organization'   => __('Organization', 'watf'),
		'badge_name'     => __('Badge Name', 'watf'),
		'street'         => __('Street', 'watf'),
		'city'           => __('City', 'watf'),
		'state'          => __('State', 'watf'),
		'zip'            => __('Zip', 'watf'),
		'phone'          => __('Phone', 'watf'),
		'email'          => __('Email', 'watf'),
		'attendee_type'  => __('Attendee Type', 'watf'),
		'promo_code'     => __('Promo Code', 'watf'),
		'special_info'   => __('Special Accommodations, Dietary Restrictions, and Additional Information', 'watf'),
		'is_primary'     => __('Primary Registrant', 'watf'),
		'added_by'       => __('Added By', 'watf'),
		'group_id'       => __('Registration Group ID', 'watf'),
		// 'group_position' => __('Group Position', 'watf'),
		// 'group_total'    => __('Group Total', 'watf'),
	];

	fputcsv($output, array_values($columns));

	$type_labels = agm_attendee_type_labels();

	foreach ($attendee_ids as $attendee_id) {
		$group_id = (int) get_post_meta($attendee_id, 'registration_group', true);
		$is_primary = (int) get_post_meta($attendee_id, 'is_primary', true) === 1;
		$group_total = (int) get_post_meta($attendee_id, 'group_total', true);
		$group_position = (int) get_post_meta($attendee_id, 'group_position', true);

		$added_by = __('N/A', 'watf');
		if ($group_id && $group_id !== (int) $attendee_id) {
			$primary_first = get_post_meta($group_id, 'first_name', true);
			$primary_last = get_post_meta($group_id, 'last_name', true);
			$primary_name = trim($primary_first . ' ' . $primary_last);
			$added_by = $primary_name !== '' ? $primary_name : get_the_title($group_id);
		} elseif ($group_id === (int) $attendee_id) {
			$added_by = __('Primary registrant', 'watf');
		}

		$data = [];
		foreach ($columns as $key => $label) {
			switch ($key) {
				case 'id':
					$value = $attendee_id;
					break;
				case 'submitted_at':
					$value = get_post_time('Y-m-d H:i:s', false, $attendee_id);
					break;
				case 'attendee_type':
					$raw = get_post_meta($attendee_id, 'attendee_type', true);
					$normalized = strtolower((string) $raw);
					$value = $type_labels[$normalized] ?? ucwords(str_replace(['-', '_'], [' ', ' '], $normalized));
					break;
				case 'special_info':
					$value = get_post_meta($attendee_id, 'special_info', true);
					$value = $value !== '' ? preg_replace("/\r\n|\r/", "\n", $value) : '';
					break;
				case 'is_primary':
					$value = $is_primary ? __('Yes', 'watf') : __('No', 'watf');
					break;
				case 'added_by':
					$value = $added_by;
					break;
				case 'group_id':
					$value = $group_id ?: '';
					break;
				case 'group_total':
					$value = $group_total ?: '';
					break;
				case 'group_position':
					$value = $group_position ?: '';
					break;
				default:
					$value = get_post_meta($attendee_id, $key, true);
					break;
			}

			if (is_string($value)) {
				$value = trim($value);
			}

			$data[] = $value;
		}

		fputcsv($output, $data);
	}

	fclose($output);
	exit;
});

add_action('admin_post_agm_sponsorship_export', function () {
	if (!current_user_can('edit_posts')) {
		wp_die(__('You do not have permission to export sponsorships.', 'watf'));
	}

	if (!isset($_REQUEST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])), 'agm_sponsorship_export')) {
		wp_die(__('The export link has expired. Please reload the page and try again.', 'watf'));
	}

	$filename = 'agm-sponsorships-' . gmdate('Y-m-d') . '.xlsx';

	$filters = [];
	$allowed_params = ['m', 'post_status', 's', 'orderby', 'order'];
	foreach ($allowed_params as $param) {
		if (isset($_GET[$param])) {
			$filters[$param] = sanitize_text_field(wp_unslash($_GET[$param]));
		}
	}

	$args = [
		'post_type'      => 'agm_sponsorship',
		'post_status'    => ['publish', 'draft', 'pending', 'private', 'future'],
		'posts_per_page' => -1,
		'orderby'        => 'date',
		'order'          => 'DESC',
		'fields'         => 'ids',
	];

	if (!empty($filters['post_status']) && $filters['post_status'] !== 'all') {
		$args['post_status'] = $filters['post_status'];
	}

	if (!empty($filters['s'])) {
		$args['s'] = $filters['s'];
	}

	if (!empty($filters['orderby'])) {
		$allowed_orderby = ['date', 'title', 'modified'];
		if (in_array($filters['orderby'], $allowed_orderby, true)) {
			$args['orderby'] = $filters['orderby'];
		}
	}

	if (!empty($filters['order'])) {
		$order = strtoupper($filters['order']);
		if (in_array($order, ['ASC', 'DESC'], true)) {
			$args['order'] = $order;
		}
	}

	if (!empty($filters['m']) && preg_match('/^(\\d{4})(\\d{2})?$/', $filters['m'], $matches)) {
		$year  = (int) $matches[1];
		$month = isset($matches[2]) ? (int) $matches[2] : 0;

		if ($year >= 1970 && $year <= 2100) {
			$date_query = ['year' => $year];
			if ($month >= 1 && $month <= 12) {
				$date_query['monthnum'] = $month;
			}
			$args['date_query'][] = $date_query;
		}
	}

	$sponsorship_ids = get_posts($args);

	if (!is_array($sponsorship_ids)) {
		$sponsorship_ids = [];
	}

	$sponsorship_columns = [
		'submitted_at'           => __('Submitted At', 'watf'),
		'sponsor_level'          => __('Sponsor Level', 'watf'),
		'sponsor_name'           => __('Sponsor Name', 'watf'),
		'organization'           => __('Organization', 'watf'),
		'prefix'                 => __('Prefix', 'watf'),
		'first_name'             => __('First Name', 'watf'),
		'last_name'              => __('Last Name', 'watf'),
		'title'                  => __('Title', 'watf'),
		'street'                 => __('Street', 'watf'),
		'city'                   => __('City', 'watf'),
		'state'                  => __('State', 'watf'),
		'zip'                    => __('Zip', 'watf'),
		'phone'                  => __('Phone', 'watf'),
		'email'                  => __('Email', 'watf'),
		'invoice_requested'      => __('Invoice Requested', 'watf'),
		'paying_by_check'        => __('Paying by Check', 'watf'),
		'additional_information' => __('Additional Information', 'watf'),
		'attendee_count'         => __('Attendee Count', 'watf'),
	];

	$attendee_columns = [
		'sponsor_name'          => __('Sponsor Name', 'watf'),
		'sponsor_level'         => __('Sponsor Level', 'watf'),
		'attendee_promo_code'   => __('Promo Code', 'watf'),
		'attendee_prefix'       => __('Prefix', 'watf'),
		'attendee_first_name'   => __('First Name', 'watf'),
		'attendee_last_name'    => __('Last Name', 'watf'),
		'attendee_title'        => __('Title', 'watf'),
		'attendee_organization' => __('Organization', 'watf'),
		'attendee_badge_name'   => __('Badge Name', 'watf'),
		'attendee_street'       => __('Street', 'watf'),
		'attendee_city'         => __('City', 'watf'),
		'attendee_state'        => __('State', 'watf'),
		'attendee_zip'          => __('Zip', 'watf'),
		'attendee_phone'        => __('Phone', 'watf'),
		'attendee_email'        => __('Email', 'watf'),
		'attendee_special_info' => __('Special Accommodations, Dietary Restrictions, and Additional Information', 'watf'),
	];

	$sponsorship_rows = [array_values($sponsorship_columns)];
	$attendee_rows    = [array_values($attendee_columns)];

	$levels = apply_filters(
		'watf_agm_sponsorship_levels',
		[
			''         => __('Select', 'watf'),
			'premier'  => __('Premier Sponsor', 'watf'),
			'platinum' => __('Platinum Sponsor', 'watf'),
			'gold'     => __('Gold Sponsor', 'watf'),
			'silver'   => __('Silver Sponsor', 'watf'),
			'bronze'   => __('Bronze Sponsor', 'watf'),
		]
	);

	$states_lookup = function_exists('agm_us_states_list') ? agm_us_states_list() : [];

	$attendee_fetcher = static function ($sponsorship_id) {
		$post_type = defined('WATF_SPONSOR_ATTENDEE_CPT') ? WATF_SPONSOR_ATTENDEE_CPT : 'agm_sponsor_att';

		$attendee_ids = get_post_meta($sponsorship_id, 'sponsorship_attendee_ids', true);
		$query_args = [
			'post_type'      => $post_type,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		];

		if (is_array($attendee_ids) && !empty($attendee_ids)) {
			$attendee_ids = array_map('intval', $attendee_ids);
			$query_args['post__in'] = $attendee_ids;
			$query_args['orderby']  = 'post__in';
		} else {
			$query_args['meta_key']   = 'sponsorship_post_id';
			$query_args['meta_value'] = $sponsorship_id;
			$query_args['orderby']    = 'date';
			$query_args['order']      = 'ASC';
		}

		$posts = get_posts($query_args);

		if (empty($posts)) {
			return [];
		}

		$attendees = [];
		foreach ($posts as $attendee_post) {
			$first = get_post_meta($attendee_post->ID, 'first_name', true);
			$last  = get_post_meta($attendee_post->ID, 'last_name', true);
			$attendees[] = [
				'id'           => (int) $attendee_post->ID,
				'first_name'   => $first,
				'last_name'    => $last,
				'name'         => trim(implode(' ', array_filter([$first, $last]))),
				'title'        => get_post_meta($attendee_post->ID, 'title', true),
				'organization' => get_post_meta($attendee_post->ID, 'organization', true),
				'email'        => get_post_meta($attendee_post->ID, 'email', true),
				'promo_code'   => get_post_meta($attendee_post->ID, 'promo_code', true),
				'prefix'       => get_post_meta($attendee_post->ID, 'prefix', true),
				'badge_name'   => get_post_meta($attendee_post->ID, 'badge_name', true),
				'street'       => get_post_meta($attendee_post->ID, 'street', true),
				'city'         => get_post_meta($attendee_post->ID, 'city', true),
				'state'        => get_post_meta($attendee_post->ID, 'state', true),
				'zip'          => get_post_meta($attendee_post->ID, 'zip', true),
				'phone'        => get_post_meta($attendee_post->ID, 'phone', true),
				'special_info' => get_post_meta($attendee_post->ID, 'special_info', true),
			];
		}

		return $attendees;
	};

	foreach ($sponsorship_ids as $sponsorship_id) {
		$attendees = $attendee_fetcher($sponsorship_id);
		$attendee_total = is_array($attendees) ? count($attendees) : 0;
		$sponsor_row = [];

		foreach ($sponsorship_columns as $key => $label) {
			switch ($key) {
				case 'submitted_at':
					$value = get_post_time('Y-m-d H:i:s', false, $sponsorship_id);
					break;
				case 'sponsor_level':
					$raw_level = get_post_meta($sponsorship_id, 'sponsor_level', true);
					$value = $levels[$raw_level] ?? ucwords(str_replace(['-', '_'], [' ', ' '], (string) $raw_level));
					break;
				case 'state':
					$state_value = get_post_meta($sponsorship_id, 'state', true);
					$value = $states_lookup[$state_value] ?? strtoupper((string) $state_value);
					break;
				case 'invoice_requested':
				case 'paying_by_check':
					$raw = get_post_meta($sponsorship_id, $key, true);
					$value = $raw === 'yes' ? __('Yes', 'watf') : __('No', 'watf');
					break;
				case 'additional_information':
					$raw = get_post_meta($sponsorship_id, $key, true);
					$value = $raw !== '' ? preg_replace("/\r\n|\r/", "\n", $raw) : '';
					break;
				case 'attendee_count':
					$value = $attendee_total;
					break;
				default:
					$value = get_post_meta($sponsorship_id, $key, true);
					break;
			}

			if (is_string($value)) {
				$value = trim($value);
			}

			$sponsor_row[] = $value;
		}

		$sponsorship_rows[] = $sponsor_row;

		foreach ($attendees as $attendee_data) {
			$row = [];

			foreach ($attendee_columns as $key => $label) {
				switch ($key) {
					case 'sponsor_name':
						$value = get_post_meta($sponsorship_id, 'sponsor_name', true);
						break;
					case 'sponsor_level':
						$raw_level = get_post_meta($sponsorship_id, 'sponsor_level', true);
						$value = $levels[$raw_level] ?? ucwords(str_replace(['-', '_'], [' ', ' '], (string) $raw_level));
						break;
					case 'state':
						$state_value = get_post_meta($sponsorship_id, 'state', true);
						$value = $states_lookup[$state_value] ?? strtoupper((string) $state_value);
						break;
					case 'attendee_state':
						$state_value = $attendee_data['state'];
						$value = $states_lookup[$state_value] ?? strtoupper((string) $state_value);
						break;
					case 'attendee_special_info':
						$raw = $attendee_data['special_info'];
						$value = $raw !== '' ? preg_replace("/\r\n|\r/", "\n", $raw) : '';
						break;
					case 'attendee_first_name':
						$value = $attendee_data['first_name'];
						break;
					case 'attendee_last_name':
						$value = $attendee_data['last_name'];
						break;
					default:
						if (strpos($key, 'attendee_') === 0) {
							$field = substr($key, strlen('attendee_'));
							$value = $attendee_data[$field] ?? '';
						} else {
							$value = get_post_meta($sponsorship_id, $key, true);
						}
						break;
				}

				if (is_string($value)) {
					$value = trim($value);
				}

				$row[] = $value;
			}

			$attendee_rows[] = $row;
		}
	}

	$sheets = [
		[
			'name' => 'Sponsors',
			'rows' => $sponsorship_rows,
		],
		[
			'name' => 'Attendees',
			'rows' => $attendee_rows,
		],
	];

	$xlsx = watf_generate_simple_xlsx($sheets);

	if ($xlsx === '') {
		wp_die(__('Unable to generate Excel export.', 'watf'));
	}

	nocache_headers();
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header('Content-Disposition: attachment; filename="' . $filename . '"');
	header('Content-Length: ' . strlen($xlsx));
	echo $xlsx; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	exit;
});

if (!function_exists('watf_generate_simple_xlsx')) {
	/**
	 * Build a minimal XLSX workbook with the provided sheets.
	 *
	 * @param array<int, array{name:string, rows:array<int, array<int|string, string>>}> $sheets
	 */
	function watf_generate_simple_xlsx(array $sheets)
	{
		if (empty($sheets) || !class_exists('ZipArchive')) {
			return '';
		}

		$tmp = wp_tempnam('watf-xlsx');
		if (!$tmp) {
			return '';
		}

		$zip = new ZipArchive();
		if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
			return '';
		}

		$sheet_overrides = [];
		$sheet_entries   = [];
		$relationship_nodes = [];
		$sheet_index = 1;
		foreach ($sheets as $sheet) {
			$name = isset($sheet['name']) ? $sheet['name'] : 'Sheet' . $sheet_index;
			$sanitized_name = watf_xlsx_sanitize_sheet_name($name);
			$rows = isset($sheet['rows']) && is_array($sheet['rows']) ? $sheet['rows'] : [];
			if (empty($rows)) {
				$rows = [[]];
			}

			$sheet_xml = watf_xlsx_build_sheet_xml($rows);
			$sheet_path = 'xl/worksheets/sheet' . $sheet_index . '.xml';
			$zip->addFromString($sheet_path, $sheet_xml);

			$sheet_overrides[] = '<Override PartName="/' . $sheet_path . '" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
			$sheet_entries[]   = '<sheet name="' . esc_attr($sanitized_name) . '" sheetId="' . $sheet_index . '" r:id="rId' . $sheet_index . '"/>';
			$relationship_nodes[] = '<Relationship Id="rId' . $sheet_index . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $sheet_index . '.xml"/>';

			$sheet_index++;
		}

		$styles_id = 'rId' . $sheet_index;
		$relationship_nodes[] = '<Relationship Id="' . $styles_id . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';

		$workbook_xml = '<?xml version="1.0" encoding="UTF-8"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
			. 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheets>' . implode('', $sheet_entries) . '</sheets>'
			. '</workbook>';
		$zip->addFromString('xl/workbook.xml', $workbook_xml);

		$workbook_rels = '<?xml version="1.0" encoding="UTF-8"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. implode('', $relationship_nodes)
			. '</Relationships>';
		$zip->addFromString('xl/_rels/workbook.xml.rels', $workbook_rels);

		$styles_xml = '<?xml version="1.0" encoding="UTF-8"?>'
			. '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<fonts count="1"><font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/></font></fonts>'
			. '<fills count="1"><fill><patternFill patternType="none"/></fill></fills>'
			. '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
			. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
			. '<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellXfs>'
			. '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
			. '</styleSheet>';
		$zip->addFromString('xl/styles.xml', $styles_xml);

		$core_props = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
			. 'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
			. 'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
			. '<dc:creator>WordPress</dc:creator>'
			. '<cp:lastModifiedBy>WordPress</cp:lastModifiedBy>'
			. '<dcterms:created xsi:type="dcterms:W3CDTF">' . gmdate('Y-m-d\TH:i:s\Z') . '</dcterms:created>'
			. '<dcterms:modified xsi:type="dcterms:W3CDTF">' . gmdate('Y-m-d\TH:i:s\Z') . '</dcterms:modified>'
			. '</cp:coreProperties>';
		$zip->addFromString('docProps/core.xml', $core_props);

		$app_props = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
			. 'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
			. '<Application>WordPress</Application>'
			. '<Sheets>' . count($sheets) . '</Sheets>'
			. '</Properties>';
		$zip->addFromString('docProps/app.xml', $app_props);

		$root_rels = '<?xml version="1.0" encoding="UTF-8"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
			. '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
			. '</Relationships>';
		$zip->addFromString('_rels/.rels', $root_rels);

		$content_types = '<?xml version="1.0" encoding="UTF-8"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
			. '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
			. '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
			. implode('', $sheet_overrides)
			. '</Types>';
		$zip->addFromString('[Content_Types].xml', $content_types);

		$zip->close();

		$data = file_get_contents($tmp);
		@unlink($tmp);

		return $data !== false ? $data : '';
	}

	function watf_xlsx_build_sheet_xml(array $rows)
	{
		$xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">', '<sheetData>'];
		$row_index = 1;
		foreach ($rows as $row) {
			if (!is_array($row)) {
				$row = [(string) $row];
			}
			$xml[] = '<row r="' . $row_index . '">';
			$col_index = 1;
			foreach ($row as $cell) {
				if ($cell === '' || $cell === null) {
					$col_index++;
					continue;
				}
				$cell_ref = watf_xlsx_column_letter($col_index) . $row_index;
				$value = watf_xlsx_escape((string) $cell);
				$xml[] = '<c r="' . $cell_ref . '" t="inlineStr"><is><t xml:space="preserve">' . $value . '</t></is></c>';
				$col_index++;
			}
			$xml[] = '</row>';
			$row_index++;
		}
		$xml[] = '</sheetData></worksheet>';
		return implode('', $xml);
	}

	function watf_xlsx_column_letter($index)
	{
		$letter = '';
		while ($index > 0) {
			$remainder = ($index - 1) % 26;
			$letter = chr(65 + $remainder) . $letter;
			$index = (int) (($index - $remainder - 1) / 26);
		}
		return $letter;
	}

	function watf_xlsx_escape($value)
	{
		$value = htmlspecialchars($value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
		return str_replace(["\r\n", "\r", "\n"], '&#10;', $value);
	}

	function watf_xlsx_sanitize_sheet_name($name)
	{
		$name = preg_replace('/[\[\]\*\/\\\\\:\?]/', '', $name);
		$name = trim((string) $name);
		if ($name === '') {
			$name = 'Sheet1';
		}
		if (strlen($name) > 31) {
			$name = substr($name, 0, 31);
		}
		return $name;
	}
}

/**
 * 3) (Optional) Admin list columns
 */
add_filter('manage_agm_attendee_posts_columns', function ($cols) {
	unset($cols['date']);
	$cols['name']  = 'Name';
	$cols['email'] = 'Email';
	$cols['org']   = 'Organization';
	$cols['added_by'] = 'Added By';
	$cols['date']  = 'Date';
	return $cols;
});

add_action('manage_agm_attendee_posts_custom_column', function ($col, $post_id) {
	if ($col === 'name') {
		$first = get_post_meta($post_id, 'first_name', true);
		$last  = get_post_meta($post_id, 'last_name', true);
		echo esc_html(trim($first . ' ' . $last));
	} elseif ($col === 'email') {
		$email = get_post_meta($post_id, 'email', true);
		if ($email) echo '<a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a>';
	} elseif ($col === 'org') {
		echo esc_html(get_post_meta($post_id, 'organization', true));
	} elseif ($col === 'added_by') {
		$group_id = (int) get_post_meta($post_id, 'registration_group', true);
		if ($group_id && $group_id !== (int) $post_id) {
			$first = get_post_meta($group_id, 'first_name', true);
			$last  = get_post_meta($group_id, 'last_name', true);
			$name  = trim($first . ' ' . $last);
			echo esc_html($name !== '' ? $name : get_the_title($group_id));
		} elseif ($group_id === (int) $post_id) {
			echo '<span class="description">Primary registrant</span>';
		} else {
			echo '<span class="description">N/A</span>';
		}
	}
}, 10, 2);

add_filter('views_edit-agm_attendee', function ($views) {
	if (isset($views['mine'])) {
		unset($views['mine']);
	}

	return $views;
});
register_post_meta('agm_attendee', 'first_name', ['show_in_rest' => true, 'type' => 'string', 'single' => true, 'auth_callback' => '__return_true']);
/* repeat for other keys if needed */

add_filter('post_row_actions', function ($actions, $post) {
	if ($post->post_type !== 'agm_attendee') {
		return $actions;
	}

	$new_actions = [];
	$view_link   = get_edit_post_link($post->ID, '');

	if ($view_link) {
		$new_actions['view'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url($view_link),
			esc_html__('View', 'watf')
		);
	}

	if (isset($actions['trash'])) {
		$new_actions['trash'] = $actions['trash'];
	}

	return $new_actions;
}, 10, 2);

add_action('add_meta_boxes', function ($post_type, $post) {
	if ($post_type === 'agm_attendee') {
		remove_meta_box('submitdiv', 'agm_attendee', 'side');
	}
}, 10, 2);

add_action('admin_print_footer_scripts', function () {
	$screen = function_exists('get_current_screen') ? get_current_screen() : null;
	if (!$screen || $screen->base !== 'post' || $screen->post_type !== 'agm_attendee') {
		return;
	} ?>
	<script>
		document.addEventListener('DOMContentLoaded', function() {
			var selectors = '#poststuff input:not([type="hidden"]):not([type="submit"]):not([type="button"]), #poststuff select, #poststuff textarea, #titlewrap input';
			document.querySelectorAll(selectors).forEach(function(field) {
				field.setAttribute('disabled', 'disabled');
				field.classList.add('agm-attendee-readonly');
			});

			var backButton = document.querySelector('.wrap .page-title-action');
			if (backButton) {
				backButton.textContent = '<?php echo esc_js(__('Back to AGM Attendees', 'watf')); ?>';
				backButton.setAttribute('href', '<?php echo esc_url(admin_url('edit.php?post_type=agm_attendee')); ?>');
			}
		});
	</script>
	<style>
		#titlewrap input.agm-attendee-readonly,
		#poststuff .agm-attendee-readonly {
			background-color: #f6f6f6;
			color: #555;
			cursor: not-allowed;
			pointer-events: none;
		}
	</style>
<?php
});

add_action('init', function () {
	register_post_type('agm_sponsorship', [
		'label'           => __('AGM Sponsorships', 'watf'),
		'labels'          => [
			'singular_name'  => __('AGM Sponsorship', 'watf'),
			'menu_name'      => __('AGM Sponsorships', 'watf'),
			'name_admin_bar' => __('AGM Sponsorship', 'watf'),
			'add_new'        => '',
			'add_new_item'   => '',
			'edit_item'      => __('Sponsorship Details', 'watf'),
			'view_item'      => __('View Sponsorship', 'watf'),
			'all_items'      => __('AGM Sponsorships', 'watf'),
			'back_to_items'  => __('← Back to AGM Sponsorships', 'watf'),
		],
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'supports'        => ['title'],
		'capability_type' => 'post',
		'map_meta_cap'    => true,
		'capabilities'    => [
			'create_posts' => 'do_not_allow',
		],
		'menu_position'   => 26,
		'menu_icon'       => 'dashicons-awards',
	]);
});

add_action('add_meta_boxes', function () {
	add_meta_box(
		'agm_sponsorship_details',
		__('Sponsorship Details', 'watf'),
		'watf_agm_sponsorship_details_metabox_cb',
		'agm_sponsorship',
		'normal',
		'default'
	);
});

function watf_agm_sponsorship_details_metabox_cb($post)
{
	$get_meta = static function ($key, $default = '') use ($post) {
		$val = get_post_meta($post->ID, $key, true);
		return $val !== '' ? $val : $default;
	};

	$levels = apply_filters(
		'watf_agm_sponsorship_levels',
		[
			''         => __('Select', 'watf'),
			'premier'  => __('Premier Sponsor', 'watf'),
			'platinum' => __('Platinum Sponsor', 'watf'),
			'gold'     => __('Gold Sponsor', 'watf'),
			'silver'   => __('Silver Sponsor', 'watf'),
			'bronze'   => __('Bronze Sponsor', 'watf'),
		]
	);

	$level_key   = $get_meta('sponsor_level');
	$level_label = $levels[$level_key] ?? ucwords(str_replace(['-', '_'], [' ', ' '], $level_key));

	$states_lookup = function_exists('agm_us_states_list') ? agm_us_states_list() : [];
	$state_value   = $get_meta('state');
	$state_display = $states_lookup[$state_value] ?? $state_value;

	$invoice_requested = $get_meta('invoice_requested') === 'yes' ? __('Yes', 'watf') : __('No', 'watf');
	$paying_by_check   = $get_meta('paying_by_check') === 'yes' ? __('Yes', 'watf') : __('No', 'watf');
	$additional_info   = $get_meta('additional_information');

	$field_rows = [
		[
			'key'   => 'sponsor_level',
			'label' => __('Sponsor Level', 'watf'),
			'value' => $level_label,
		],
		[
			'key'   => 'sponsor_name',
			'label' => __('Sponsor Name', 'watf'),
			'value' => $get_meta('sponsor_name'),
		],
		[
			'key'   => 'organization',
			'label' => __('Organization', 'watf'),
			'value' => $get_meta('organization'),
		],
		[
			'key'   => 'prefix',
			'label' => __('Prefix', 'watf'),
			'value' => $get_meta('prefix'),
		],
		[
			'key'   => 'first_name',
			'label' => __('First Name', 'watf'),
			'value' => $get_meta('first_name'),
		],
		[
			'key'   => 'last_name',
			'label' => __('Last Name', 'watf'),
			'value' => $get_meta('last_name'),
		],
		[
			'key'   => 'title',
			'label' => __('Title', 'watf'),
			'value' => $get_meta('title'),
		],
		[
			'key'   => 'street',
			'label' => __('Street', 'watf'),
			'value' => $get_meta('street'),
		],
		[
			'key'   => 'city',
			'label' => __('City', 'watf'),
			'value' => $get_meta('city'),
		],
		[
			'key'   => 'state',
			'label' => __('State', 'watf'),
			'value' => $state_display,
		],
		[
			'key'   => 'zip',
			'label' => __('Zip', 'watf'),
			'value' => $get_meta('zip'),
		],
		[
			'key'   => 'phone',
			'label' => __('Phone', 'watf'),
			'value' => $get_meta('phone'),
		],
		[
			'key'   => 'email',
			'label' => __('Email', 'watf'),
			'value' => $get_meta('email'),
		],
		[
			'key'   => 'invoice_requested',
			'label' => __('Would you like an invoice?', 'watf'),
			'value' => $invoice_requested,
		],
		[
			'key'   => 'paying_by_check',
			'label' => __('Paying by Check?', 'watf'),
			'value' => $paying_by_check,
		],
		[
			'key'   => 'additional_information',
			'label' => __('Additional Information', 'watf'),
			'value' => $additional_info,
		],
	];
?>
	<table class="widefat striped">
		<tbody>
			<?php foreach ($field_rows as $row) :
				$value = $row['value'];
				$key   = $row['key'];

				if ($key === 'email') {
					if ($value) {
						$value_markup = sprintf('<a href="mailto:%1$s">%2$s</a>', esc_attr($value), esc_html($value));
					} else {
						$value_markup = '<span class="description">' . esc_html__('N/A', 'watf') . '</span>';
					}
				} elseif ($key === 'additional_information') {
					$value_markup = $value !== '' ? nl2br(esc_html($value)) : '<span class="description">' . esc_html__('None provided.', 'watf') . '</span>';
				} else {
					$value_markup = $value !== '' ? esc_html($value) : '<span class="description">' . esc_html__('N/A', 'watf') . '</span>';
				}
			?>
				<tr>
					<th scope="row"><?php echo esc_html($row['label']); ?></th>
					<td><?php echo $value_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
						?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<?php
	$attendee_ids = get_post_meta($post->ID, 'sponsorship_attendee_ids', true);
	if (!is_array($attendee_ids)) {
		$attendee_ids = [];
	}
	$attendee_query_args = [
		'post_type'      => WATF_SPONSOR_ATTENDEE_CPT,
		'post_status'    => 'publish',
		'posts_per_page' => -1,
	];

	if (!empty($attendee_ids)) {
		$attendee_query_args['post__in'] = $attendee_ids;
		$attendee_query_args['orderby']  = 'post__in';
	} else {
		$attendee_query_args['meta_key']   = 'sponsorship_post_id';
		$attendee_query_args['meta_value'] = $post->ID;
	}

	$attendee_posts = get_posts($attendee_query_args);
	?>
	<h3 class="mt-4"><?php esc_html_e('Attendees', 'watf'); ?></h3>
	<?php if (empty($attendee_posts)) : ?>
		<p class="description"><?php esc_html_e('No attendees have been submitted for this sponsorship yet.', 'watf'); ?></p>
	<?php else : ?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e('Name', 'watf'); ?></th>
					<th><?php esc_html_e('Title / Organization', 'watf'); ?></th>
					<th><?php esc_html_e('Email', 'watf'); ?></th>
					<th><?php esc_html_e('Promo Code', 'watf'); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($attendee_posts as $attendee) :
					$first  = get_post_meta($attendee->ID, 'first_name', true);
					$last   = get_post_meta($attendee->ID, 'last_name', true);
					$name   = trim($first . ' ' . $last);
					$title  = get_post_meta($attendee->ID, 'title', true);
					$org    = get_post_meta($attendee->ID, 'organization', true);
					$email  = get_post_meta($attendee->ID, 'email', true);
					$promo  = get_post_meta($attendee->ID, 'promo_code', true);
				?>
					<tr>
						<td><?php echo esc_html($name !== '' ? $name : get_the_title($attendee)); ?></td>
						<td>
							<div><?php echo esc_html($title); ?></div>
							<div class="description"><?php echo esc_html($org); ?></div>
						</td>
						<td>
							<?php if ($email) : ?>
								<a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a>
							<?php else : ?>
								<span class="description"><?php esc_html_e('N/A', 'watf'); ?></span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html($promo !== '' ? $promo : __('N/A', 'watf')); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
<?php
}

if (!function_exists('watf_get_agm_sponsorship_attendee_count')) {
	function watf_get_agm_sponsorship_attendee_count($post_id)
	{
		$post_id = intval($post_id);
		if ($post_id <= 0) {
			return 0;
		}

		$attendee_ids = get_post_meta($post_id, 'sponsorship_attendee_ids', true);
		if (is_array($attendee_ids)) {
			return count($attendee_ids);
		}

		$post_type = defined('WATF_SPONSOR_ATTENDEE_CPT') ? WATF_SPONSOR_ATTENDEE_CPT : 'agm_sponsor_att';
		$posts     = get_posts(
			[
				'post_type'   => $post_type,
				'post_status' => 'publish',
				'numberposts' => -1,
				'fields'      => 'ids',
				'meta_key'    => 'sponsorship_post_id',
				'meta_value'  => $post_id,
			]
		);

		return is_array($posts) ? count($posts) : 0;
	}
}

if (!function_exists('watf_get_total_agm_attendee_count')) {
	function watf_get_total_agm_attendee_count()
	{
		$post_ids = get_posts(
			[
				'post_type'   => 'agm_sponsorship',
				'post_status' => 'any',
				'numberposts' => -1,
				'fields'      => 'ids',
			]
		);

		if (!is_array($post_ids) || empty($post_ids)) {
			return 0;
		}

		$total = 0;
		foreach ($post_ids as $id) {
			$total += watf_get_agm_sponsorship_attendee_count($id);
		}

		return $total;
	}
}

add_action('wp_ajax_watf_remove_sponsorship_attendee', 'watf_ajax_remove_sponsorship_attendee');
add_action('wp_ajax_nopriv_watf_remove_sponsorship_attendee', 'watf_ajax_remove_sponsorship_attendee');
function watf_ajax_remove_sponsorship_attendee()
{
	check_ajax_referer('watf_remove_sponsor_attendee', 'nonce');

	$attendee_id = isset($_REQUEST['attendee_id']) ? intval($_REQUEST['attendee_id']) : 0;
	$sponsor_ref = isset($_REQUEST['sponsor_ref']) ? sanitize_text_field(wp_unslash($_REQUEST['sponsor_ref'])) : '';

	if ($attendee_id <= 0 || $sponsor_ref === '' || !function_exists('watf_decode_sponsor_ref')) {
		wp_send_json_error(['message' => __('Invalid request.', 'watf')]);
	}

	$sponsor_id = watf_decode_sponsor_ref($sponsor_ref);
	if ($sponsor_id <= 0) {
		wp_send_json_error(['message' => __('The sponsorship link is invalid.', 'watf')]);
	}

	$sponsor_post = get_post($sponsor_id);
	if (!$sponsor_post || $sponsor_post->post_type !== 'agm_sponsorship') {
		wp_send_json_error(['message' => __('Sponsorship not found.', 'watf')]);
	}

	$attendee_post_type = defined('WATF_SPONSOR_ATTENDEE_CPT') ? WATF_SPONSOR_ATTENDEE_CPT : 'agm_sponsor_att';
	$attendee = get_post($attendee_id);
	if (!$attendee || $attendee->post_type !== $attendee_post_type) {
		wp_send_json_error(['message' => __('Attendee not found.', 'watf')]);
	}

	$registered = intval(get_post_meta($attendee_id, 'sponsorship_post_id', true));
	if ($registered !== $sponsor_id) {
		wp_send_json_error(['message' => __('Attendee does not belong to this sponsorship.', 'watf')]);
	}

	$deleted = wp_delete_post($attendee_id, true);
	if (! $deleted) {
		wp_send_json_error(['message' => __('Unable to remove attendee.', 'watf')]);
	}

	$attendee_ids = get_post_meta($sponsor_id, 'sponsorship_attendee_ids', true);
	if (!is_array($attendee_ids)) {
		$attendee_ids = [];
	}

	$attendee_ids = array_values(array_diff($attendee_ids, [$attendee_id]));
	update_post_meta($sponsor_id, 'sponsorship_attendee_ids', $attendee_ids);

	$remaining = watf_get_agm_sponsorship_attendee_count($sponsor_id);
	$message   = __('You have deleted the attendee.', 'watf');

	wp_send_json_success(['remaining' => $remaining, 'message' => $message]);
}

add_filter('manage_agm_sponsorship_posts_columns', function ($columns) {
	$new_columns = [];
	if (isset($columns['cb'])) {
		$new_columns['cb'] = $columns['cb'];
	}

	$new_columns['title']             = __('Record', 'watf');
	$new_columns['sponsor_level']     = __('Sponsor Level', 'watf');
	$new_columns['organization']      = __('Organization', 'watf');
	$new_columns['contact']           = __('Contact', 'watf');
	$new_columns['email']             = __('Email', 'watf');
	$new_columns['phone']             = __('Phone', 'watf');
	$new_columns['attendee_count']    = __('Attendees', 'watf');
	$new_columns['invoice_requested'] = __('Invoice?', 'watf');
	$new_columns['paying_by_check']   = __('Paying by Check?', 'watf');

	if (isset($columns['date'])) {
		$new_columns['date'] = $columns['date'];
	}

	return $new_columns;
});

add_action('manage_agm_sponsorship_posts_custom_column', function ($column, $post_id) {
	switch ($column) {
		case 'sponsor_level':
			$levels = apply_filters(
				'watf_agm_sponsorship_levels',
				[
					''         => __('Select', 'watf'),
					'premier'  => __('Premier Sponsor', 'watf'),
					'platinum' => __('Platinum Sponsor', 'watf'),
					'gold'     => __('Gold Sponsor', 'watf'),
					'silver'   => __('Silver Sponsor', 'watf'),
					'bronze'   => __('Bronze Sponsor', 'watf'),
				]
			);
			$level = get_post_meta($post_id, 'sponsor_level', true);
			$label = $levels[$level] ?? ucwords(str_replace(['-', '_'], [' ', ' '], $level));
			echo esc_html($label);
			break;
		case 'organization':
			echo esc_html(get_post_meta($post_id, 'organization', true));
			break;
		case 'contact':
			$prefix = get_post_meta($post_id, 'prefix', true);
			$first  = get_post_meta($post_id, 'first_name', true);
			$last   = get_post_meta($post_id, 'last_name', true);
			$name   = trim(implode(' ', array_filter([$prefix, $first, $last])));
			echo esc_html($name);
			break;
		case 'email':
			$email = get_post_meta($post_id, 'email', true);
			if ($email) {
				printf('<a href="mailto:%1$s">%2$s</a>', esc_attr($email), esc_html($email));
			}
			break;
		case 'attendee_count':
			echo esc_html((string) watf_get_agm_sponsorship_attendee_count($post_id));
			break;
		case 'phone':
			echo esc_html(get_post_meta($post_id, 'phone', true));
			break;
		case 'invoice_requested':
			$invoice = get_post_meta($post_id, 'invoice_requested', true) === 'yes' ? __('Yes', 'watf') : __('No', 'watf');
			echo esc_html($invoice);
			break;
		case 'paying_by_check':
			$paying = get_post_meta($post_id, 'paying_by_check', true) === 'yes' ? __('Yes', 'watf') : __('No', 'watf');
			echo esc_html($paying);
			break;
	}
}, 10, 2);

add_action('admin_head-edit.php', function () {
	$screen = function_exists('get_current_screen') ? get_current_screen() : null;
	if (!$screen || $screen->post_type !== 'agm_sponsorship') {
		return;
	}

	$total_attendees = watf_get_total_agm_attendee_count();
	if ($total_attendees <= 0) {
		return;
	}

	$label = sprintf(
		/* translators: %d is the total number of AGM attendees. */
		esc_html__('Total %s attendees registered', 'watf'),
		number_format_i18n($total_attendees)
	);
?>
	<style>
		.wrap .wp-heading-inline,
		.agm-attendee-count {
			display: inline-flex;
			align-items: flex-end;
			vertical-align: baseline;
		}

		.agm-attendee-count {
			margin-left: 0.75rem;
			font-size: 1.2em;
			color: #f10d28ff;
			font-weight: bold;
		}
	</style>
	<script>
		document.addEventListener('DOMContentLoaded', function() {
			const heading = document.querySelector('.wrap .wp-heading-inline');
			if (!heading) {
				return;
			}

			let badge = document.createElement('span');
			badge.className = 'agm-attendee-count';
			badge.textContent = '<?php echo esc_js($label); ?>';
			heading.insertAdjacentElement('afterend', badge);
		});
	</script>
<?php
}, 1);


add_filter('post_row_actions', function ($actions, $post) {
	if ($post->post_type !== 'agm_sponsorship') {
		return $actions;
	}

	$new_actions = [];
	$view_link   = get_edit_post_link($post->ID, '');

	if ($view_link) {
		$new_actions['view'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url($view_link),
			esc_html__('View', 'watf')
		);
	}

	if (isset($actions['trash'])) {
		$new_actions['trash'] = $actions['trash'];
	}

	return $new_actions;
}, 10, 2);

add_action('add_meta_boxes', function ($post_type, $post) {
	if ($post_type === 'agm_sponsorship') {
		remove_meta_box('submitdiv', 'agm_sponsorship', 'side');
	}
}, 10, 2);

add_action('admin_print_footer_scripts', function () {
	$screen = function_exists('get_current_screen') ? get_current_screen() : null;
	if (!$screen || $screen->base !== 'post' || $screen->post_type !== 'agm_sponsorship') {
		return;
	} ?>
	<script>
		document.addEventListener('DOMContentLoaded', function() {
			var selectors = '#poststuff input:not([type="hidden"]):not([type="submit"]):not([type="button"]), #poststuff select, #poststuff textarea, #titlewrap input';
			document.querySelectorAll(selectors).forEach(function(field) {
				field.setAttribute('disabled', 'disabled');
				field.classList.add('agm-sponsorship-readonly');
			});

			var backButton = document.querySelector('.wrap .page-title-action');
			if (backButton) {
				backButton.textContent = '<?php echo esc_js(__('Back to AGM Sponsorships', 'watf')); ?>';
				backButton.setAttribute('href', '<?php echo esc_url(admin_url('edit.php?post_type=agm_sponsorship')); ?>');
			}
		});
	</script>
	<style>
		#titlewrap input.agm-sponsorship-readonly,
		#poststuff .agm-sponsorship-readonly {
			background-color: #f6f6f6;
			color: #555;
			cursor: not-allowed;
			pointer-events: none;
		}
	</style>
<?php
});

/**
 * Allow URLs such as /agm/2025-agm-sponsorship-registration-form/{level}/
 * to map to the attendee registration page and expose the level slug.
 */
function watf_register_sponsorship_attendee_rewrite()
{
	$page = get_page_by_path('agm/2025-agm-sponsorship-registration-form');
	if (!$page) {
		return;
	}

	$permalink = get_permalink($page);
	if (!$permalink) {
		return;
	}

	$path = trim(parse_url($permalink, PHP_URL_PATH) ?? '', '/');
	if ($path === '') {
		return;
	}

	add_rewrite_rule(
		$path . '/([^/]+)/?$',
		'index.php?page_id=' . intval($page->ID) . '&watf_sponsor_level=$matches[1]',
		'top'
	);
}
add_action('init', 'watf_register_sponsorship_attendee_rewrite', 11);

add_filter('query_vars', function ($vars) {
	$vars[] = 'watf_sponsor_level';
	return $vars;
});

// [go_home_button] shortcode
function go_home_button_shortcode()
{
	$home_url = esc_url(home_url('/'));
	return '<a  href="' . $home_url . '" class="button1 mt-5 ">Go Home</a>';
}
add_shortcode('go_home_button', 'go_home_button_shortcode');

if (!function_exists('watf_encode_sponsor_ref')) {
	/**
	 * Encode a sponsorship post ID so it can be shared publicly.
	 */
	function watf_encode_sponsor_ref($post_id)
	{
		$post_id = intval($post_id);
		if ($post_id <= 0) {
			return '';
		}

		$payload = $post_id . '|' . wp_hash($post_id);
		return rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');
	}
}

if (!function_exists('watf_decode_sponsor_ref')) {
	/**
	 * Decode the sponsorship reference and ensure it matches the hash.
	 */
	function watf_decode_sponsor_ref($token)
	{
		if (!is_string($token) || $token === '') {
			return 0;
		}

		$decoded = base64_decode(strtr($token, '-_', '+/'));
		if (!$decoded) {
			return 0;
		}
		$parts = explode('|', $decoded, 2);
		$post_id = intval($parts[0] ?? 0);
		$hash    = $parts[1] ?? '';

		if ($post_id <= 0 || $hash === '' || !hash_equals(wp_hash($post_id), $hash)) {
			return 0;
		}

		return $post_id;
	}
}
require get_template_directory() . '/form/agm-sponsorship-commitment-form.php';
require get_template_directory() . '/form/agm-sponsorship-attendee-registration.php';
require get_template_directory() . '/form/scolarship-login-form.php';
require get_template_directory() . '/form/scolarship-registration-form.php';
require get_template_directory() . '/form/scholarship-application-form.php';
