<?php

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_watf_scholarship_ajax_login', 'watf_scholarship_ajax_login');
add_action('wp_ajax_nopriv_watf_scholarship_ajax_login', 'watf_scholarship_ajax_login');
add_action('wp_ajax_watf_scholarship_ajax_verify_otp', 'watf_scholarship_ajax_verify_otp');
add_action('wp_ajax_nopriv_watf_scholarship_ajax_verify_otp', 'watf_scholarship_ajax_verify_otp');

function watf_scholarship_ajax_login()
{
    check_ajax_referer('watf_scholarship_login', 'nonce');

    $email    = sanitize_email($_POST['log'] ?? '');
    $password = $_POST['pwd'] ?? '';

    if (!$email || !$password) {
        wp_send_json_error('Email and password are required.');
    }

    $user = get_user_by('email', $email);
    if (!$user || !wp_check_password($password, $user->user_pass, $user->ID)) {
        wp_send_json_error('Invalid email or password.');
    }

    $otp_code   = (string) random_int(100000, 999999);
    // $token_hash = wp_hash_password($otp_code);
    $expires_at = date('Y-m-d H:i:s', current_time('timestamp') + 10 * MINUTE_IN_SECONDS);

    global $wpdb;
    $table = $wpdb->prefix . 'watf_auth_tokens';

    $wpdb->delete(
        $table,
        [
            'user_id'    => $user->ID,
            'token_type' => 'login_otp',
            'used'       => 0,
        ],
        ['%d', '%s', '%d']
    );

    $wpdb->insert(
        $table,
        [
            'user_id'     => $user->ID,
            'token_hash'  => $otp_code,
            'token_type'  => 'login_otp',
            'expires_at'  => $expires_at,
            'used'        => 0,
            'ip_address'  => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : null,
            'user_agent'  => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : null,
        ],
        ['%d', '%s', '%s', '%s', '%d', '%s', '%s']
    );

    wp_mail(
        $email,
        'Your Scholarship Login OTP',
        "Your OTP is: {$otp_code}\nIt expires in 10 minutes."
    );

    wp_send_json_success([
        'email'   => $email,
        'message' => 'OTP sent to your email.',
    ]);
}

function watf_scholarship_ajax_verify_otp()
{

    check_ajax_referer('watf_scholarship_login', 'nonce');

    $email = sanitize_email($_POST['log'] ?? '');
    $entered_otp = trim($_POST['otp_code'] ?? '');

    if (!$email || !$entered_otp) {
        wp_send_json_error('Invalid request.');
    }

    $user = get_user_by('email', $email);
    if (!$user) {
        wp_send_json_error('User not found.');
    }

    global $wpdb;
    $table = $wpdb->prefix . 'watf_auth_tokens';

    // Fetch latest unused OTP
    $token = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table
         WHERE user_id = %d
         AND token_type = 'login_otp'
         AND used = 0
         ORDER BY id DESC
         LIMIT 1",
        $user->ID
    ));

    if (!$token) {
        wp_send_json_error('OTP not found.');
    }

    if (strtotime($token->expires_at) < current_time('timestamp')) {
        wp_send_json_error('OTP expired.');
    }

    if ($entered_otp !== $token->token_hash) {
        wp_send_json_error('Invalid OTP.');
    }

    // Mark as used
    $wpdb->update(
        $table,
        ['used' => 1],
        ['id' => $token->id],
        ['%d'],
        ['%d']
    );

    // Login
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID);

    wp_send_json_success([
        'redirect' => home_url('/scholarship-application-form/')
    ]);
}
