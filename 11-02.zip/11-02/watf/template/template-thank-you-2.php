<?php

/**
 * Template Name: Thank You 2
 *
 * Provides a shortcode to surface AGM sponsorship confirmation details (promo code
 * and attendee registration link) on the thank-you page.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('watf_render_agm_thank_you_details')) {
	/**
	 * Render the thank-you details pulled from query params.
	 *
	 * @return string
     */
    function watf_render_agm_thank_you_details()
    {
        $status            = isset($_GET['agm_sponsorship_status']) ? sanitize_key(wp_unslash($_GET['agm_sponsorship_status'])) : '';
        $promo_code        = isset($_GET['promo_code']) ? sanitize_text_field(wp_unslash($_GET['promo_code'])) : '';
        $attendee_form_url = isset($_GET['attendee_form_url']) ? esc_url_raw(wp_unslash($_GET['attendee_form_url'])) : '';

        if ($status !== 'success') {
            return '';
        }

        $items = [];

        if ($promo_code !== '') {
			$items[] = sprintf(
				'<div class="fw-semibold mb-2"><span class="promo-code-badge">Promo Code: %s</span></div>',
				esc_html($promo_code)
			);
		}


        if ($attendee_form_url !== '') {
            $items[] = sprintf(
                '<div class="fw-semibold">%s <a class="thankyou-2-registration-link" href="%s" target="_blank" rel="noopener noreferrer">%s</a></div>',
                esc_html__('Sponsorship Attendee Registration Link:', 'watf'),
                esc_url($attendee_form_url),
                esc_html($attendee_form_url)
            );
        }

        if (empty($items)) {
            return '';
        }

        $content = '<div class="alert-section alert alert-success mt-5" role="alert">';
        $content .= '<div class="mb-2">' . esc_html__('Please use the details below to register attendees.', 'watf') . '</div>';
        $content .= implode('', $items);
        $content .= '</div>';

		return $content;
	}
}

// Register the shortcode immediately (page templates load after init).
add_shortcode('agm_thank_you_details', 'watf_render_agm_thank_you_details');

// Standard template output. Drop the shortcode into the page content.
get_header();
?>

<div class="container py-5 thank-you-2 px-3 px-lg-5" style="max-width:1320px !important;">
    <div class="row justify-content-center">
        <div class="col-12">
            <?php
            while (have_posts()) :
                the_post();
                the_content();

            endwhile;
            ?>
            <?php echo do_shortcode('[agm_thank_you_details]'); ?>
        </div>
    </div>
</div>

<?php
get_footer();
