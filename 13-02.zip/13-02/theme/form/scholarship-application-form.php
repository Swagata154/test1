<?php

/**
 * Scholarship application form shortcode.
 *
 * Usage: [scholarship_application_form]
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('watf_register_scholarship_application_form_shortcode')) {
    function watf_register_scholarship_application_form_shortcode()
    {
        add_shortcode('scholarship_application_form', 'watf_render_scholarship_application_form_shortcode');
    }
    add_action('init', 'watf_register_scholarship_application_form_shortcode');
}
if (!function_exists('watf_render_scholarship_application_form_shortcode')) {
    /**
     * Render the scholarship application form.
     *
     * @param array<string, mixed> $atts Shortcode attributes.
     * @return string
     */
    function watf_render_scholarship_application_form_shortcode($atts = [])
    {
        $current_user_id = get_current_user_id();
        if (!$current_user_id) {
            return '<div class="alert alert-danger">Please login first.</div>';
        }
        global $wpdb;
        $table = $wpdb->prefix . 'watf_applications';
        ob_start();
        $user_id = get_current_user_id();
        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table WHERE user_id = %d",
                $user_id
            )
        );
        $selected_state = isset($existing->state) ? $existing->state : '';
        $selected_resident = isset($existing->resident) ? $existing->resident : '';
        $selected_student_release = isset($existing->student_release) ? $existing->student_release : '';
        $selected_parent_release = isset($existing->parent_release) ? $existing->parent_release : '';
        $selected_acknowledgement = isset($existing->acknowledgement) ? $existing->acknowledgement : '';
?>
        <div class="container px-3 pb-5">
            <form id="watf-application-form" class="agm-registration-form scholarship-registration-form" method="post" enctype="multipart/form-data">
                <div class="row g-4 align-items-end">
                    <input type="hidden" name="action" value="watf_scholarship_application">
                    <?php wp_nonce_field('watf_scholarship_application', 'watf_application_nonce'); ?>
                    <div class="col-12 col-md-4">
                        <label class="form-label">First Name <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->first_name ?? '') ?>" name="first_name">
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">Middle Initial</label>
                        <input type="text" class="form-control" value="<?= esc_attr($existing->middle_initial ?? '') ?>" name="middle_initial">
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">Last Name <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->last_name ?? '') ?>" name="last_name">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Are you a legal U.S. resident? <span class="text-danger">*</span></label>
                        <select required name="resident" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="yes" <?php selected($selected_resident, 'yes'); ?>>Yes</option>
                            <option value="no" <?php selected($selected_resident, 'no'); ?>>No</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Date of Birth (MM/DD/YYYY) <span class="text-danger">*</span></label>
                        <input required type="date" class="form-control" value="<?= esc_attr($existing->dob ?? '') ?>" name="date">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Phone <span class="text-danger">*</span></label>
                        <input required type="tel" inputmode="numeric" maxlength="10" value="<?= esc_attr($existing->phone ?? '') ?>" class="form-control" name="phone">
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Email <span class="text-danger">*</span></label>
                        <input required type="email" class="form-control" value="<?= esc_attr($existing->email ?? '') ?>" name="email">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Parent Name <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->parent_name ?? '') ?>" name="parent_name">
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Street <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->street ?? '') ?>" name="street">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">City <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->city ?? '') ?>" name="city">
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">State <span class="text-danger">*</span></label>
                        <select required name="state" class="form-control">
                            <option value="">Select</option>
                            <option value="AL" <?php selected($selected_state, 'AL'); ?>>Alabama</option>
                            <option value="AK" <?php selected($selected_state, 'AK'); ?>>Alaska</option>
                            <option value="AZ" <?php selected($selected_state, 'AZ'); ?>>Arizona</option>
                            <option value="AR" <?php selected($selected_state, 'AR'); ?>>Arkansas</option>
                            <option value="CA" <?php selected($selected_state, 'CA'); ?>>California</option>
                            <option value="CO" <?php selected($selected_state, 'CO'); ?>>Colorado</option>
                            <option value="CT" <?php selected($selected_state, 'CT'); ?>>Connecticut</option>
                            <option value="DE" <?php selected($selected_state, 'DE'); ?>>Delaware</option>
                            <option value="FL" <?php selected($selected_state, 'FL'); ?>>Florida</option>
                            <option value="GA" <?php selected($selected_state, 'GA'); ?>>Georgia</option>
                            <option value="HI" <?php selected($selected_state, 'HI'); ?>>Hawaii</option>
                            <option value="ID" <?php selected($selected_state, 'ID'); ?>>Idaho</option>
                            <option value="IL" <?php selected($selected_state, 'IL'); ?>>Illinois</option>
                            <option value="IN" <?php selected($selected_state, 'IN'); ?>>Indiana</option>
                            <option value="IA" <?php selected($selected_state, 'IA'); ?>>Iowa</option>
                            <option value="KS" <?php selected($selected_state, 'KS'); ?>>Kansas</option>
                            <option value="KY" <?php selected($selected_state, 'KY'); ?>>Kentucky</option>
                            <option value="LA" <?php selected($selected_state, 'LA'); ?>>Louisiana</option>
                            <option value="ME" <?php selected($selected_state, 'ME'); ?>>Maine</option>
                            <option value="MD" <?php selected($selected_state, 'MD'); ?>>Maryland</option>
                            <option value="MA" <?php selected($selected_state, 'MA'); ?>>Massachusetts</option>
                            <option value="MI" <?php selected($selected_state, 'MI'); ?>>Michigan</option>
                            <option value="MN" <?php selected($selected_state, 'MN'); ?>>Minnesota</option>
                            <option value="MS" <?php selected($selected_state, 'MS'); ?>>Mississippi</option>
                            <option value="MO" <?php selected($selected_state, 'MO'); ?>>Missouri</option>
                            <option value="MT" <?php selected($selected_state, 'MT'); ?>>Montana</option>
                            <option value="NE" <?php selected($selected_state, 'NE'); ?>>Nebraska</option>
                            <option value="NV" <?php selected($selected_state, 'NV'); ?>>Nevada</option>
                            <option value="NH" <?php selected($selected_state, 'NH'); ?>>New Hampshire</option>
                            <option value="NJ" <?php selected($selected_state, 'NJ'); ?>>New Jersey</option>
                            <option value="NM" <?php selected($selected_state, 'NM'); ?>>New Mexico</option>
                            <option value="NY" <?php selected($selected_state, 'NY'); ?>>New York</option>
                            <option value="NC" <?php selected($selected_state, 'NC'); ?>>North Carolina</option>
                            <option value="ND" <?php selected($selected_state, 'ND'); ?>>North Dakota</option>
                            <option value="OH" <?php selected($selected_state, 'OH'); ?>>Ohio</option>
                            <option value="OK" <?php selected($selected_state, 'OK'); ?>>Oklahoma</option>
                            <option value="OR" <?php selected($selected_state, 'OR'); ?>>Oregon</option>
                            <option value="PA" <?php selected($selected_state, 'PA'); ?>>Pennsylvania</option>
                            <option value="RI" <?php selected($selected_state, 'RI'); ?>>Rhode Island</option>
                            <option value="SC" <?php selected($selected_state, 'SC'); ?>>South Carolina</option>
                            <option value="SD" <?php selected($selected_state, 'SD'); ?>>South Dakota</option>
                            <option value="TN" <?php selected($selected_state, 'TN'); ?>>Tennessee</option>
                            <option value="TX" <?php selected($selected_state, 'TX'); ?>>Texas</option>
                            <option value="UT" <?php selected($selected_state, 'UT'); ?>>Utah</option>
                            <option value="VT" <?php selected($selected_state, 'VT'); ?>>Vermont</option>
                            <option value="VA" <?php selected($selected_state, 'VA'); ?>>Virginia</option>
                            <option value="WA" <?php selected($selected_state, 'WA'); ?>>Washington</option>
                            <option value="WV" <?php selected($selected_state, 'WV'); ?>>West Virginia</option>
                            <option value="WI" <?php selected($selected_state, 'WI'); ?>>Wisconsin</option>
                            <option value="WY" <?php selected($selected_state, 'WY'); ?>>Wyoming</option>
                        </select>

                    </div>

                    <div class="col-12 col-md-3">
                        <label class="form-label">Zip <span class="text-danger">*</span></label>
                        <input required type="number" class="form-control" value="<?= esc_attr($existing->zip ?? '') ?>" name="zip">
                    </div>
                    <span class="application_form_font">
                        Applicant must be an employee, volunteer, or dependent of one at a business within the Washington Dulles Airport
                        perimeter (inside the airport fence).
                    </span>

                    <div class="col-12 col-md-12">
                        <label class="form-label">Who is the employee/volunteer at Dulles Airport/perimeter? <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->vol_name ?? '') ?>" name="vol">
                    </div>

                    <div class="col-12 col-md-12">
                        <label class="form-label">What is the employee’s/volunteer’s email address? <span class="text-danger">*</span></label>
                        <input required type="email" class="form-control" value="<?= esc_attr($existing->vol_email ?? '') ?>" name="vol_email">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Relationship to Applicant <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->relation ?? '') ?>" name="relation">
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Employer <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->employer ?? '') ?>" name="employer">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Position <span class="text-danger">*</span></label>
                        <input required type="text" class="form-control" value="<?= esc_attr($existing->position ?? '') ?>" name="position">
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Phone <span class="text-danger">*</span></label>
                        <input required type="tel" inputmode="numeric" value="<?= esc_attr($existing->employee_phone ?? '') ?>" maxlength="10" class="form-control" name="employee_phone">
                    </div>

                    <label class="form-label application_form_textarea_label">Please list any colleges, universities, and/or trade schools you have been accepted to attend. <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea required name="accepted_schools"><?= esc_attr($existing->accepted_schools ?? '') ?></textarea>
                    </div>

                    <span class="application_form_font">
                        Please use the four sections below to provide details that showcase your leadership and commitment to the
                        community through extracurricular activities, employment, and/or volunteer work.
                    </span>

                    <label class="form-label application_form_textarea_label">1. List scholastic honors and scholarships. <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea required name="honors"><?= esc_attr($existing->honors ?? '') ?></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">2. List extra-curricular activities and/or employment history (include number of years and offices held). <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea required name="activities"><?= esc_attr($existing->activities ?? '') ?></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">3. List community activities (include number of years and offices held, if any). <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea required name="community"><?= esc_attr($existing->community ?? '') ?></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">4. Highlight instances where you took initiative, led a team, or made a meaningful impact through your leadership. <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea required name="leadership"><?= esc_attr($existing->leadership ?? '') ?></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">Describe your planned course of studies and educational goals. <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea required name="study_goals"><?= esc_attr($existing->study_goals ?? '') ?></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">Describe how you will benefit from this scholarship opportunity <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea required name="benefit"><?= esc_attr($existing->benefit ?? '') ?></textarea>
                    </div>

                    <label for="" class="application_form_textarea_label">
                        Please upload a PDF of your transcripts, available from your school counseling office.
                        <label for="transcript_file" class="watf-upload-btn float-end">
                            UPLOAD <span class="arrow">→</span>
                        </label>
                    </label>
                    <div class="watf-upload-wrapper col-12">
                        <div class="watf-upload-top w-100">
                            <input required type="file" id="transcript_file" class="w-100" name="transcript_file" accept="application/pdf">
                        </div>
                    </div>


                    <span class="application_form_textarea_label col-10">
                        Please upload a letter of recommendation (as a PDF or Word file) from a teacher or school
                        administrator. If you are unable to upload this document due to sensitivity constraints, a
                        school representative may email the letter directly to cfdco@washingtonairports.com.
                    </span>
                    <label for="recommendation_file" class="watf-upload-btn float-end col-2">
                        UPLOAD <span class="arrow">→</span>
                    </label>

                    <div class="watf-upload-wrapper col-12">
                        <div class="watf-upload-top w-100">
                            <input required type="file" id="recommendation_file" class="w-100" name="recommendation_file" accept="application/pdf">
                        </div>
                    </div>

                    <div class="col-12">
                        <label class="form-label application_form_textarea_label w-100">
                            Students’ personal and scholastic information remains confidential. However, the CFDCO promotes the
                            scholarship<br> applicants’ and winners’ names and photos if available. Please acknowledge that you and your parents
                            authorize the<br> CFDO to use such information.
                        </label>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">Student Release: <span class="text-danger">*</span></label>
                        <select required name="s_rel" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="yes" <?php selected($selected_student_release, 'yes'); ?>>Yes, I authorize CFDC to use my name and photo</option>
                            <option value="no" <?php selected($selected_student_release, 'no'); ?>>No, I do not authorize</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">Parent Release: <span class="text-danger">*</span></label>
                        <select required name="p_rel" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="yes" <?php selected($selected_parent_release, 'yes'); ?>>Yes, I authorize as Parent/Guardian</option>
                            <option value="no" <?php selected($selected_parent_release, 'no'); ?>>No, I do not authorize</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-10">
                        <label class="form-label">Applicant acknowledges information provided is true and accurate: <span class="text-danger">*</span></label>
                        <select required name="ack" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="yes" <?php selected($selected_acknowledgement, 'yes'); ?>>Yes, I confirm the information provided is true and accurate</option>
                            <option value="no" <?php selected($selected_acknowledgement, 'no'); ?>>No</option>
                        </select>
                    </div>

                    <div class="watf-agm-sponsorship-form container px-3">
                        <p class="text-danger fw-bold text-center mb-2">QUESTIONS?</p>
                    </div>

                    <label for="" class="fw-bold fst-italic text-center mt-0">
                        For questions or concerns, please email CFDCO@washingtonairports.com or call 703-572-8714.
                    </label>
                    <div id="watf-form-message"></div>
                    <div class="col-12 text-center d-flex">
                        <button type="submit" formnovalidate <?php if (!empty($existing->status) && $existing->status === 'submitted') echo 'disabled'; ?>
                            name="form_type" id="save_continue" value="draft" class="btn btn-primary px-5 button1">
                            SAVE & CONTINUE LATER
                        </button>
                        <button type="submit" <?php if (!empty($existing->status) && $existing->status === 'submitted') echo 'disabled'; ?>
                            name="form_type" id="submit" value="submitted" class="btn btn-primary px-5 button1">
                            SUBMIT
                        </button>
                    </div>
                </div>
            </form>
        </div>
<?php
        return ob_get_clean();
    }
}
