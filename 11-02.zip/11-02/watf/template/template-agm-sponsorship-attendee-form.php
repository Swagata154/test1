<?php
// Template Name: Agm sponsorship attendee form Template

$agm_attendee_form_output = do_shortcode('[agm_sponsorship_attendee_form]');
$is_form_available = trim($agm_attendee_form_output) !== '';

get_header();

$heading_1 = get_field( 'heading_1' , 'option');
$heading_2 = get_field( 'heading_2' , 'option');
$text1 = get_field( 'text1' , 'option');
$image = get_field( 'image' , 'option');
$text2 = get_field( 'text2' , 'option');
$date = get_field( 'date' , 'option');
$location = get_field( 'location' , 'option');
$rsvp = get_field( 'rsvp' , 'option');
$thank_given = get_field( 'thank_given');
$please_note = get_field( 'please_note');
$pay_online_text = get_field( 'pay_online_text');
$pay_link = get_field( 'pay_link');
?>
<?php if (!$is_form_available): ?>
	<section class="container my-5 py-5 text-center">
		<div class="alert alert-warning" role="alert" style="max-width: 640px; margin: 0 auto;">
			<strong><?php esc_html_e('Link unavailable', 'watf'); ?></strong><br>
			<?php esc_html_e('The registration link appears to be wrong or has expired. Please check your email invitation or contact Washington Airports Task Force for assistance.', 'watf'); ?>
		</div>
	</section>
<?php else: ?>
<!-- Banner -->
<div class="agm-registration-form_banner py-3 mt-5 px-3">
    <div class="container text-center">

        
		<h2 class="py-1"><span>AGM</span> SPONSORSHIP ATTENDEES REGISTRATION FORM</h2>
        

        <?php if (!empty($heading_2)): ?>
            <h1><?php echo ($heading_2); ?></h1>
        <?php endif; ?>

        <div class="row text-center align-items-center">

            <?php if (!empty($text1)): ?>
                <div class="col-12 col-sm-4">
                    <p><?php echo ($text1); ?></p>
                </div>
            <?php endif; ?>

            <?php if (!empty($image)): ?>
                <div class="col-12 col-sm-4">
                    <img class="img-fluid w-50"
                         src="<?php echo esc_url($image['url']); ?>"
                         alt="<?php echo esc_attr($image['alt'] ?? $image['filename']); ?>">
                </div>
            <?php endif; ?>

            <?php if (!empty($text2)): ?>
                <div class="col-12 col-sm-4">
                    <p><?php echo ($text2); ?></p>
                </div>
            <?php endif; ?>

        </div>

        <?php if (!empty($date)): ?>
            <p class="date"><?php echo ($date); ?></p>
        <?php endif; ?>

        <?php if (!empty($location)): ?>
            <p class="loc"><?php echo ($location); ?></p>
        <?php endif; ?>

        <?php if (!empty($rsvp)): ?>
            <p class="rsvp"><?php echo ($rsvp); ?></p>
        <?php endif; ?>

    </div>
</div>

<div class="agm-registration-form_section2 mb-5 py-5 px-3 text-center">
    <div class="container">
        
            <p>Thank you for sponsoring the 43rd Annual General Meeting and Williams Trophy Award. Our theme, “Eye
on the Future with the Skies of Tomorrow,” celebrates the innovation, technology, and collaboration that
continue to propel our industry forward.</p>
<p style="color: #368ccc;font-style: italic; font-weight: bold;">This form is for meeting sponsors only to fill out your organization’s meeting attendees.</p>
        
    </div>
</div>



<!-- agm_sponsorship_attendee_form -->
<?php if ($is_form_available) : ?>
	<?php echo $agm_attendee_form_output; ?>
<?php endif; ?>
<?php endif; ?>
<?php
get_footer();
?>
