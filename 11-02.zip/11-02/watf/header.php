<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package watf
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
<link rel="icon" href="https://www.washingtonairports.com/wp-content/uploads/2025/09/WATF_new.png" sizes="32x32">


	<title>
		<?php
		if (is_front_page()) {
			echo 'Washington Airports Task Force';
		} else {
			echo wp_get_document_title();
		}
		?>
	</title>

	<!-- jQuery CDN -->
	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/jquery-3.7.1.min.js"></script>

	<!-- Slick CSS -->
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/slick.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/slick-theme.css">

	<!-- Slick JS -->
	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/slick.min.js"></script>


	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/bootstrap.min.css">

	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/all.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/menu/nav.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/style.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/responsive.css">
	<!-- end style -->


	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/bootstrap.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/menu/bootstrap.bundle.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/menu/nav.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/app.js"></script>




	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<div id="page" class="site">
		<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'watf'); ?></a>

		<?php if (is_front_page()) : ?>
			<!-- Home Page Header -->
			<header id="homehead" class="home-header position-absolute top-0 right-0 px-0 w-100 d-none d-lg-flex">
				<div class="container-fluid">
					<div class="row align-items-center text-white">
						<!-- Center: Logo -->
						<div class="col-3 text-start">
							<div class="site-branding">
								<?php if (has_custom_logo()) {
									the_custom_logo();
								} ?>
							</div>
						</div>

						<!-- Left: Navigation Menu -->
						<div class="col-9 d-flex justify-content-end align-items-center gap-5">
							<?php
							wp_nav_menu(array(
								'theme_location' => 'primary',
								'menu_class' => 'nav menu-gap home m-0',
								'container' => false,
								'fallback_cb' => false
							));
							?>

						</div>
					</div>
				</div>
			</header>
		<?php else : ?>
			<header id="masthead" class="site-header py-0 px-0 fixed-top d-none d-lg-flex flex-column">
				<div class="top-header container-fluid px-4">
					<a href="<?= get_field('map_link', 'option'); ?>" class="location" target="_blank"><i class="fa-solid fa-location-dot mx-2"></i><?= get_field('map_name', 'option'); ?></a>
					<div class="header-social d-inline-flex gap-0">
						<?php
						$linkedin_link  = get_field('linkedin_link', 'option');
						$facebook_link  = get_field('facebook_link', 'option');
						$instagram_link = get_field('instagram_link', 'option');
						?>
						<?php if ($linkedin_link): ?>
							<a href="<?php echo esc_url($linkedin_link); ?>" target="_blank" class="text-white">
								<i class="fab fa-linkedin fa-lg"></i>
							</a>
						<?php endif; ?>
						<?php if ($facebook_link): ?>
							<a href="<?php echo esc_url($facebook_link); ?>" target="_blank" class="text-white">
								<i class="fa-brands fa-square-facebook fa-lg"></i>
							</a>
						<?php endif; ?>
						<?php if ($instagram_link): ?>
							<a href="<?php echo esc_url($instagram_link); ?>" target="_blank" class="text-white">
								<i class="fa-brands fa-square-instagram fa-xl"></i>
							</a>
						<?php endif; ?>
					</div>
					
				</div>

				<div class="container-fluid p-0 px-4">
					<div class="row align-items-center text-white">


						<!-- Center: Logo -->
						<div class="col-3 text-start">
							<div class="site-branding">
								<?php if (has_custom_logo()) {
									the_custom_logo();
								} ?>
							</div>
						</div>


						<!-- Left: Navigation Menu -->
						<div class="col-9 d-flex justify-content-end align-items-center gap-5 px-5">
							<?php
							wp_nav_menu(array(
								'theme_location' => 'primary',
								'menu_class' => 'nav main-nav menu-gap m-0',
								'container' => false,
								'fallback_cb' => false
							));
							?>

						</div>




						<!-- <div class="col-5 text-end d-flex justify-content-center align-items-center gap-5">
						
					</div> -->

					</div>
				</div>
			</header>
		<?php endif; ?>

		<header id="masthead2" class="fixed-top d-flex px-0 d-lg-none flex-column">
			<div class="top-header container-fluid px-4 py-2 justify-content-center justify-content-sm-between">
				<a href="<?= get_field('map_link', 'option'); ?>" class="location mb-2" target="_blank"><i class="fa-solid fa-location-dot mx-2"></i><?= get_field('map_name', 'option'); ?></a>
				<div class="header-social d-inline-flex gap-3 mb-1">
					<?php
					$linkedin_link  = get_field('linkedin_link', 'option');
					$facebook_link  = get_field('facebook_link', 'option');
					$instagram_link = get_field('instagram_link', 'option');
					?>
					<?php if ($linkedin_link): ?>
						<a href="<?php echo esc_url($linkedin_link); ?>" target="_blank" class="text-white">
							<i class="fab fa-linkedin fa-lg"></i>
						</a>
					<?php endif; ?>
					<?php if ($facebook_link): ?>
						<a href="<?php echo esc_url($facebook_link); ?>" target="_blank" class="text-white">
							<i class="fab fa-facebook fa-lg"></i>
						</a>
					<?php endif; ?>
					<?php if ($instagram_link): ?>
						<a href="<?php echo esc_url($instagram_link); ?>" target="_blank" class="text-white">
							<i class="fab fa-instagram fa-lg"></i>
						</a>
					<?php endif; ?>
				</div>
			</div>
			<div class="phone-nav d-flex d-lg-none position-reltive w-100 px-3">
				<div class="d-flex align-items-center w-100">
					<div class="eader-logo-phone">
						<div class="logo-wrapper">
							<?php the_custom_logo(); ?>
						</div>
					</div>

					<div class="header-nav flex-grow-1">
						<div id="swipe_overlay"></div>
						<div id="swipeNav">
							<div class="pull_nav_close text-center">
								<a href="javascript:void(0);" id="closeBtn" class="pull-close-nav">
									<span class="n"></span>
									<span class="g"></span>
									<span class="s"></span>
								</a>

							</div>
							<div id="main_nav" class="main_nav">
								<?php
								wp_nav_menu([
									'theme_location' => 'mobile-menu',
									'menu_class'     => 'top_nav',
									'menu_id'        => 'top_nav',
									'container'      => false,
								]);
								?>

							</div>
						</div>
					</div>


					<div id="pull_nav" class="d-flex">
						<a id="menuBtn" class="pull-nav">
							<span class="n"></span>
							<span class="g"></span>
							<span class="s"></span>
						</a>
					</div>
				</div>


			</div>
		</header>




		<script>
			jQuery(document).ready(function($) {
				$(".nav > li.menu-item-has-children > a").on("click", function(e) {
					e.preventDefault(); // stop link
					let $submenu = $(this).siblings(".sub-menu");

					// Close other open submenus
					$(".nav .sub-menu").not($submenu).removeClass("active");

					// Toggle clicked submenu
					$submenu.toggleClass("active");

					e.stopPropagation(); // prevent bubbling to document click
				});

				// Close submenu when clicking outside
				$(document).on("click", function(e) {
					if (!$(e.target).closest(".nav").length) {
						$(".nav .sub-menu").removeClass("active");
					}
				});

				function adjustBodyPadding() {
					var headerHeight = 0;


					if ($('#masthead').is(':visible')) {
						headerHeight = $('#masthead').outerHeight();
					} else if ($('#masthead2').is(':visible')) {
						headerHeight = $('#masthead2').outerHeight();
					}



					$('#dynamic-body-padding').remove();
					$('head').append('<style id="dynamic-body-padding">body { padding-top: ' + headerHeight + 'px !important; }</style>');
				}

				function toggleScrolledClass() {
					var scrollTop = $(window).scrollTop();
					$('#masthead, #masthead2').toggleClass('scrolled', scrollTop > 0);
				}


				$(window).on('load resize scroll', function() {
					adjustBodyPadding();
					toggleScrolledClass();
				});


				adjustBodyPadding();
				toggleScrolledClass();
			});
		</script>