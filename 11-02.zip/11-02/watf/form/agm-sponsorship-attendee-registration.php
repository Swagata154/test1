<?php

/**
 * AGM Sponsorship Attendee Registration Form shortcode.
 *
 * This shortcode provides a front-end form so sponsors can register the attendees
 * that are included with their sponsorship package. It mirrors the layout shared
 * in the design brief and writes submissions to the existing `agm_attendee` custom
 * post type so the admin workflow remains unchanged.
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!function_exists('watf_register_agm_sponsorship_attendee_form_shortcode')) {
	/**
	 * Register the shortcode during init.
	 */
	function watf_register_agm_sponsorship_attendee_form_shortcode()
	{
		add_shortcode(
			'agm_sponsorship_attendee_form',
			'watf_render_agm_sponsorship_attendee_form_shortcode'
		);
	}
	add_action('init', 'watf_register_agm_sponsorship_attendee_form_shortcode');
}

if (!function_exists('watf_render_agm_sponsorship_attendee_form_shortcode')) {
	/**
	 * Render + process the sponsorship attendee form.
	 *
	 * @param array<string, mixed> $atts Shortcode attributes.
	 */
	function watf_render_agm_sponsorship_attendee_form_shortcode($atts = [])
	{
		$states = function_exists('agm_us_states_list') ? agm_us_states_list() : [];

		/** @var array<string, array<string, mixed>> $default_levels */
		$default_levels = apply_filters(
			'watf_agm_sponsorship_attendee_levels',
			[
				'premier'  => [
					'label'         => __('Premier Sponsor - $10,000', 'watf'),
					'max_attendees' => 35,
				],
				'platinum' => [
					'label'         => __('Platinum Sponsor - $5,000', 'watf'),
					'max_attendees' => 22,
				],
				'gold'     => [
					'label'         => __('Gold Sponsor - $2,500', 'watf'),
					'max_attendees' => 10,
				],
				'silver'   => [
					'label'         => __('Silver Sponsor - $1,250', 'watf'),
					'max_attendees' => 8,
				],
				'bronze'   => [
					'label'         => __('Bronze Sponsor - $750', 'watf'),
					'max_attendees' => 6,
				],
			]
		);

		$atts = shortcode_atts(
			[
				'sponsor_level'         => 'premier',
				'sponsor_level_label'   => '',
				'promo_code'            => '',
				'max_attendees'         => '',
				'contact_sponsorship'   => 'Mark@washingtonairports.com',
				'contact_event'         => 'Lisa@washingtonairports.com',
			],
			$atts,
			'agm_sponsorship_attendee_form'
		);

		$query_level         = get_query_var('watf_sponsor_level');
		$get_level           = isset($_GET['sponsor_level']) ? sanitize_key(wp_unslash($_GET['sponsor_level'])) : '';
		$sponsor_ref         = isset($_GET['sponsor_ref']) ? sanitize_text_field(wp_unslash($_GET['sponsor_ref'])) : '';
		$linked_sponsorships = 0;
		$sponsor_form_locked = false;

		if ($sponsor_ref !== '' && function_exists('watf_decode_sponsor_ref')) {
			$decoded_id = watf_decode_sponsor_ref($sponsor_ref);
			if ($decoded_id > 0) {
				$linked_sponsorships = $decoded_id;
				$meta_level = get_post_meta($decoded_id, 'sponsor_level', true);
				if (is_string($meta_level) && $meta_level !== '') {
					$atts['sponsor_level'] = sanitize_key($meta_level);
				}
			}
		} else {
			$sponsor_form_locked = true;
		}

		if ($linked_sponsorships <= 0) {
			$sponsor_form_locked = true;
		}

		$existing_attendees = [];
		$existing_attendee_meta = [];
		$attendee_meta_keys = [
			'prefix',
			'first_name',
			'last_name',
			'title',
			'organization',
			'badge_name',
			'street',
			'city',
			'state',
			'zip',
			'phone',
			'email',
			'promo_code',
			'special_info',
		];
		$existing_count = 0;
		if ($linked_sponsorships > 0) {
			$existing_ids = get_post_meta($linked_sponsorships, 'sponsorship_attendee_ids', true);
			if (!is_array($existing_ids)) {
				$existing_ids = [];
			}
			$existing_ids = array_values(array_unique(array_filter(array_map('intval', $existing_ids))));

			if (!empty($existing_ids)) {
				$attendee_query = [
					'post_type'      => defined('WATF_SPONSOR_ATTENDEE_CPT') ? WATF_SPONSOR_ATTENDEE_CPT : 'agm_sponsor_att',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'post__in'       => $existing_ids,
					'orderby'        => 'post__in',
				];
				$attendee_posts = get_posts($attendee_query);

				foreach ($attendee_posts as $attendee_post) {
					$first = trim((string) get_post_meta($attendee_post->ID, 'first_name', true));
					$last  = trim((string) get_post_meta($attendee_post->ID, 'last_name', true));
					$name  = trim(implode(' ', array_filter([$first, $last])));
					if ($name === '') {
						$name = get_the_title($attendee_post);
					}

					$subtitle_parts = [];
					$title = trim((string) get_post_meta($attendee_post->ID, 'title', true));
					if ($title !== '') {
						$subtitle_parts[] = $title;
					}
					$organization = trim((string) get_post_meta($attendee_post->ID, 'organization', true));
					if ($organization !== '') {
						$subtitle_parts[] = $organization;
					}

					$existing_meta = [];
					foreach ($attendee_meta_keys as $meta_key) {
						$existing_meta[$meta_key] = get_post_meta($attendee_post->ID, $meta_key, true);
					}

					$existing_attendees[] = [
						'id'       => $attendee_post->ID,
						'name'     => $name !== '' ? $name : __('Attendee', 'watf'),
						'subtitle' => implode(' — ', $subtitle_parts),
						'email'    => sanitize_email(get_post_meta($attendee_post->ID, 'email', true)),
					];
					$existing_attendee_meta[] = $existing_meta;
				}
			}
		}
		$existing_count = count($existing_attendees);


		if ($sponsor_form_locked) {
			$invalid_heading = '';
			$invalid_message = '';
			if (function_exists('get_field')) {
				$invalid_heading = trim((string) get_field('invalid_link_heading', 'option'));
				$invalid_message = trim((string) get_field('invalid_link_body', 'option'));
			}

			if ($invalid_heading === '') {
				$invalid_heading = __('Link unavailable', 'watf');
			}

			if ($invalid_message === '') {
				$invalid_message = __('The registration link appears to be wrong or has expired. Please check your email invitation or contact Washington Airports Task Force for assistance.', 'watf');
			}

			global $watf_agm_invalid_link_message;
			$watf_agm_invalid_link_message = [
				'heading' => $invalid_heading,
				'message' => $invalid_message,
			];

			status_header(404);
			nocache_headers();
			$template = get_query_template('404');
			if ($template) {
				include $template;
			} else {
				echo '<h1>404</h1>';
			}
			return '';
		}

		$selected_level = sanitize_key($atts['sponsor_level']);
		if (!isset($default_levels[$selected_level])) {
			$selected_level = array_key_first($default_levels);
		}

		$level_config = $default_levels[$selected_level] ?? [];
		$level_display = $atts['sponsor_level_label'] !== ''
			? sanitize_text_field($atts['sponsor_level_label'])
			: ($level_config['label'] ?? ucwords(str_replace(['-', '_'], [' ', ' '], $selected_level)));

		$max_attendees = intval($atts['max_attendees']) > 0 ? intval($atts['max_attendees']) : intval($level_config['max_attendees'] ?? 0);

		$promo_code_value = sanitize_text_field($atts['promo_code']);

		$errors       = [];
		$limit_error  = '';
		$success_ids  = [];
		$saved_count  = 0;
		$has_post     = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['watf_sponsorship_attendee_form']); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ($has_post) {
			$nonce_ok = isset($_POST['watf_sponsorship_attendee_nonce']) && wp_verify_nonce(
				sanitize_text_field(wp_unslash($_POST['watf_sponsorship_attendee_nonce'] ?? '')),
				'watf_sponsorship_attendee'
			);

			if (!$nonce_ok) {
				$errors[] = __('Security check failed. Please refresh and try again.', 'watf');
			} else {
				$posted_level = isset($_POST['selected_sponsor_level'])
					? sanitize_key(wp_unslash($_POST['selected_sponsor_level']))
					: $selected_level;
				if (isset($default_levels[$posted_level])) {
					$selected_level = $posted_level;
					$level_config   = $default_levels[$posted_level];
				}

				$level_display_post = sanitize_text_field(wp_unslash($_POST['sponsor_level_display'] ?? ''));
				if ($level_display_post !== '') {
					$level_display = $level_display_post;
				} elseif (isset($level_config['label'])) {
					$level_display = $level_config['label'];
				}

				$promo_code_value = sanitize_text_field(wp_unslash($_POST['shared_promo_code'] ?? $promo_code_value));

				$limit_from_post = intval(wp_unslash($_POST['attendee_limit'] ?? 0));
				if ($limit_from_post > 0) {
					$max_attendees = $limit_from_post;
				}

				$fields = [
					'prefix',
					'first_name',
					'last_name',
					'title',
					'organization',
					'badge_name',
					'street',
					'city',
					'state',
					'zip',
					'phone',
					'email',
					'special_info',
				];

				foreach ($fields as $field) {
					if (!isset($_POST[$field]) || !is_array($_POST[$field])) {
						$_POST[$field] = [];
					}
				}

				$total_rows = count($_POST['first_name']);
				$attendees  = [];

				for ($i = 0; $i < $total_rows; $i++) {
					$attendee = [
						'prefix'                => sanitize_text_field(wp_unslash($_POST['prefix'][$i] ?? '')),
						'first_name'            => sanitize_text_field(wp_unslash($_POST['first_name'][$i] ?? '')),
						'last_name'             => sanitize_text_field(wp_unslash($_POST['last_name'][$i] ?? '')),
						'title'                 => sanitize_text_field(wp_unslash($_POST['title'][$i] ?? '')),
						'organization'          => sanitize_text_field(wp_unslash($_POST['organization'][$i] ?? '')),
						'badge_name'            => sanitize_text_field(wp_unslash($_POST['badge_name'][$i] ?? '')),
						'street'                => sanitize_text_field(wp_unslash($_POST['street'][$i] ?? '')),
						'city'                  => sanitize_text_field(wp_unslash($_POST['city'][$i] ?? '')),
						'state'                 => sanitize_text_field(wp_unslash($_POST['state'][$i] ?? '')),
						'zip'                   => sanitize_text_field(wp_unslash($_POST['zip'][$i] ?? '')),
						'phone'                 => sanitize_text_field(wp_unslash($_POST['phone'][$i] ?? '')),
						'email'                 => sanitize_email(wp_unslash($_POST['email'][$i] ?? '')),
						'attendee_type'         => 'sponsor',
						'promo_code'            => $promo_code_value,
						'special_info'          => sanitize_textarea_field(wp_unslash($_POST['special_info'][$i] ?? '')),
						'sponsor_level'         => $selected_level,
						'sponsor_level_label'   => $level_display,
						'sponsor_allowed_total' => $max_attendees,
					];

					$is_empty = implode('', array_map('strval', $attendee)) === '';
					if ($is_empty) {
						continue;
					}

					if (
						$attendee['first_name'] === '' ||
						$attendee['last_name'] === '' ||
						$attendee['title'] === '' ||
						$attendee['organization'] === '' ||
						$attendee['badge_name'] === '' ||
						$attendee['street'] === '' ||
						$attendee['city'] === '' ||
						$attendee['state'] === '' ||
						$attendee['zip'] === '' ||
						$attendee['phone'] === '' ||
						$attendee['email'] === ''
					) {
						$errors[] = sprintf(__('Attendee %d: Please complete all required fields.', 'watf'), $i + 1);
						continue;
					}

					if (!isset($states[$attendee['state']])) {
						$errors[] = sprintf(__('Attendee %d: Invalid state selection.', 'watf'), $i + 1);
						continue;
					}

					if (!is_email($attendee['email'])) {
						$errors[] = sprintf(__('Attendee %d: Invalid email address.', 'watf'), $i + 1);
						continue;
					}

					$attendees[] = $attendee;
				}

				if (empty($attendees)) {
					$errors[] = __('No attendee information was provided.', 'watf');
				}

				if ($max_attendees > 0) {
					$total_new = count($attendees);
					if ($existing_count >= $max_attendees) {
						$limit_error = __('You have already reached the attendee limit for this sponsorship level.', 'watf');
						$errors[] = $limit_error;
					} else {
						$available = $max_attendees - $existing_count;
						if ($total_new > $available) {
							$errors[] = sprintf(
								/* translators: %1: allowed left, 2: existing count, 3: limit */
								__('You may only register %1$d more attendee(s); %2$d of %3$d slots are already used.', 'watf'),
								$available,
								$existing_count,
								$max_attendees
							);
						}
					}
				}

				if (empty($errors) && !empty($attendees)) {
					$primary = $attendees[0];

					$primary_id = wp_insert_post(
						[
							'post_type'   => defined('WATF_SPONSOR_ATTENDEE_CPT') ? WATF_SPONSOR_ATTENDEE_CPT : 'agm_sponsor_att',
							'post_status' => 'publish',
							'post_title'  => 'AGM Sponsorship Attendee: ' . $primary['first_name'] . ' ' . $primary['last_name'],
						],
						true
					);

					if (is_wp_error($primary_id)) {
						$errors[] = sprintf(__('Attendee 1: Could not save (error: %s).', 'watf'), $primary_id->get_error_message());
					} else {
						foreach ($primary as $meta_key => $meta_value) {
							update_post_meta($primary_id, $meta_key, $meta_value);
						}
						update_post_meta($primary_id, 'registration_group', $primary_id);
						update_post_meta($primary_id, 'group_position', 1);
						update_post_meta($primary_id, 'is_primary', 1);

						$saved_count = 1;

						$child_ids = [];
						for ($i = 1, $attendee_total = count($attendees); $i < $attendee_total; $i++) {
							$child      = $attendees[$i];
							$child_id   = wp_insert_post(
								[
									'post_type'   => defined('WATF_SPONSOR_ATTENDEE_CPT') ? WATF_SPONSOR_ATTENDEE_CPT : 'agm_sponsor_att',
									'post_status' => 'publish',
									'post_parent' => $primary_id,
									'post_title'  => 'AGM Sponsorship Attendee: ' . $child['first_name'] . ' ' . $child['last_name'],
									'menu_order'  => $i + 1,
								],
								true
							);

							if (is_wp_error($child_id)) {
								$errors[] = sprintf(__('Attendee %d: Could not save (error: %s).', 'watf'), $i + 1, $child_id->get_error_message());
								continue;
							}

							foreach ($child as $meta_key => $meta_value) {
								update_post_meta($child_id, $meta_key, $meta_value);
							}

							update_post_meta($child_id, 'registration_group', $primary_id);
							update_post_meta($child_id, 'group_position', $i + 1);
							update_post_meta($child_id, 'is_primary', 0);
							$child_ids[]  = $child_id;
							$success_ids[] = $child_id;
							$saved_count++;
						}

						foreach ($child_ids as $child_id) {
							update_post_meta($child_id, 'group_total', $saved_count);
						}

						update_post_meta($primary_id, 'group_total', $saved_count);
						update_post_meta($primary_id, 'additional_attendee_ids', array_map('intval', $child_ids));

						$all_attendee_ids = array_map('intval', array_merge([$primary_id], $child_ids));
						if ($linked_sponsorships > 0) {
							$current = get_post_meta($linked_sponsorships, 'sponsorship_attendee_ids', true);
							if (!is_array($current)) {
								$current = [];
							}
							$merged = array_values(array_unique(array_merge($current, $all_attendee_ids)));
							update_post_meta($linked_sponsorships, 'sponsorship_attendee_ids', $merged);

							foreach ($all_attendee_ids as $attendee_id) {
								update_post_meta($attendee_id, 'sponsorship_post_id', $linked_sponsorships);
							}
						}

						if ($saved_count > 0 && empty($errors)) {
							$recipient_email = $primary['email'] ?? '';

							if ($recipient_email && is_email($recipient_email)) {
								$primary_name = trim(implode(' ', array_filter([$primary['prefix'] ?? '', $primary['first_name'] ?? '', $primary['last_name'] ?? ''])));
								$subject      = "WATF 43rd AGM Sponsorship Attendee Registration";
								$sponsor_name  = get_post_meta($linked_sponsorships, 'sponsor_name', true);
								$body_html   = [];
								//$body_html[] = '<p>' . ($sponsor_name !== '' ? sprintf(__('Hello %s,', 'watf'), esc_html($sponsor_name)) : esc_html__('Hello,', 'watf')) . '</p>';
								$body_html[] = '<p>Hello,</p>';
								$body_html[] = '';

								$body_html[] = '<p>Thank you for sponsoring and registering for WATF’s <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="https://www.washingtonairports.com/agm/"><strong>2025 43rd Annual General Meeting and Williams Trophy Presentation</strong></a>.</p>';
								$body_html[] = '<p>We look forward to seeing you on Tuesday, December 2, 2025 from 11am-2pm at <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="https://www.invitedclubs.com/clubs/belmont-country-club"><strong>Belmont Country Club</strong></a>, 19661 Belmont Manor Ln., Ashburn, VA 20147.</p>';
								$body_html[] = '<p>Here is a summary of your registration:</p>';

								// if ($max_attendees > 0) {
								// 	$body_html[] = '<p>' . sprintf(
								// 		/* translators: 1: saved count, 2: allowed total */
								// 		esc_html__('You submitted %1$d of %2$d allowed attendees.', 'watf'),
								// 		intval($saved_count),
								// 		intval($max_attendees)
								// 	) . '</p>';
								// }

								$field_labels = [
									'prefix'       => __('Prefix', 'watf'),
									'first_name'   => __('First Name', 'watf'),
									'last_name'    => __('Last Name', 'watf'),
									'title'        => __('Title', 'watf'),
									'organization' => __('Organization', 'watf'),
									'badge_name'   => __('Badge Name', 'watf'),
									'street'       => __('Street', 'watf'),
									'city'         => __('City', 'watf'),
									'state'        => __('State', 'watf'),
									'zip'          => __('Zip', 'watf'),
									'phone'        => __('Phone', 'watf'),
									'email'        => __('Email', 'watf'),
									'promo_code'   => __('Promo Code', 'watf'),
									'special_info' => __('Special Accommodations, Dietary Restrictions, and Additional Information', 'watf'),
								];

								$attendee_number = 0;
								if (!empty($existing_attendee_meta)) {
									foreach ($existing_attendee_meta as $existing_data) {
										$attendee_number++;
										$body_html[] = '<h4 style="margin-bottom:6px;">' . sprintf(
											/* translators: %d attendee number */
											esc_html__('Attendee %d', 'watf'),
											$attendee_number
										) . '</h4>';
										$body_html[] = '<ul style="margin-top:0; padding-left:18px;">';
										foreach ($field_labels as $meta_key => $label) {
											$value = $existing_data[$meta_key] ?? '';
											if ($value === '' || $value === null) {
												continue;
											}
											$value_markup = $meta_key === 'special_info'
												? nl2br(esc_html($value))
												: esc_html($value);
											$body_html[] = '<li><strong>' . esc_html($label) . ':</strong> ' . $value_markup . '</li>';
										}
										$body_html[] = '</ul>';
									}
								}

								foreach ($attendees as $index => $attendee_data) {
									$attendee_number++;
									$body_html[] = '<h4 style="margin-bottom:6px;">' . sprintf(
										/* translators: %d attendee number */
										esc_html__('Attendee %d', 'watf'),
										$attendee_number
									) . '</h4>';
									$body_html[] = '<ul style="margin-top:0; padding-left:18px;">';
									foreach ($field_labels as $meta_key => $label) {
										if (!isset($attendee_data[$meta_key]) || $attendee_data[$meta_key] === '') {
											continue;
										}

										$value_markup = $meta_key === 'special_info'
											? nl2br(esc_html($attendee_data[$meta_key]))
											: esc_html($attendee_data[$meta_key]);

										$body_html[] = '<li><strong>' . esc_html($label) . ':</strong> ' . $value_markup . '</li>';
									}


									$body_html[] = '</ul>';
								}

								$body_html[] = '<p>Thank you, again, for your registration. If any of the above information is incorrect, please contact Lisa Merhaut at 703-572-8714 or  <a style="text-decoration:none; color: #1A3C6B; font-weight:600;" href="mailto:mark@washingtonairports.com">Lisa@washingtonairports.com</a>.</p>';

								$message = '<html><body>' . implode("\n", $body_html) . '</body></html>';
								$headers = ['Content-Type: text/html; charset=UTF-8'];
								// from address set
								$from_email = 'info@washingtonairports.com';
								if ($from_email && is_email($from_email)) {
									$from_name = 'WATF';
									$headers[] = 'From: ' . sanitize_text_field($from_name) . ' <' . sanitize_email($from_email) . '>';
								}

								$admin_email = get_option('admin_email');
								if ($admin_email && is_email($admin_email)) {
									$headers[] = 'Cc: ' . sanitize_email($admin_email);
								}

								//    bcc_addresses set 
								$bcc_addresses = [];
								if (have_rows('bcc_addresses', 'option')) {
									while (have_rows('bcc_addresses', 'option')) {
										the_row();
										$email = sanitize_email(get_sub_field('recipient_email'));
										if (!empty($email)) {
											$bcc_addresses[] = $email;
										}
									}
								}

								if (!empty($bcc_addresses)) {
									$headers[] = 'Bcc: ' . implode(', ', $bcc_addresses);
								}

								// wp_mail($recipient_email, $subject, $message, $headers);

								if ($linked_sponsorships > 0) {
									$sponsor_email = get_post_meta($linked_sponsorships, 'email', true);

									if ($sponsor_email && is_email($sponsor_email) && strcasecmp($sponsor_email, $recipient_email) !== 0) {
										wp_mail($sponsor_email, $subject, $message, $headers);
									}
								}
							}
						}

						if (empty($errors) && $saved_count > 0) {
							$redirect = get_permalink(get_page_by_path('thank-you-4'));
							if (!$redirect) {
								$redirect = wp_get_referer();
							}
							if (!$redirect) {
								$redirect = get_permalink();
							}
							if (!$redirect) {
								$redirect = home_url('/');
							}
							$redirect = remove_query_arg('watf_sponsor_success', $redirect);
							if (strpos($redirect, home_url()) === 0) {
								// optional success count for fallbacks
								$redirect = add_query_arg('watf_sponsor_success', $saved_count, $redirect);
							}
							wp_safe_redirect($redirect);
							exit;
						}
					}
				}
			}
		}

		$has_errors = !empty($errors);
		$limit_error_fired = !empty($limit_error) && in_array($limit_error, $errors, true);
		$errors_to_show = $errors;
		if ($limit_error_fired) {
			$errors_to_show = array_values(array_filter($errors_to_show, function ($error) use ($limit_error) {
				return $error !== $limit_error;
			}));
		}

		$prefill = [
			'prefix'       => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['prefix'] ?? []))) : [],
			'first_name'   => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['first_name'] ?? []))) : [],
			'last_name'    => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['last_name'] ?? []))) : [],
			'title'        => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['title'] ?? []))) : [],
			'organization' => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['organization'] ?? []))) : [],
			'badge_name'   => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['badge_name'] ?? []))) : [],
			'street'       => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['street'] ?? []))) : [],
			'city'         => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['city'] ?? []))) : [],
			'state'        => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['state'] ?? []))) : [],
			'zip'          => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['zip'] ?? []))) : [],
			'phone'        => $has_errors ? array_map('sanitize_text_field', wp_unslash((array) ($_POST['phone'] ?? []))) : [],
			'email'        => $has_errors ? array_map('sanitize_email', wp_unslash((array) ($_POST['email'] ?? []))) : [],
			'special_info' => $has_errors ? array_map('sanitize_textarea_field', wp_unslash((array) ($_POST['special_info'] ?? []))) : [],
		];

		$initial_forms = $has_errors ? max(1, count($prefill['first_name'])) : 1;
		$entered_count = $has_errors ? count(array_filter($prefill['first_name'])) : $existing_count;
		$progress_max  = $max_attendees > 0 ? max($max_attendees, $entered_count) : max(1, max($initial_forms, $entered_count));
		$progress_template_prefix = __('You have entered', 'watf');
		$progress_template_suffix = __("attendees' information.", 'watf');
		$progress_text = sprintf(
			'%1$s: %2$s %3$d/%4$d %5$s',
			$level_display !== '' ? $level_display : __('Sponsorship', 'watf'),
			$progress_template_prefix,
			$entered_count,
			$progress_max,
			$progress_template_suffix
		);

		ob_start();
?>
		<div class="watf-sponsorship-attendee-wrapper container px-3 pb-5">
			<?php if (!empty($errors_to_show)) : ?>
				<div class="alert alert-danger">
					<ul class="mb-0" style="padding-left:18px;">
						<?php foreach ($errors_to_show as $error_message) : ?>
							<li><?php echo esc_html($error_message); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if (isset($_GET['watf_sponsor_success'])) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended 
				$success_total = intval($_GET['watf_sponsor_success']);
				if ($success_total > 0) :
			?>
					<div class="alert alert-success">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %d count */
								__('Thank you! %d attendee(s) have been saved.', 'watf'),
								$success_total
							)
						);
						?>
					</div>
			<?php
				endif;
			endif;
			?>
			<div id="watf-existing-feedback" class="alert d-none mb-2" role="alert"></div>
			<?php if (!empty($existing_attendees)) : ?>
				<section class="watf-existing-attendees mb-4">
					<div class="d-flex justify-content-between align-items-start mb-2">
						<h3 class="h5 mb-0"><?php esc_html_e('Registered Attendees', 'watf'); ?></h3>
						<b>
							<span id="watf-existing-count" class="text-muted small">
								<?php printf(esc_html__('You have registered %d attendee(s).', 'watf'), $existing_count); ?>
							</span>
						</b>
					</div>

					<ul id="watf-existing-attendee-list" class="list-group">
						<?php foreach ($existing_attendees as $attendee) : ?>
							<li class="list-group-item d-flex justify-content-between align-items-center">
								<strong class="mb-0" style="font-size: 18PX;"><?php echo esc_html($attendee['name']); ?></strong>
								<button type="button"
									class="btn btn-sm btn-outline-secondary watf-remove-attendee"
									data-attendee-id="<?php echo esc_attr($attendee['id']); ?>">
									<?php esc_html_e('Delete', 'watf'); ?>
								</button>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>
			<?php endif; ?>

			<form method="post" class="agm-registration-form watf-sponsorship-attendee-form" id="agm-form">
				<?php wp_nonce_field('watf_sponsorship_attendee', 'watf_sponsorship_attendee_nonce'); ?>
				<input type="hidden" name="watf_sponsorship_attendee_form" value="1">
				<input type="hidden" name="selected_sponsor_level" value="<?php echo esc_attr($selected_level); ?>">
				<input type="hidden" name="sponsor_level_display" value="<?php echo esc_attr($level_display); ?>">
				<input type="hidden" name="attendee_limit" value="<?php echo esc_attr($max_attendees); ?>">

				<h3 class="mb-1 text-center"><?php echo esc_html__('Annual General Meeting Sponsorship Attendee Registration Form', 'watf'); ?></h3>
				<p class="text-muted mb-4 text-start"><span class="text-danger">*</span> <?php echo esc_html__('Indicates required fields.', 'watf'); ?></p>

				<div class="row g-3 mb-4 mx-auto" style="max-width: 1550px;">
					<div class="col-12 col-md-6">
						<label class="form-label fw-semibold"><?php echo wp_kses_post(__('Sponsor Level<span class="text-danger">*</span>', 'watf')); ?></label>
						<input type="text" class="form-control bg-light text-body" style="color: #368ccc !important;font-size:18px;  font-style: italic; font-weight: bold;" value="<?php echo esc_attr($level_display); ?>" readonly>

					</div>
					<div class="col-12 col-md-6 d-flex justify-content-start">
						<label class="form-label fw-semibold" style="width:40%;" for="watf-shared-promo"><?php echo wp_kses_post(__('Promo Code<span class="text-danger">*</span>', 'watf')); ?></label>
						<input type="text" id="watf-shared-promo" name="shared_promo_code" class="form-control" value="<?php echo esc_attr($promo_code_value); ?>" required>
					</div>
				</div>



				<div id="attendee-forms" data-attendee-limit="<?php echo esc_attr($max_attendees); ?>" data-level-label="<?php echo esc_attr($level_display); ?>">
					<?php for ($i = 0; $i < $initial_forms; $i++) : ?>
						<div class="attendee-form p-3 p-md-4 mb-4">
							<div class="d-flex justify-content-start align-items-center mb-3 gap-4">
								<h5 class="mb-0"><?php echo esc_html(sprintf(__('Attendee %d', 'watf'), $i + 1)); ?></h5>
								<button type="button" class="remove-attendee btn btn-sm p-0 text-danger<?php echo $i === 0 ? ' d-none' : ''; ?>" aria-label="<?php echo esc_attr__('Remove attendee', 'watf'); ?>">
									<i class="fa-solid fa-trash" aria-hidden="true"></i>
								</button>
							</div>

							<div class="row g-4">
								<div class="col-12 col-md-2">
									<label class="form-label"><?php echo esc_html__('Prefix', 'watf'); ?></label>
									<input type="text" name="prefix[]" class="form-control" value="<?php echo esc_attr($prefill['prefix'][$i] ?? ''); ?>">
								</div>
								<div class="col-12 col-md-5">
									<label class="form-label"><?php echo wp_kses_post(__('First Name<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="text" name="first_name[]" class="form-control" value="<?php echo esc_attr($prefill['first_name'][$i] ?? ''); ?>" required>
								</div>
								<div class="col-12 col-md-5">
									<label class="form-label"><?php echo wp_kses_post(__('Last Name<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="text" name="last_name[]" class="form-control" value="<?php echo esc_attr($prefill['last_name'][$i] ?? ''); ?>" required>
								</div>

								<div class="col-12 col-md-6">
									<label class="form-label"><?php echo wp_kses_post(__('Title<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="text" name="title[]" class="form-control" value="<?php echo esc_attr($prefill['title'][$i] ?? ''); ?>" required>
								</div>
								<div class="col-12 col-md-6">
									<label class="form-label"><?php echo wp_kses_post(__('Organization<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="text" name="organization[]" class="form-control watf-copy-organization" value="<?php echo esc_attr($prefill['organization'][$i] ?? ''); ?>" required>
								</div>

								<div class="col-12 col-md-6">
									<label class="form-label"><?php echo wp_kses_post(__('Badge Name<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="text" name="badge_name[]" class="form-control watf-copy-badge" value="<?php echo esc_attr($prefill['badge_name'][$i] ?? ''); ?>" required>
								</div>
								<div class="col-12 col-md-6">
									<label class="form-label"><?php echo wp_kses_post(__('Street<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="text" name="street[]" class="form-control watf-copy-street" value="<?php echo esc_attr($prefill['street'][$i] ?? ''); ?>" required>
								</div>

								<div class="col-12 col-md-4">
									<label class="form-label"><?php echo wp_kses_post(__('City<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="text" name="city[]" class="form-control watf-copy-city" value="<?php echo esc_attr($prefill['city'][$i] ?? ''); ?>" required>
								</div>
								<div class="col-12 col-md-4">
									<label class="form-label"><?php echo wp_kses_post(__('State<span class="text-danger">*</span>', 'watf')); ?></label>
									<select name="state[]" class="form-select watf-copy-state" required>
										<option value=""><?php echo esc_html__('Select', 'watf'); ?></option>
										<?php foreach ($states as $abbr => $state_name) : ?>
											<option value="<?php echo esc_attr($abbr); ?>" <?php selected($abbr, $prefill['state'][$i] ?? ''); ?>>
												<?php echo esc_html($state_name); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="col-12 col-md-4">
									<label class="form-label"><?php echo wp_kses_post(__('Zip<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="text" name="zip[]" class="form-control watf-copy-zip" value="<?php echo esc_attr($prefill['zip'][$i] ?? ''); ?>" required>
								</div>

								<div class="col-12 col-md-6">
									<label class="form-label"><?php echo wp_kses_post(__('Phone<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="tel" name="phone[]" class="form-control" value="<?php echo esc_attr($prefill['phone'][$i] ?? ''); ?>" required>
								</div>
								<div class="col-12 col-md-6">
									<label class="form-label"><?php echo wp_kses_post(__('Email<span class="text-danger">*</span>', 'watf')); ?></label>
									<input type="email" name="email[]" class="form-control" value="<?php echo esc_attr($prefill['email'][$i] ?? ''); ?>" required>
								</div>

								<div class="col-12">
									<label class="form-label"><?php echo esc_html__('Special Accommodations, Dietary Restrictions, and Additional Information', 'watf'); ?></label>
									<textarea name="special_info[]" class="form-control" rows="3"><?php echo esc_textarea($prefill['special_info'][$i] ?? ''); ?></textarea>
								</div>
							</div>
						</div>
					<?php endfor; ?>
				</div>

				<div class="watf-add-attendee-wrapper text-center mb-4">
					<!-- <p style="color: #368ccc;font-style: italic; font-weight: bold;">Premier Sponsorship: You have entered 0/30 attendees’ information.</p> -->
					<p id="watf-attendee-progress" class="d-block mt-1 mb-2" style="color: #368ccc;font-style: italic; font-weight: bold;"><?php echo esc_html($progress_text); ?></p>
					<p class="click mb-1">
						<a href="#" id="add-attendee" class="fw-bold"><?php echo esc_html__('Click here', 'watf'); ?></a>
						<?php echo esc_html__('to add an additional AGM meeting attendee.', 'watf'); ?>
					</p>
					<small class="text-muted d-none" id="watf-attendee-limit-note"></small>
				</div>



				<div class="text-center mb-4">
					<p class="fw-bold mb-1 text-danger text-uppercase"><?php echo esc_html__('Questions?', 'watf'); ?></p>
					<p class="mb-1 email">
						<?php
						printf(
							/* translators: %s email */
							esc_html__('For event sponsorships, contact %s.', 'watf'),
							'<a href="mailto:' . esc_attr($atts['contact_sponsorship']) . '">' . esc_html($atts['contact_sponsorship']) . '</a>'
						);
						?>
					</p>
					<p class="mb-0 email">
						<?php
						printf(
							/* translators: %s email */
							esc_html__('For event details, contact %s.', 'watf'),
							'<a href="mailto:' . esc_attr($atts['contact_event']) . '">' . esc_html($atts['contact_event']) . '</a>'
						);
						?>
					</p>
				</div>

				<div class="text-center">
					<button type="submit" class="px-5 button1 mx-auto">
						<?php echo esc_html__('Submit', 'watf'); ?>
					</button>
				</div>
			</form>
		</div>

		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
		<script>
			document.addEventListener('DOMContentLoaded', function() {
				const container = document.getElementById('attendee-forms');
				if (!container) {
					return;
				}

				const addButton = document.getElementById('add-attendee');
				const addContainer = document.querySelector('.watf-add-attendee-wrapper');
				const progress = document.getElementById('watf-attendee-progress');
				const limitNote = document.getElementById('watf-attendee-limit-note');
				const limit = parseInt(container.dataset.attendeeLimit || '0', 10);
				const levelLabel = container.dataset.levelLabel || '';
				const attendeesProgressPrefix = '<?php echo esc_js(__('You have entered', 'watf')); ?>';
				const attendeesProgressSuffix = '<?php echo esc_js(__("attendees' information.", 'watf')); ?>';
				const existingList = document.getElementById('watf-existing-attendee-list');
				const existingCountNode = document.getElementById('watf-existing-count');
				const existingFeedback = document.getElementById('watf-existing-feedback');
				const existingCountTemplate = '<?php echo esc_js(__("%d attendees already registered", "watf")); ?>';
				const removeNonce = '<?php echo esc_js(wp_create_nonce('watf_remove_sponsor_attendee')); ?>';
				const sponsorRefValue = '<?php echo esc_js($sponsor_ref); ?>';
				const ajaxUrl = '<?php echo esc_url(admin_url('admin-ajax.php')); ?>';
				let existingAttendeesCount = <?php echo (int) $existing_count; ?>;
				const levelName = levelLabel || '<?php echo esc_js(__('Sponsorship', 'watf')); ?>';

				const updateProgress = () => {
					const formCount = container.querySelectorAll('.attendee-form').length;
					const totalCount = existingAttendeesCount + formCount;

					if (progress) {
						const maxDisplay = limit > 0 ? limit : Math.max(totalCount, 1);
						const text = levelName + ': ' + attendeesProgressPrefix + ' ' + totalCount + '/' + maxDisplay + ' ' + attendeesProgressSuffix;
						progress.textContent = text;
					}
					if (limitNote) {
						if (limit > 0 && totalCount >= limit) {
							if (window.wp && wp.i18n && wp.i18n.sprintf && wp.i18n.__) {
								limitNote.textContent = wp.i18n.sprintf(
									wp.i18n.__('You have reached the %d attendee limit for this sponsorship level.', 'watf'),
									limit
								);
							} else {
								limitNote.textContent = 'You have reached the ' + limit + ' attendee limit for this sponsorship level.';
							}
						} else if (limit > 0) {
							const remaining = limit - totalCount;
							if (window.wp && wp.i18n && wp.i18n.sprintf && wp.i18n.__) {
								limitNote.textContent = wp.i18n.sprintf(
									wp.i18n.__('%d spot(s) remaining.', 'watf'),
									remaining
								);
							} else {
								limitNote.textContent = remaining + ' spot(s) remaining.';
							}
						} else {
							limitNote.textContent = '';
						}
					}

					const reachedLimit = limit > 0 && totalCount >= limit;
					if (addContainer) {
						addContainer.classList.toggle('d-none', reachedLimit);
					}
				};

				const removalSuccessFallback = '<?php echo esc_js(__('Attendee deleted.', 'watf')); ?>';
				const removalErrorFallback = '<?php echo esc_js(__('Unable to delete attendee. Please try again.', 'watf')); ?>';

				const showExistingFeedback = (message, type = 'info') => {
					if (!existingFeedback) {
						return;
					}

					existingFeedback.textContent = message;
					existingFeedback.classList.remove('d-none', 'alert-success', 'alert-danger', 'alert-info');
					existingFeedback.classList.add('alert-' + (type === 'success' ? 'success' : 'danger'));
				};

				const handleExistingRemoval = (button) => {
					if (!button) {
						return;
					}

					const attendeeId = parseInt(button.dataset.attendeeId || '0', 10);
					if (!attendeeId) {
						return;
					}

					const listItem = button.closest('li');
					button.disabled = true;

					const payload = new FormData();
					payload.append('action', 'watf_remove_sponsorship_attendee');
					payload.append('attendee_id', attendeeId);
					payload.append('sponsor_ref', sponsorRefValue);
					payload.append('nonce', removeNonce);

					fetch(ajaxUrl, {
							method: 'POST',
							body: payload,
						})
						.then((response) => response.json())
						.then((payload) => {
							if (!payload.success) {
								throw new Error(payload.data?.message || removalErrorFallback);
							}

							if (listItem) {
								listItem.remove();
							}

							existingAttendeesCount = Number(payload.data?.remaining ?? existingAttendeesCount - 1);
							if (Number.isNaN(existingAttendeesCount) || existingAttendeesCount < 0) {
								existingAttendeesCount = Math.max(0, existingAttendeesCount);
							}
							updateExistingCountDisplay();
							updateProgress();
							showExistingFeedback(payload.data?.message || removalSuccessFallback, 'success');

							if (existingList && existingList.children.length === 0) {
								const wrapper = existingList.closest('.watf-existing-attendees');
								if (wrapper) {
									wrapper.classList.add('d-none');
								}
							}
						})
						.catch((error) => {
							showExistingFeedback(error.message || removalErrorFallback, 'danger');
						})
						.finally(() => {
							button.disabled = false;
						});
				};

				if (existingList) {
					existingList.addEventListener('click', function(event) {
						const button = event.target.closest('.watf-remove-attendee');
						if (!button) {
							return;
						}

						event.preventDefault();
						const proceed = () => handleExistingRemoval(button);
						if (window.Swal) {
							Swal.fire({
								icon: 'warning',
								title: '<?php echo esc_js(__('Delete attendee?', 'watf')); ?>',
								text: '<?php echo esc_js(__('This will permanently remove the attendee from your list.', 'watf')); ?>',
								showCancelButton: true,
								confirmButtonColor: '#d33',
								confirmButtonText: '<?php echo esc_js(__('Delete', 'watf')); ?>',
							}).then((result) => {
								if (result.isConfirmed) {
									proceed();
								}
							});
						} else {
							if (window.confirm('<?php echo esc_js(__('Are you sure you want to delete this attendee?', 'watf')); ?>')) {
								proceed();
							}
						}
					});
				}

				const updateExistingCountDisplay = () => {
					if (!existingCountNode) {
						return;
					}

					existingCountNode.innerHTML = existingCountTemplate.replace('%d', existingAttendeesCount);
				};

				updateExistingCountDisplay();
				updateProgress();

				const resetCloneValues = (clone, template) => {
					const org = template.querySelector('.watf-copy-organization')?.value || '';
					const street = template.querySelector('.watf-copy-street')?.value || '';
					const city = template.querySelector('.watf-copy-city')?.value || '';
					const state = template.querySelector('.watf-copy-state')?.value || '';
					const zip = template.querySelector('.watf-copy-zip')?.value || '';

					clone.querySelectorAll('input, textarea, select').forEach((field) => {
						if (field.matches('.watf-copy-organization')) {
							field.value = org;
							// } else if (field.matches('.watf-copy-badge')) {
							// 	field.value = badge;
						} else if (field.matches('.watf-copy-street')) {
							field.value = street;
						} else if (field.matches('.watf-copy-city')) {
							field.value = city;
						} else if (field.matches('.watf-copy-state')) {
							field.value = state;
						} else if (field.matches('.watf-copy-zip')) {
							field.value = zip;
						} else if (field.tagName === 'SELECT') {
							field.selectedIndex = 0;
						} else {
							field.value = '';
						}
					});
				};

				if (addButton) {
					addButton.addEventListener('click', function(e) {
						e.preventDefault();
						const forms = container.querySelectorAll('.attendee-form');
						if (limit > 0 && forms.length >= limit) {
							updateProgress();
							return;
						}

						const template = forms[0];
						if (!template) {
							return;
						}

						const clone = template.cloneNode(true);

						const heading = clone.querySelector('h5');
						if (heading) {
							heading.textContent = '<?php echo esc_js(__('Attendee', 'watf')); ?> ' + (forms.length + 1);
						}

						const removeBtn = clone.querySelector('.remove-attendee');
						if (removeBtn) {
							removeBtn.classList.remove('d-none');
						}

						resetCloneValues(clone, template);
						container.appendChild(clone);
						updateProgress();
					});
				}

				container.addEventListener('click', function(event) {
					const target = event.target.closest('.remove-attendee');
					if (!target) {
						return;
					}

					event.preventDefault();
					const card = target.closest('.attendee-form');
					if (!card) {
						return;
					}

					card.remove();
					container.querySelectorAll('.attendee-form').forEach((cardEl, index) => {
						const heading = cardEl.querySelector('h5');
						if (heading) {
							heading.textContent = '<?php echo esc_js(__('Attendee', 'watf')); ?> ' + (index + 1);
						}
						const removeBtn = cardEl.querySelector('.remove-attendee');
						if (removeBtn) {
							if (index === 0) {
								removeBtn.classList.add('d-none');
							} else {
								removeBtn.classList.remove('d-none');
							}
						}
					});
					updateProgress();
				});
			});
		</script>
		<?php if ($limit_error_fired) : ?>
			<script>
				if (window.Swal) {
					Swal.fire({
						icon: 'warning',
						title: '<?php echo esc_js(__('You have already reached the attendee limit for this sponsorship level.', 'watf')); ?>',
						text: '<?php echo esc_js(__('Please review your existing attendees before adding more.', 'watf')); ?>',
					});
				}
			</script>
		<?php endif; ?>
<?php
		return ob_get_clean();
	}
}
