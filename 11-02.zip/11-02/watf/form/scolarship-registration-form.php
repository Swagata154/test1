<?php

/**
 * Scholarship registration form shortcode.
 *
 * Usage: [scholarship_registration_form]
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!function_exists('watf_register_scholarship_registration_form_shortcode')) {
	function watf_register_scholarship_registration_form_shortcode()
	{
		add_shortcode('scholarship_registration_form', 'watf_render_scholarship_registration_form_shortcode');
	}
	add_action('init', 'watf_register_scholarship_registration_form_shortcode');
}
//Validation
add_action('init', 'watf_handle_scholarship_registration');

function watf_handle_scholarship_registration()
{
	if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

	if (
		empty($_POST['action']) ||
		$_POST['action'] !== 'watf_scholarship_register'
	) return;

	if (
		empty($_POST['watf_register_nonce']) ||
		!wp_verify_nonce($_POST['watf_register_nonce'], 'watf_scholarship_register')
	) {
		wp_safe_redirect(add_query_arg('register', 'security', wp_get_referer()));
		exit;
	}

	$first   = sanitize_text_field($_POST['first_name'] ?? '');
	$middle  = sanitize_text_field($_POST['middle_initial'] ?? '');
	$last    = sanitize_text_field($_POST['last_name'] ?? '');
	$phone   = sanitize_text_field($_POST['phone'] ?? '');
	$email   = sanitize_email($_POST['email'] ?? '');

	// Required field validation
	if (!$first || !$last || !$phone || !$email) {
		wp_safe_redirect(add_query_arg('register', 'missing', wp_get_referer()));
		exit;
	}

	if (!is_email($email)) {
		wp_safe_redirect(add_query_arg('register', 'invalid_email', wp_get_referer()));
		exit;
	}

	if (email_exists($email)) {
		wp_safe_redirect(add_query_arg('register', 'exists', wp_get_referer()));
		exit;
	}
}

if (!function_exists('watf_render_scholarship_registration_form_shortcode')) {
	/**
	 * Render the scholarship registration form.
	 *
	 * @param array<string, mixed> $atts Shortcode attributes.
	 * @return string
	 */
	function watf_render_scholarship_registration_form_shortcode($atts = [])
	{
		ob_start();
?>
		<div class="container px-3 pb-5">
			<form class="agm-registration-form scholarship-registration-form" method="post">
				<?php wp_nonce_field('watf_scholarship_register', 'watf_register_nonce'); ?>
				<input type="hidden" name="action" value="watf_scholarship_register">

				<div class="row g-4 align-items-end">

					<div class="col-12 col-md-4">
						<label class="form-label">First Name <span class="text-danger">*</span></label>
						<input type="text" class="form-control" name="first_name">
					</div>

					<div class="col-12 col-md-4">
						<label class="form-label">Middle Initial</label>
						<input type="text" class="form-control" name="middle_initial" maxlength="1">
					</div>

					<div class="col-12 col-md-4">
						<label class="form-label">Last Name <span class="text-danger">*</span></label>
						<input type="text" class="form-control" name="last_name">
					</div>

					<div class="col-12 col-md-5">
						<label class="form-label">Phone <span class="text-danger">*</span></label>
						<input type="tel" class="form-control" name="phone">
					</div>

					<div class="col-12 col-md-7">
						<label class="form-label">Email <span class="text-danger">*</span></label>
						<input type="email" class="form-control" name="email">
					</div>

					<div class="col-12 text-center">
						<button type="submit" class="btn btn-primary px-5 button1">
							SUBMIT
						</button>
					</div>

				</div>
			</form>
		</div>
<?php

		return ob_get_clean();
	}
}
