<?php
// Template Name: AGM Template

get_header();
?>

<style>
    .container {
        max-width: 1320px !important;
    }
</style>

<?php
$event  = get_field('42_event_section');
?>

<section class="event-section">
    <div class="px-3 pt-5">
        <div class="container pt-md-5 pb-md-3">
            <div class="row g-4 d-flex align-items-streach">
                <!-- Left Content -->
                <div class="col-lg-9">
                    <?php if (!empty($event['heading'])): ?>
                        <h2 class=" mb-3"><?php echo esc_html($event['heading']); ?></h2>
                    <?php endif; ?>

                    <?php if (!empty($event['subheading'])): ?>
                        <h5 class="fw-semibold mb-3"><?php echo esc_html($event['subheading']); ?></h5>
                    <?php endif; ?>

                    <?php if (!empty($event['top_description'])): ?>
                        <div class="mb-3 event-desc">
                            <?php echo wp_kses_post($event['top_description']); ?>
                        </div>
                    <?php endif; ?>
					
					<?php if (have_rows('agm_sponsors')) : ?>
						<section class="race-sponsors py-2">
							<div class="container text-center">

								<?php while (have_rows('agm_sponsors')) : the_row(); 
									$heading = get_sub_field('heading');
								?>

									<?php if (have_rows('sponsor_logos')) : ?>
										<div class="sponsor-group mb-5">
											<?php if ($heading) : ?>
												<h2 class="fw-bold mb-4"><?= esc_html($heading); ?></h2>
											<?php endif; ?>

											<div class="d-flex flex-wrap justify-content-evenly pt-4 custom-border">
												<?php while (have_rows('sponsor_logos')) : the_row(); 
													$logo = get_sub_field('logo_image');
													$link = get_sub_field('logo_link');
												?>

													<?php if ($logo) : ?>
														<div class="m-2">
															<?php if ($link) : ?>
																<a href="<?= esc_url($link); ?>" target="_blank" rel="noopener">
																	<img src="<?= esc_url($logo['url']); ?>" alt="<?= esc_attr($logo['alt']); ?>" class="sponsor-img">
																</a>
															<?php else : ?>
																<img src="<?= esc_url($logo['url']); ?>" alt="<?= esc_attr($logo['alt']); ?>" class="sponsor-img">
															<?php endif; ?>
														</div>
													<?php endif; ?>

												<?php endwhile; ?>
											</div>
										</div>
									<?php endif; ?>

								<?php endwhile; ?>

							</div>
						</section>
					<?php endif; ?>

					
					<?php if (!empty($event['bottom_description'])): ?>
                        <div class="mb-3 event-desc">
                            <?php echo wp_kses_post($event['bottom_description']); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Right Side Images -->
                <div class="col-lg-3">
                    <?php if (!empty($event['right_side_image'])): ?>
                        <div class="d-flex flex-column gap-3">
                            <?php foreach ($event['right_side_image'] as $row):
                                $img = $row['event_image'];
                                if (!$img) continue;
                            ?>
                                <img src="<?php echo esc_url($img['url']); ?>"
                                    alt="<?php echo esc_attr($img['alt']); ?>"
                                    class="img-fluid rounded shadow-sm">
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

	


    <!-- 3rd section -->

    <?php if (have_rows('race_links_section')): ?>
        <section class="pb-5 race-links">
            <div class="container">
                <div class="row justify-content-start text-start">
                    <?php while (have_rows('race_links_section')): the_row();
                        $heading = get_sub_field('link_heading');
                        $btn_text = get_sub_field('button_text');
                        $btn_url  = get_sub_field('button_link');
                    ?>
                        <div class="col-md-6 mb-4">
                            <?php if ($heading): ?>
                                <h3 class="fw-bold mb-3"><?php echo esc_html($heading); ?></h3>
                            <?php endif; ?>

                            <?php if ($btn_text): ?>
                                <?php if ($btn_url): ?>
                                    <a href="<?php echo esc_url($btn_url); ?>" class="button1">
                                        <?php echo esc_html($btn_text); ?>
                                    </a>
                                <?php else: ?>
                                    <span class="button1">
                                        <?php echo esc_html($btn_text); ?>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>


</section>


<?php

get_footer();
?>