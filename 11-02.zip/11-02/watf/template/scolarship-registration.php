<?php
// Template Name: Scolarship Registration
get_header();
?>
<div class="agm_sponsorship_commitment_form_banner py-3 px-3 mt-2">
    <div class="container text-center">
        <h2><span>DULLES AIRPORT</span> SCHOLARSHIP PROGRAM</h2>
        <div class="col-12">
            <img class="w-50" src="<?php echo get_template_directory_uri(); ?>/assets/images/Dulles20airport20scholarship20logo-1024x252.png" alt="" style="width: 250px;">
        </div>
    </div>
</div>
<div class="watf-agm-sponsorship-form container px-3 pb-5">
    <p class="para1 text-center mb-2">Scholarship Application Registration</p>
</div>
<!-- Scholarship_registration_form -->
<?php if (isset($_GET['register'])) : ?>
    <p class="register-error text-center text-danger">
        <?php
        switch ($_GET['register']) {
            case 'missing':
                echo 'All required fields must be filled.';
                break;
            case 'invalid_email':
                echo 'Invalid email address.';
                break;
            case 'exists':
                echo 'Email already registered.';
                break;
            case 'security':
                echo 'Security check failed.';
                break;
            default:
                echo 'Registration failed.';
                break;
        }
        ?>
    </p>
<?php endif; ?>
<?php echo do_shortcode('[scholarship_registration_form]'); ?>
<?php
get_footer();
?>