<?php

/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package watf
 */

get_header();
?>

<main id="primary" class="site-main py-5">
	<div class="container px-3 px-lg-5 py-md-3" style="max-width:1320px !important;">
		<?php
		if (
			function_exists('yoast_breadcrumb') &&
			!in_array(get_post_field('post_name', get_post()), ['thank-you', 'thank-you-2', 'thank-you-4'])
		) :
		?>
			<nav class="breadcrumb-wrapper" aria-label="Breadcrumb">
				<?php yoast_breadcrumb('<p id="breadcrumbs">', '</p>'); ?>
			</nav>
		<?php endif; ?> 
		
		<?php
		while (have_posts()) :
			the_post();

			get_template_part('template-parts/content', 'page');


		endwhile; // End of the loop.
		?>
	</div>
</main>

<?php
get_footer();
?>

<style>
	#breadcrumbs * {
		text-transform: uppercase;
	}
</style>