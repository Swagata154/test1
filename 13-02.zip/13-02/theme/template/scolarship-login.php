<?php
// Template Name: Scolarship Login
get_header();
?>
<div class="agm_sponsorship_commitment_form_banner py-3 px-3 mt-2">
    <div class="container text-center">
        <h2><span>DULLES AIRPORT</span> SCHOLARSHIP PROGRAM</h2>
        <div class="col-12">
            <img class="w-50" src="<?php echo get_template_directory_uri(); ?>/assets/images/Dulles20airport20scholarship20logo-1024x252.png" alt="" style="width: 250px;">
        </div>
    </div>
</div>
<div class="watf-agm-sponsorship-form container px-3 pb-3">
    <p class="para1 text-center mb-2">Scholarship Application Login</p>
</div>
<!-- Scholarship_login_form -->
<?php if (isset($_GET['login'])) : ?>
    <p class="login-error text-danger text-center">
        <?php
        switch ($_GET['login']) {
            case 'failed':
                echo 'Invalid email or password.';
                break;
            case 'empty':
                echo 'All fields are required.';
                break;
            case 'empty_email':
                echo 'Email is required.';
                break;
            case 'otp_sent':
                echo 'OTP sent to your email.';
                break;
            case 'otp_failed':
                echo 'Invalid or expired OTP.';
                break;
            case 'invalid_nonce':
                echo 'Security check failed. Please try again.';
                break;
        }
        ?>
    </p>
<?php endif; ?>

<?php echo do_shortcode('[scholarship_login_form]'); ?>
<?php
get_footer();
?>