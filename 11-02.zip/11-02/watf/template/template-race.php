<?php
// Template Name: Race Template

get_header();
?>

<style>
    .container {
        max-width: 1320px !important;
    }
</style>

<?php
$banner = get_field('top_banner_image');
$event  = get_field('event_section');
?>

<?php if ($banner): ?>
    <section class="event-banner">
        <img src="<?php echo esc_url($banner['url']); ?>"
            alt="<?php echo esc_attr($banner['alt']); ?>"
            class="img-fluid w-100">
    </section>
<?php endif; ?>

<section class="event-section py-5">
    <div class="px-3 pb-5">
        <div class="container py-md-5">
            <div class="row g-4 d-flex align-items-streach">
                <!-- Left Content -->
                <div class="col-lg-8">
                    <?php if (!empty($event['heading'])): ?>
                        <h2 class=" mb-3"><?php echo esc_html($event['heading']); ?></h2>
                    <?php endif; ?>

                    <?php if (!empty($event['subheading'])): ?>
                        <h5 class="fw-semibold mb-3"><?php echo esc_html($event['subheading']); ?></h5>
                    <?php endif; ?>

                    <?php if (!empty($event['description'])): ?>
                        <div class="mb-3 event-desc">
                            <?php echo wp_kses_post($event['description']); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Right Side Images -->
                <div class="col-lg-4">
                    <?php if (!empty($event['right_side_image'])): ?>
                        <div class="d-flex flex-column gap-3">
                            <?php foreach ($event['right_side_image'] as $row):
                                $img = $row['event_image'];
                                if (!$img) continue;
                            ?>
                                <img src="<?php echo esc_url($img['url']); ?>"
                                    alt="<?php echo esc_attr($img['alt']); ?>"
                                    class="img-fluid rounded shadow-sm">
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


    <!-- 2nd section -->

    <?php if (get_field('race_sponsors_heading')): ?>
        <section class="py-5 px-3 race-sponsors" style="background-color:#f8f9fa;">
            <div class="container py-md-3 text-center">

                <?php if (get_field('race_sponsors_heading')): ?>
                    <h2 class="sponsors_heading fw-bold mb-5">
                        <?php the_field('race_sponsors_heading'); ?>
                    </h2>
                <?php endif; ?>

                <?php if( have_rows('race_sponsors', 'option') ): ?>
						<section class="race-sponsors">
							<div class="container text-center">

								<?php while( have_rows('race_sponsors', 'option') ): the_row(); 
									$heading = get_sub_field('heading');
									if( have_rows('sponsor_logos') ):
								?>
								<div class="sponsor-group">
									<h2 class="fw-bold mb-4"><?= esc_html($heading); ?></h2>
									<div class="d-flex flex-wrap justify-content-evenly justify-content-lg-evenly mb-5 pt-5 custom-border">
										<?php while( have_rows('sponsor_logos') ): the_row(); 
											$logo = get_sub_field('logo_image');
											$link = get_sub_field('logo_link');
											if( $logo ): ?>
												<?php if( $link ): ?>
													<a href="<?= esc_url($link); ?>" target="_blank" class="m-2">
														<img src="<?= esc_url($logo['url']); ?>" alt="<?= esc_attr($logo['alt']); ?>" class="sponsor-img">
													</a>
												<?php else: ?>
													<img src="<?= esc_url($logo['url']); ?>" alt="<?= esc_attr($logo['alt']); ?>" class="sponsor-img m-2">
												<?php endif; ?>
											<?php endif; ?>
										<?php endwhile; ?>
									</div>
								<?php endif; endwhile; ?>
								</div>
							</div>
						</section>
					<?php endif; ?>


            </div>
        </section>
    <?php endif; ?>

    <!-- 3rd section -->

    <?php if (get_field('sponsors_heading') || get_field('sponsors_description')): ?>
        <section class="pt-5 px-3 race-sponsors">
            <div class="container py-md-3 text-center">

                <div class="col-md-9 col-lg-8 text-start">
                    <?php if (get_field('sponsors_heading')): ?>
                        <h2 class="sponsors_heading fw-bold mb-3">
                            <?php the_field('sponsors_heading'); ?>
                        </h2>
                    <?php endif; ?>

                    <?php if ($sponsor_desc = get_field('sponsors_description')): ?>

                        <?= $sponsor_desc; ?>

                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
	<section class="container pt-5 px-3">
	<a href="<?= site_url('/2025-dulles-5k-10k-on-the-runway/');?>" class="button1" style="width:250px;">Archived Races</a>
</section>
</section>



<?php
get_footer();
?>