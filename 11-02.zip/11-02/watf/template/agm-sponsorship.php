<?php
// Template Name: AGM Sponsorship Template

get_header();
?>
<?php

$rsvp = get_field( 'rsvp' , 'option');

?>
<!-- BANNER -->
<div class="agm_sponsorship_commitment_form_banner py-3 px-3 mt-5">
    <div class="container text-center">
        <h2><span>AGM</span> SPONSORSHIP COMMITMENT FORM</h2>
        <h1>Eye on the Future with the Skies of Tomorrow</h1>
        <div class="row text-center align-items-center">
            <div class="col-12 col-md-4">
                <p>43rd Annual General <br>Meeting</p>
            </div>
            <div class="col-12 col-md-4">
                <img class="w-50" src="<?php echo get_template_directory_uri(); ?>/assets/images/Bitmap.jpg" alt="" style="width: 250px;">
            </div>
            <div class="col-12 col-md-4">
                <p>Williams Trophy Award<br> Presentation</p>
            </div>
        </div>        
        <p class="date">Tuesday, December 2, 2025 | 11am-2pm</p>
        <p class="loc">Belmont Country Club, 19661 Belmont Manor Ln., Ashburn, VA 20147</p>
      
        <?php if (!empty($rsvp)): ?>
            <p class="rsvp"><?php echo ($rsvp); ?></p>
        <?php endif; ?>
    </div>
</div>

<!-- SECTION2 -->
<div class="agm_sponsorship_commitment_form_section2 py-4 px-3">
    <div class="container">
        <p>As we honor the visionaries redefining the future of aviation, we invite you to help us <span>soar toward tomorrow</span> by sponsoring the 43rd Annual General Meeting and Williams Trophy Award. Our theme, <em>“Eye on the Future with the Skies of Tomorrow,”</em> celebrates the innovation, technology, and collaboration that continue to propel our industry forward.</p>
        <h2 class="text-center">Why Sponsor?</h2>
        <p>By becoming a sponsor, you will.</p>
        <ul>
            <li><span>Gain prominent recognition</span> before an audience of aviation leaders, policymakers, and innovators.</li>
            <li><span>Showcase your commitment to the future of flight</span>, sustainability, and technological excellence.</li>
            <li><span>Engage directly</span> with this year’s honorees and stakeholders during our exclusive networking reception and technology showcase.</li>
        </ul>
        <h2 class="text-center">Make an Impact</h2>
        <p>By sponsoring this event, your organization showcases its dedication to driving excellence, innovation, and growth across the aerospace sector.</p>
        <p class="para text-center">Commitments must be received no later than November 20, 2025, for your company name to appear in the printed program.</p>
    </div>
</div>

<!-- Sponsorship Levels -->
 
<div class="agm_sponsorship_commitment_form_section3 py-4 mb-4 px-3">
    <div class="container text-center">
        <h2 class="pb-4">Sponsorship Levels</h2>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 justify-content-center">
            <div class="col py-4">
                <div class="box px-3">
                    <h3>PREMIER SPONSOR</h3>
                    <p class="price">$10,000</p>
                    <p>Five exclusive seats at a center stage table, three designated tables for 10, prominent company recognition as Premier Sponsor on signage throughout the event, in the printed program, and by the Master of Ceremonies.</p>
                </div>
            </div>
            <div class="col py-4">
                <div class="box px-3">
                    <h3>PLATINUM SPONSOR</h3>
                    <p class="price">$5,000</p>
                    <p>Two exclusive seats at a center stage table, two designated tables for 10, prominent company recognition as a Platinum Sponsor on signage throughout the event, in the printed program, and by the Master of Ceremonies.</p>
                </div>
            </div>
            <div class="col py-4">
                <div class="box px-3">
                    <h3>GOLD SPONSOR</h3>
                    <p class="price">$2,500</p>
                    <p>One designated table for 10, prominent recognition as a Gold Sponsor on signage throughout the program, in the printed program, and by the Master of Ceremonies.</p>
                </div>
            </div>
            <div class="col py-4">
                <div class="box px-3">
                    <h3>SILVER SPONSOR</h3>
                    <p class="price">$1,250</p>
                    <p>Eight seats at a table, recognition as a Silver Sponsor on signage and in the printed program.</p>
                </div>
            </div>
            <div class="col py-4">
                <div class="box px-3">
                    <h3>BRONZE SPONSOR</h3>
                    <p class="price">$750</p>
                    <p>Six seats at a table. Recognition as Bronze Sponsor on signage and in the printed program.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- AGM_registration_form -->
<?php echo do_shortcode('[agm_sponsorship_form]'); ?>
<?php
get_footer();
?>
