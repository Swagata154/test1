<?php
// Template Name: Scolarship Application Form
get_header();
?>
<div class="agm_sponsorship_commitment_form_banner py-3 px-3 mt-2">
    <div class="container text-center">
        <h2><span>DULLES AIRPORT</span> SCHOLARSHIP PROGRAM</h2>
        <div class="col-12">
            <img class="w-50" src="<?php echo get_template_directory_uri(); ?>/assets/images/Dulles20airport20scholarship20logo-1024x252.png" alt="" style="width: 250px;">
        </div>
    </div>
</div>
<div class="watf-agm-sponsorship-form container px-3 pb-3">
    <p class="para1 text-center mb-2">Scholarship Application Form</p>
</div>
<!-- Scholarship_application_form -->
<?php echo do_shortcode('[scholarship_application_form]'); ?>
<?php
get_footer();
?>