<?php
// Template Name: Scholarship Template
get_header();
?>





<?php
get_footer();
?>