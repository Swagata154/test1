<?php
// Template Name: BOD Template
get_header();
?>


<section class="board-directors px-3 py-5">
    <div class="container py-md-5" style="max-width: 1320px !important;">

        <!-- Board of Directors -->
        <?php if (get_field('bod_heading')): ?>
            <h1 class="fw-bold mb-3"><?php the_field('bod_heading'); ?></h1>
            <div class="mb-4">
                <?php the_field('bod_description'); ?>
            </div>
        <?php endif; ?>

        <!-- Executive Committee -->
        <?php if (get_field('executive_heading')): ?>
            <h2 class="fw-bold mb-3"><?php the_field('executive_heading'); ?></h2>
            <div class="mb-3">
                <?php the_field('executive_description'); ?>
            </div>
        <?php endif; ?>

        <!-- Corporate Officers -->
        <?php if (have_rows('corporate_officers')): ?>
            <h2 class="fw-bold mb-4">Corporate Officers</h2>
            <div class="row g-4">
                <?php
                $i = 0;
                while (have_rows('corporate_officers')): the_row();
                    $i++;
                    $image    = get_sub_field('officer_image');
                    $name     = get_sub_field('officer_name');
                    $position = get_sub_field('officer_position');
                    $bio      = get_sub_field('officer_bio');
                ?>
                    <div class="col-md-6">
                        <div class="card shadow-sm">

                            <!-- Card Header (Clickable) -->
                            <div class="card-body d-flex align-items-center px-4 header-toggle cursor-pointer"
                                data-bs-target="#officer-<?php echo $i; ?>"
                                aria-expanded="false"
                                aria-controls="officer-<?php echo $i; ?>">

                                <?php if ($image): ?>
                                    <img src="<?php echo esc_url($image['url']); ?>"
                                        alt="<?php echo esc_attr($name); ?>"
                                        class="me-3 bod_img"
                                        style="width:100px; height:100px; object-fit:cover;">
                                <?php endif; ?>

                                <div>
                                    <h5 class="name mb-1"><?php echo esc_html($name); ?></h5>
                                    <p class="mb-0 role"><?php echo esc_html($position); ?></p>
                                </div>

                                <i class="fa-solid fa-angle-down  fa-xl ms-auto chevron"></i>
                            </div>

                            <!-- Accordion Body -->
                            <div id="officer-<?php echo $i; ?>" class="accordion-collapse collapse">
                                <div class="card-body bio border-top">
                                    <?php echo wp_kses_post($bio); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                    // Insert BOD Listing section AFTER 4 cards
                    if ($i === 4 && get_field('bod_listing_heading')): ?>
            </div> <!-- close .row -->

            <section class="pt-5">
                <h2 class="fw-bold mb-3"><?php the_field('bod_listing_heading'); ?></h2>
                <div class="mb-3">
                    <?php the_field('bod_listing_details'); ?>
                </div>
            </section>

            <div class="row g-4 mt-4"><!-- start new row for remaining officers -->
            <?php endif; ?>

        <?php endwhile; ?>
            </div><!-- end row -->
        <?php endif; ?>


        <!-- last section -->
        <section class="py-5">
            <?php if (have_rows('bod_groups')): ?>
                <?php $group_index = 0; ?>
                <?php while (have_rows('bod_groups')): the_row();
                    $group_index++; ?>

                    <h2 class="fw-bold mb-3">
                        <?php the_sub_field('group_heading'); ?>
                    </h2>

                    <div class="row g-0 mb-4">
                        <?php
                        $j = 0;
                        while (have_rows('group_members')): the_row();
                            $j++;
                            $details = get_sub_field('member_details');
                            $bio     = get_sub_field('members_bio');

                            // Unique collapse ID
                            $collapse_id = 'collapse-' . $group_index . '-' . $j;
                        ?>
                            <div class="col-md-12">
                                <div class="card shadow-sm">

                                    <!-- Card Header (clickable) -->
                                    <div class="card-body d-flex align-items-center px-4 header-toggle cursor-pointer"
                                        data-bs-target="#<?php echo esc_attr($collapse_id); ?>"
                                        aria-expanded="false"
                                        aria-controls="<?php echo esc_attr($collapse_id); ?>">

                                        <div>
                                            <h5 class="mem_details mb-0"><?php echo esc_html($details); ?></h5>
                                        </div>

                                        <i class="fa-solid fa-angle-down  fa-xl ms-auto chevron"></i>
                                    </div>

                                    <!-- Accordion Body -->
                                    <div id="<?php echo esc_attr($collapse_id); ?>" class="accordion-collapse collapse">
                                        <div class="card-body bio border-top">
                                            <?php echo wp_kses_post($bio); ?>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </section>




    </div>
</section>







<?php
get_footer();
?>

<style>
    .fa-angle-down {
        color: #212529;
        opacity: 0.5;
    }
</style>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        const headers = document.querySelectorAll('.header-toggle[data-bs-target]');

        headers.forEach(function(header) {
            const selector = header.getAttribute('data-bs-target');
            if (!selector) return;

            const collapseEl = document.querySelector(selector);
            if (!collapseEl) return;

            const icon = header.querySelector('.chevron');

            header.addEventListener('click', function(e) {
                if (e.target.closest('a') || e.target.closest('button')) return;

                // Close all other collapses instantly
                headers.forEach(function(otherHeader) {
                    const otherSelector = otherHeader.getAttribute('data-bs-target');
                    const otherCollapse = document.querySelector(otherSelector);
                    const otherIcon = otherHeader.querySelector('.chevron');

                    if (otherCollapse !== collapseEl) {
                        bootstrap.Collapse.getOrCreateInstance(otherCollapse, {
                            toggle: false
                        }).hide();
                        otherHeader.classList.remove('open');
                        if (otherIcon) otherIcon.classList.remove('rotated');
                        otherHeader.setAttribute('aria-expanded', 'false');
                    }
                });

                // Toggle clicked collapse instantly
                const bsCollapse = bootstrap.Collapse.getOrCreateInstance(collapseEl, {
                    toggle: false
                });
                bsCollapse.toggle();

                // Toggle clicked header styles instantly
                header.classList.toggle('open');
                if (icon) icon.classList.toggle('rotated');
                header.setAttribute('aria-expanded', collapseEl.classList.contains('show'));
            });

            
            collapseEl.addEventListener('shown.bs.collapse', function() {
                header.setAttribute('aria-expanded', 'true');
                header.classList.add('open');
                if (icon) icon.classList.add('rotated');
            });

            collapseEl.addEventListener('hidden.bs.collapse', function() {
                header.setAttribute('aria-expanded', 'false');
                header.classList.remove('open');
                if (icon) icon.classList.remove('rotated');
            });
        });

        
    });
</script>