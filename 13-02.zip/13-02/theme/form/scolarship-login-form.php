<?php

/**
 * Scholarship login form shortcode.
 *
 * Usage: [scholarship_login_form]
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('watf_register_scholarship_login_form_shortcode')) {
    function watf_register_scholarship_login_form_shortcode()
    {
        add_shortcode('scholarship_login_form', 'watf_render_scholarship_login_form_shortcode');
    }
    add_action('init', 'watf_register_scholarship_login_form_shortcode');
}

if (!function_exists('watf_render_scholarship_login_form_shortcode')) {
    /**
     * Render the scholarship login form.
     *
     * @param array<string, mixed> $atts Shortcode attributes.
     * @return string
     */
    function watf_render_scholarship_login_form_shortcode($atts = [])
    {
        $atts = shortcode_atts(
            [
                'redirect_url'      => '',
                'register_url'      => '',
                'lost_password_url' => '',
            ],
            $atts,
            'scholarship_login_form'
        );

        ob_start();
?>
        <div class="scholarship-login-wrapper mt-0">
            <div class="scholarship-login-box">
                <h3><?php esc_html_e('APPLICANT LOGIN', 'watf'); ?></h3>
                <form id="watf-login-form" class="scholarship-login-form" method="post">
                    <input type="text" name="log" placeholder="<?php echo esc_attr__('Email', 'watf'); ?>" autocomplete="username">
                    <input type="password" name="pwd" placeholder="<?php echo esc_attr__('Password', 'watf'); ?>" autocomplete="current-password">
                    <input type="submit" value="<?php echo esc_attr__('SUBMIT', 'watf'); ?>">
                </form>

                <form id="watf-otp-form" class="scholarship-login-form" method="post" style="display:none;">
                    <input type="hidden" name="log" id="watf-otp-email">
                    <input type="text" name="otp_code" placeholder="<?php echo esc_attr__('OTP Code', 'watf'); ?>" autocomplete="one-time-code">
                    <input type="submit" value="<?php echo esc_attr__('VERIFY OTP', 'watf'); ?>">
                </form>
                <form id="watf-forgot-form" class="scholarship-login-form" method="post" style="display:none;">
                    <input type="text" name="forgot_email"
                        placeholder="<?php echo esc_attr__('Email', 'watf'); ?>"
                        required>
                    <input type="submit"
                        value="<?php echo esc_attr__('Reset Password', 'watf'); ?>">
                </form>
                <div id="watf-login-message"></div>
            </div>
            <div>
                Not Registered Yet? <a href="<?= site_url() ?>/scholarship-registration/" style="font-size: 16px; text-decoration: none; font-weight: bold;">CLICK HERE</a>
            </div>
            <div>
                Forgot Password? <a href="#" id="watf-show-forgot" style="font-size: 16px; text-decoration: none; font-weight: bold;">CLICK HERE</a>
            </div>
        </div>
<?php
        return ob_get_clean();
    }
}
