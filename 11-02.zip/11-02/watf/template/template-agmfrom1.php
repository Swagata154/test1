<?php
// Template Name: Agm From Template

get_header();
?>
<?php
$heading_1 = get_field( 'heading_1' , 'option');
$heading_2 = get_field( 'heading_2' , 'option');
$text1 = get_field( 'text1' , 'option');
$image = get_field( 'image' , 'option');
$text2 = get_field( 'text2' , 'option');
$date = get_field( 'date' , 'option');
$location = get_field( 'location' , 'option');
$rsvp = get_field( 'rsvp' , 'option');
$thank_given = get_field( 'thank_given');
$please_note = get_field( 'please_note');
$pay_online_text = get_field( 'pay_online_text');
$pay_link = get_field( 'pay_link');
?>
<!-- Banner -->
<div class="agm-registration-form_banner py-3 mt-5 px-3">
    <div class="container text-center">

        <?php if (!empty($heading_1)): ?>
            <h2 class="py-1"><?php echo ($heading_1); ?></h2>
        <?php endif; ?>

        <?php if (!empty($heading_2)): ?>
            <h1><?php echo ($heading_2); ?></h1>
        <?php endif; ?>

        <div class="row text-center align-items-center">

            <?php if (!empty($text1)): ?>
                <div class="col-12 col-sm-4">
                    <p><?php echo ($text1); ?></p>
                </div>
            <?php endif; ?>

            <?php if (!empty($image)): ?>
                <div class="col-12 col-sm-4">
                    <img class="img-fluid w-50"
                         src="<?php echo esc_url($image['url']); ?>"
                         alt="<?php echo esc_attr($image['alt'] ?? $image['filename']); ?>" style="width:250px;">
                </div>
            <?php endif; ?>

            <?php if (!empty($text2)): ?>
                <div class="col-12 col-sm-4">
                    <p><?php echo ($text2); ?></p>
                </div>
            <?php endif; ?>

        </div>

        <?php if (!empty($date)): ?>
            <p class="date"><?php echo ($date); ?></p>
        <?php endif; ?>

        <?php if (!empty($location)): ?>
            <p class="loc"><?php echo ($location); ?></p>
        <?php endif; ?>

        <?php if (!empty($rsvp)): ?>
            <p class="rsvp"><?php echo ($rsvp); ?></p>
        <?php endif; ?>

    </div>
</div>

<div class="agm-registration-form_section2 py-3 px-3 text-center">
    <div class="container">
        <?php if (!empty($thank_given)): ?>
            <p><?php echo ($thank_given); ?></p>
        <?php endif; ?>
    </div>
</div>

<div class="agm-registration-form_section3 text-center py-3 px-3">
    <div class="container">

        <?php if (!empty($please_note)): ?>
            <p class="para1"><?php echo ($please_note); ?></p>
        <?php endif; ?>

        <?php if (!empty($pay_online_text)): ?>
            <p class="para2"><?php echo ($pay_online_text); ?><a href="<?php echo ($pay_link["url"]); ?>"><?php echo ($pay_link["title"]); ?></a></p>
        <?php endif; ?>

    </div>
</div>


<!-- agm_checkout_popup -->
<?php echo do_shortcode('[agm_checkout_popup]'); ?>
<!-- AGM_registration_form -->
<?php echo do_shortcode('[agm_registration_form]'); ?>
<?php
get_footer();
?>

