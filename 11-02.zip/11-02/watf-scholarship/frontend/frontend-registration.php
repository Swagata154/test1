<?php

if (!defined('ABSPATH')) {
    exit;
}

add_action('user_register', 'watf_scholarship_assign_applicant_role', 10, 1);
add_action('init', 'watf_scholarship_handle_registration');
add_action('after_setup_theme', 'watf_scholarship_disable_theme_registration_handler', 20);
add_action('wp_logout', 'watf_scholarship_redirect_applicant_logout');

function watf_scholarship_assign_applicant_role($user_id)
{
    if (
        empty($_POST['action']) ||
        $_POST['action'] !== 'watf_scholarship_register'
    ) {
        return;
    }

    $user = get_user_by('id', $user_id);
    if (!$user) {
        return;
    }

    $user->set_role('scholarship_applicant');

    $first  = sanitize_text_field($_POST['first_name'] ?? '');
    $middle = sanitize_text_field($_POST['middle_initial'] ?? '');
    $last   = sanitize_text_field($_POST['last_name'] ?? '');
    $phone  = sanitize_text_field($_POST['phone'] ?? '');
    $email  = sanitize_email($_POST['email'] ?? '');

    if (!$first || !$last || !$email) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'watf_applicants';

    $wpdb->insert(
        $table_name,
        [
            'user_id'        => $user_id,
            'first_name'     => $first,
            'middle_initial' => $middle,
            'last_name'      => $last,
            'phone'          => $phone,
            'email'          => $email,
        ],
        [
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
        ]
    );
}

function watf_scholarship_disable_theme_registration_handler()
{
    if (function_exists('watf_handle_scholarship_registration')) {
        remove_action('init', 'watf_handle_scholarship_registration');
    }
}

function watf_scholarship_redirect_applicant_logout()
{
    $user = wp_get_current_user();
    if (!$user || empty($user->roles)) {
        return;
    }

    if (in_array('scholarship_applicant', (array) $user->roles, true)) {
        wp_safe_redirect(home_url('/scholarship-login/'));
        exit;
    }
}

function watf_scholarship_handle_registration()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    if (
        empty($_POST['action']) ||
        $_POST['action'] !== 'watf_scholarship_register'
    ) {
        return;
    }

    if (
        empty($_POST['watf_register_nonce']) ||
        !wp_verify_nonce($_POST['watf_register_nonce'], 'watf_scholarship_register')
    ) {
        wp_safe_redirect(add_query_arg('register', 'security', wp_get_referer()));
        exit;
    }

    $first   = sanitize_text_field($_POST['first_name'] ?? '');
    $middle  = sanitize_text_field($_POST['middle_initial'] ?? '');
    $last    = sanitize_text_field($_POST['last_name'] ?? '');
    $phone   = sanitize_text_field($_POST['phone'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');

    if (!$first || !$last || !$phone || !$email) {
        wp_safe_redirect(add_query_arg('register', 'missing', wp_get_referer()));
        exit;
    }

    if (!is_email($email)) {
        wp_safe_redirect(add_query_arg('register', 'invalid_email', wp_get_referer()));
        exit;
    }

    if (email_exists($email)) {
        wp_safe_redirect(add_query_arg('register', 'exists', wp_get_referer()));
        exit;
    }

    // Wordpress generated 12 character password
    $password = wp_generate_password(12, true);
    $user_id  = wp_create_user($email, $password, $email);

    if (is_wp_error($user_id)) {
        wp_safe_redirect(add_query_arg('register', 'failed', wp_get_referer()));
        exit;
    }

    // Send Login Email
    $login_url = home_url('/scholarship-login/');
    $subject = 'Your Scholarship Account Details';
    $message = "
        Hello $first,

        Your scholarship applicant account has been successfully created.

        Login Details:

        Email: $email
        Password: $password

        Login here:
        $login_url

        For security reasons, we recommend changing your password after first login.

        Thank you.
        ";
    $headers = ['Content-Type: text/plain; charset=UTF-8'];
    wp_mail($email, $subject, $message, $headers);

    wp_update_user([
        'ID'           => $user_id,
        'first_name'   => $first,
        'last_name'    => $last,
        'display_name' => trim("$first $middle $last"),
    ]);

    update_user_meta($user_id, 'phone', $phone);
    update_user_meta($user_id, 'middle_initial', $middle);

    wp_safe_redirect(site_url() . '/scholarship-login/');
    exit;
}
