<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package watf
 */

?>

<style>
	#scrollToTopBtn {
		position: fixed;
		bottom: 65px;
		right: 40px;
		z-index: 99999;
		background: linear-gradient(135deg, #cb7721, #b31250);
		color: #fff;
		border: none;
		outline: none;
		width: 48px;
		height: 48px;
		border-radius: 50%;
		cursor: pointer;
		font-size: 20px;
		display: flex;
		align-items: center;
		justify-content: center;
		transition: all 0.4s ease-in-out;
	}

	#scrollToTopBtn i {
		position: absolute;
		font-size: 18px;
	}

	.progress-ring {
		transform: rotate(-90deg);
		position: absolute;
		top: 0;
		left: 0;
	}

	.progress-ring__circle {
		transition: stroke-dashoffset 0.3s ease;
		stroke-linecap: round;
	}

	#scrollToTopBtn:hover {
		background: linear-gradient(135deg, #ffae5f, #6b0f49);
		transform: scale(1.1);
	}

	@media screen and (max-width:768px) {
		#scrollToTopBtn {
			bottom: 40px;
			right: 20px;
		}
	}
</style>

<?php
/**
 * Footer Template
 */

// ACF Options
$footer_logo        = get_field('footer_logo', 'option');
$footer_description = get_field('footer_description', 'option');
$linkedin_link      = get_field('linkedin_link', 'option');
$facebook_link      = get_field('facebook_link', 'option');
$instagram_link     = get_field('instagram_link', 'option');
?>

<footer class="site-footer">
	<!-- Top Section -->
	<div class="footer-top">
		<div class="container-fluid">
			<div class="row">

				<!-- Left Column -->
				<div class="col-12 col-sm-9 col-md-12 col-lg-4 mb-3">
					<?php if ($footer_logo): ?>
						<a href="<?= esc_url(site_url('/')) ?>" class="footer-logo text-center text-lg-start d-block mb-3">
							<img src="<?php echo esc_url($footer_logo['url']); ?>" alt="Footer Logo" class="img-fluid" style="max-height:60px;">
						</a>
					<?php endif; ?>

					<?php if ($footer_description): ?>
						<div class="footer-description text-center text-lg-start mb-4">
							<?php echo esc_html($footer_description); ?>
						</div>
					<?php endif; ?>
				</div>

				<!-- Middle Column (Menu 1) -->
				<div class="col-6 col-md-6 col-lg-3 offset-xl-2">
					<h4 class="fw-bold mb-3 footer-heading">About WATF</h4>
					<?php
					wp_nav_menu(array(
						'theme_location' => 'footer1',
						'menu_class'     => 'list-unstyled footer-menu',
						'container'      => false,
					));
					?>
				</div>

				<!-- Right Column (Menu 2) -->
				<div class="col-6 col-md-6  col-lg-3">
					<h4 class="fw-bold mb-3 footer-heading">Other Links</h4>
					<?php
					wp_nav_menu(array(
						'theme_location' => 'footer2',
						'menu_class'     => 'list-unstyled footer-menu',
						'container'      => false,
					));
					?>
				</div>

			</div>
		</div>
	</div>

	<!-- Bottom Section -->
	<div class="footer-bottom">
		<div class="container-fluid">
			<div class="row align-items-center">

				<div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
					<p class="mb-0 text-white fw-bold">© WATF <?php echo date("Y"); ?></p>
				</div>

				<div class="col-md-6 text-center text-md-end">
					<div class="footer-social d-inline-flex gap-0">
						<?php if ($linkedin_link): ?>
							<a href="<?php echo esc_url($linkedin_link); ?>" target="_blank" class="social_icon text-white">
								<i class="fab fa-linkedin fa-lg"></i>
							</a>
						<?php endif; ?>
						<?php if ($facebook_link): ?>
							<a href="<?php echo esc_url($facebook_link); ?>" target="_blank" class="social_icon text-white">
								<i class="fa-brands fa-square-facebook fa-lg"></i>
							</a>
						<?php endif; ?>
						<?php if ($instagram_link): ?>
							<a href="<?php echo esc_url($instagram_link); ?>" target="_blank" class="social_icon text-white">
								<i class="fa-brands fa-square-instagram fa-xl"></i>
							</a>
						<?php endif; ?>
					</div>
				</div>

			</div>
		</div>
		<!-- scroll to top -->

		<button id="scrollToTopBtn" title="Go to top">
			<svg class="progress-ring" width="48" height="48">
				<circle class="progress-ring__circle" stroke="#ecececff" stroke-width="3" fill="transparent" r="20" cx="24" cy="24" />
			</svg>
			<i class="fas fa-arrow-up"></i>
		</button>
	</div>
</footer>
<div id="applyModal" class="apply-modal">
	<div class="apply-modal-content">
		<h2>Already Registered to Apply?</h2>
		<div class="apply-modal-actions">
			<a href="<?php echo site_url() ?>/scholarship-login/" class="btn yes">Yes, Login</a>
			<a href="<?php echo site_url() ?>/scolarship-registration/" class="btn no">No, Register</a>
		</div>
		<span class="apply-modal-close">&times;</span>
	</div>
</div>


<?php wp_footer(); ?>

<!-- <div class="modal fade" id="welcomeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content p-0">
      <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
      
      <div class="row g-0 p-4">
        <!-- Left Image -->
<!--         <div class="col-md-6">
          <?php
			$popup_image = get_field('popup_image', 'option');
			if ($popup_image): ?>
            <img src="<?php echo esc_url($popup_image['url']); ?>" alt="<?php echo esc_attr($popup_image['alt']); ?>" class="w-100 h-100 object-fit-cover">
          <?php endif; ?>
        </div> -->

<!-- Right Text -->
<!--         <div class="col-md-6 d-flex align-items-center">
          <div class="text-center p-4 w-100">
            <?php
			$popup_description = get_field('popup_description', 'option');
			if ($popup_description): ?>
              <h4 class="modal-desc fw-light mb-0"><?php echo wp_kses_post($popup_description); ?></h4>
            <?php endif; ?>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</div> -->

</body>

</html>


<script>
	jQuery(document).ready(function($) {

		// 		 const modal = new bootstrap.Modal(document.getElementById('welcomeModal'));
		//     const lastVisit = localStorage.getItem("lastVisit");
		//     const now = new Date().getTime();
		//     const sixHours = 6 * 60 * 60 * 1000;

		//     if (!lastVisit || now - lastVisit > sixHours) {
		//         modal.show();
		//         localStorage.setItem("lastVisit", now);
		//     }

		// 		const modal = new bootstrap.Modal(document.getElementById('welcomeModal'));
		//     modal.show();





		var btn = $('#scrollToTopBtn');
		var circle = document.querySelector('.progress-ring__circle');
		var radius = circle.r.baseVal.value;
		var circumference = 2 * Math.PI * radius;

		circle.style.strokeDasharray = `${circumference} ${circumference}`;
		circle.style.strokeDashoffset = circumference;

		function setProgress(percent) {
			const offset = circumference - (percent / 100) * circumference;
			circle.style.strokeDashoffset = offset;
		}

		// Smooth scroll progress update
		let ticking = false;

		function onScroll() {
			if (!ticking) {
				window.requestAnimationFrame(function() {
					var scrollTop = $(window).scrollTop();
					var docHeight = $(document).height() - $(window).height();
					var scrollPercent = (scrollTop / docHeight) * 100;

					setProgress(scrollPercent);

					if (scrollTop > 100) {
						btn.fadeIn();
					} else {
						btn.fadeOut();
					}

					ticking = false;
				});
				ticking = true;
			}
		}

		// Initial check
		onScroll();

		$(window).on('scroll', onScroll);

		btn.click(function() {
			$('html, body').animate({
				scrollTop: 0
			}, 500, 'swing');
			return false;
		});
	});
</script>

<script>
	jQuery(document).ready(function($) {
		if ($('.grantors-slider').length) {
			$('.grantors-slider').slick({
				slidesToShow: 5,
				slidesToScroll: 1,
				arrows: false,
				infinite: true,
				dots: false,
				autoplay: true,
				autoplaySpeed: 2000,
				speed: 800,
				pauseOnHover: true,
				responsive: [{
						breakpoint: 992,
						settings: {
							slidesToShow: 3
						}
					},
					{
						breakpoint: 768,
						settings: {
							slidesToShow: 2
						}
					},
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1
						}
					}
				]
			});
		}

		$('.history-slider').slick({
			slidesToShow: 1,
			slidesToScroll: 1,
			autoplay: true,
			autoplaySpeed: 3000,
			arrows: false,
			dots: true,
			responsive: [{
				breakpoint: 1024,
				settings: {
					arrows: true,
					dots: false
				}
			}]
		});


		$(".share-link").on("click", function(e) {
			e.preventDefault();

			const $btn = $(this);
			const url = $btn.data("link");

			// Copy to clipboard (with fallback)
			if (navigator.clipboard && window.isSecureContext) {
				navigator.clipboard.writeText(url).then(() => {
					animateCopy($btn);
				});
			} else {
				const tempInput = $("<input>");
				$("body").append(tempInput);
				tempInput.val(url).select();
				document.execCommand("copy");
				tempInput.remove();
				animateCopy($btn);
			}
		});

		function animateCopy($btn) {
			const originalHtml = $btn.html();

			// Change text with fade effect
			$btn.fadeOut(200, function() {
				$btn.html('Link copied!');
				$btn.fadeIn(200);
			});

			// Revert back after 2s
			setTimeout(() => {
				$btn.fadeOut(200, function() {
					$btn.html(originalHtml);
					$btn.fadeIn(200);
				});
			}, 5000);
		}
	});

	document.addEventListener('DOMContentLoaded', function() {
		const trigger = document.getElementById('applyModalTrigger');
		const modal = document.getElementById('applyModal');
		const closeBtn = document.querySelector('.apply-modal-close');

		if (trigger) {
			trigger.addEventListener('click', function(e) {
				e.preventDefault();
				modal.style.display = 'block';
			});
		}

		if (closeBtn) {
			closeBtn.addEventListener('click', function() {
				modal.style.display = 'none';
			});
		}

		window.addEventListener('click', function(e) {
			if (e.target === modal) {
				modal.style.display = 'none';
			}
		});
	});

	document.addEventListener('DOMContentLoaded', function() {
		const trigger = document.getElementById('applyModalTrigger');
		const modal = document.getElementById('applyModal');
		const closeBtn = document.querySelector('.apply-modal-close');

		if (trigger) {
			trigger.addEventListener('click', function(e) {
				e.preventDefault();
				modal.style.display = 'block';
			});
		}

		if (closeBtn) {
			closeBtn.addEventListener('click', function() {
				modal.style.display = 'none';
			});
		}

		window.addEventListener('click', function(e) {
			if (e.target === modal) {
				modal.style.display = 'none';
			}
		});
	});
</script>