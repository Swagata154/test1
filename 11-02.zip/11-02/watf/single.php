<?php
/**
 * The template for displaying single posts
 *
 * @package watf
 */

get_header();
?>

<main id="primary" class="site-main py-5 my-5 px-3">
	<div class="container" style="max-width: 1320px !important;">
		<div class="row">

			<!-- Main Content (Current Post Only) -->
			<div class="col-12 col-lg-8 col-xl-9">
	<?php
	if (have_posts()) :
		while (have_posts()) : the_post();

			$post_id = get_the_ID();

			// ===============================
			// ACF FIELDS
			// ===============================
			$link_field   = get_field('link_of_the_image', $post_id);
			$target_field = get_field('target', $post_id);

			$link_url    = '';
			$link_target = '_self';

			// Handle ACF Link field (array or URL)
			if (!empty($link_field)) {
				if (is_array($link_field) && isset($link_field['url'])) {
					$link_url    = $link_field['url'];
					$link_target = !empty($link_field['target']) ? $link_field['target'] : '_self';
				} else {
					$link_url = $link_field; // URL field
				}
			}

			// Override target if separate Target field exists
			if ($target_field === 'New Tab') {
				$link_target = '_blank';
			}
	?>
			<article id="post-<?php the_ID(); ?>" <?php post_class("mb-5"); ?>>

				<header class="mb-3">
					<h1 class="entry-title h3 fw-bold">
						<?php the_title(); ?>
					</h1>

					<div class="d-flex justify-content-between align-items-center flex-wrap">
						<!-- Left: Author & Date -->
						<p class="meta-desc mb-0">
							<?php echo esc_html(get_the_author()); ?>
							&nbsp;&nbsp; • &nbsp;&nbsp;
							<?php echo esc_html(get_the_date('m-d-Y \a\t h:i A T')); ?>
						</p>

						<!-- Right: Share button -->
						<div class="share-option">
							<a href="javascript:void(0);"
							   class="share-link"
							   data-link="<?php echo esc_url(get_permalink()); ?>"
							   data-title="<?php echo esc_attr(get_the_title()); ?>">
								<i class="fas fa-share-alt"></i> Share
							</a>
						</div>
					</div>

					<hr class="custom_hr">
				</header>

				<?php if (has_post_thumbnail()) : ?>
					<div class="post-thumbnail mb-3">

						<?php if (!empty($link_url)) : ?>
							<a href="<?php echo esc_url($link_url); ?>"
							   target="<?php echo esc_attr($link_target); ?>"
							   <?php if ($link_target === '_blank') echo 'rel="noopener noreferrer"'; ?>>

								<?php the_post_thumbnail('full', ['class' => 'img-fluid listing_img']); ?>

							</a>
						<?php else : ?>

							<?php the_post_thumbnail('full', ['class' => 'img-fluid listing_img']); ?>

						<?php endif; ?>

					</div>
				<?php endif; ?>

				<div class="entry-content">
					<?php the_content(); ?>
				</div>

			</article>

	<?php
		endwhile;
	endif;
	?>
</div>



			<!-- Sidebar (Related News) -->
			<div class="col-12 col-lg-4 col-xl-3">
				<aside class="related-news ps-lg-4">
					<h5 class="news-heading mb-3">Related News</h5>
					<?php
					$related = new WP_Query([
						'post_type'      => 'post',
						'posts_per_page' => -1,
						'post__not_in'   => [get_the_ID()], // exclude current post
					]);
					if ($related->have_posts()) :
						while ($related->have_posts()) : $related->the_post();
					?>
							<div class="related-item mb-4">
								<h6 class="mb-1">
									<a href="<?php the_permalink(); ?>" class="releated_heading">
										<?php the_title(); ?>
									</a>
								</h6>
								<p class="related_excerpt">
									<?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?>
								</p>
								<p class="related_time mb-1">
									<?php echo get_the_date('m-d-Y \a\t h:i A T'); ?>
								</p>
							</div>
							<hr class="custom_hr">
					<?php endwhile;
						wp_reset_postdata();
					endif; ?>
				</aside>
			</div>

		</div>
	</div>
</main>
<script>
jQuery(document).ready(function ($) {

	$(document).on("click", ".share-link", function (e) {
		e.preventDefault();

		const $btn = $(this);
		const url = $btn.data("link");

		if (!url) return;

		// Copy to clipboard
		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(url).then(function () {
				animateCopy($btn);
			});
		} else {
			const tempInput = $("<input>");
			$("body").append(tempInput);
			tempInput.val(url).select();
			document.execCommand("copy");
			tempInput.remove();
			animateCopy($btn);
		}
	});

	function animateCopy($btn) {
		const originalHtml = $btn.html();

		$btn.stop(true, true).fadeOut(200, function () {
			$btn.html("Link copied!").fadeIn(200);
		});

		setTimeout(function () {
			$btn.stop(true, true).fadeOut(200, function () {
				$btn.html(originalHtml).fadeIn(200);
			});
		}, 2000);
	}

});
</script>

<?php
get_footer();
?>
