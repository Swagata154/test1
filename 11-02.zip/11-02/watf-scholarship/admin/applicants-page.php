<?php

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_init', 'watf_scholarship_handle_admin_actions');

function watf_scholarship_handle_admin_actions()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (empty($_GET['page']) || $_GET['page'] !== 'watf-scholarship-applicants') {
        return;
    }

    $action = sanitize_text_field($_GET['action'] ?? '');
    $id     = isset($_GET['id']) ? absint($_GET['id']) : 0;

    if (!$action || !$id) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'watf_applicants';

    if ($action === 'delete' && $id) {

        check_admin_referer('watf_delete_applicant_' . $id);

        // Get applicant record first
        $applicant = $wpdb->get_row(
            $wpdb->prepare("SELECT user_id FROM $table_name WHERE id = %d", $id)
        );

        if ($applicant) {

            $user_id = (int) $applicant->user_id;

            // Delete WordPress user
            require_once ABSPATH . 'wp-admin/includes/user.php';
            wp_delete_user($user_id);

            // Delete from custom table
            $wpdb->delete($table_name, ['id' => $id], ['%d']);
        }

        wp_safe_redirect(admin_url('admin.php?page=watf-scholarship-applicants&deleted=1'));
        exit;
    }

    if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST' && $id) {

        check_admin_referer('watf_update_applicant_' . $id);

        $first  = sanitize_text_field($_POST['first_name'] ?? '');
        $middle = sanitize_text_field($_POST['middle_initial'] ?? '');
        $last   = sanitize_text_field($_POST['last_name'] ?? '');

        if ($first && $last) {

            // Get existing applicant
            $applicant = $wpdb->get_row(
                $wpdb->prepare("SELECT user_id FROM $table_name WHERE id = %d", $id)
            );

            if ($applicant) {

                $user_id = (int) $applicant->user_id;

                // 1. Update Custom Table
                $wpdb->update(
                    $table_name,
                    [
                        'first_name'     => $first,
                        'middle_initial' => $middle,
                        'last_name'      => $last
                    ],
                    ['id' => $id],
                    ['%s', '%s', '%s', '%s', '%s'],
                    ['%d']
                );

                // 2. Update WordPress User
                wp_update_user([
                    'ID'           => $user_id,
                    'display_name' => trim("$first $middle $last")
                ]);
                update_user_meta($user_id, 'first_name', $first);
                update_user_meta($user_id, 'middle_initial', $middle);
                update_user_meta($user_id, 'last_name', $last);
            }
        }

        wp_safe_redirect(admin_url('admin.php?page=watf-scholarship-applicants&updated=1'));
        exit;
    }
}

function watf_scholarship_render_applicants_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'watf_applicants';

    $action = sanitize_text_field($_GET['action'] ?? '');
    $id     = isset($_GET['id']) ? absint($_GET['id']) : 0;

?>

    <div class="wrap">
        <h1><?php esc_html_e('Scholarship Applicants', 'watf-scholarship'); ?></h1>

        <?php
        // EDIT VIEW
        if ($action === 'edit' && $id) :
            $applicant = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id)
            );

            if ($applicant) :
                $form_action = admin_url(
                    'admin.php?page=watf-scholarship-applicants&action=update&id=' . $id
                );
        ?>

                <form method="post" action="<?php echo esc_url($form_action); ?>">
                    <?php wp_nonce_field('watf_update_applicant_' . $id); ?>

                    <table class="form-table">
                        <tbody>
                            <tr>
                                <th><label>First Name</label></th>
                                <td>
                                    <input type="text" name="first_name"
                                        value="<?php echo esc_attr($applicant->first_name); ?>"
                                        class="regular-text">
                                </td>
                            </tr>

                            <tr>
                                <th><label>Middle Initial</label></th>
                                <td>
                                    <input type="text" name="middle_initial"
                                        value="<?php echo esc_attr($applicant->middle_initial); ?>"
                                        class="regular-text">
                                </td>
                            </tr>

                            <tr>
                                <th><label>Last Name</label></th>
                                <td>
                                    <input type="text" name="last_name"
                                        value="<?php echo esc_attr($applicant->last_name); ?>"
                                        class="regular-text">
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <?php submit_button('Update Applicant'); ?>
                </form>

        <?php
                return;
            endif;
        endif;
        ?>

        <?php
        // LIST VIEW
        $per_page = 10;

        $current_page = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;

        // Total count
        $total_items = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

        // Fetch limited results
        $applicants = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name ORDER BY created_at DESC LIMIT %d OFFSET %d",
                $per_page,
                $offset
            )
        );

        // Total pages
        $total_pages = ceil($total_items / $per_page);
        ?>

        <table class="widefat fixed striped">
            <thead>
                <tr>
                    <th>SL No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>

                <?php if ($applicants) : ?>
                    <?php
                    $sl = 1;
                    foreach ($applicants as $applicant) :

                        $edit_url = admin_url(
                            'admin.php?page=watf-scholarship-applicants&action=edit&id=' . (int) $applicant->id
                        );

                        $delete_url = wp_nonce_url(
                            admin_url(
                                'admin.php?page=watf-scholarship-applicants&action=delete&id=' . (int) $applicant->id
                            ),
                            'watf_delete_applicant_' . (int) $applicant->id
                        );

                        $name = trim(
                            $applicant->first_name . ' ' .
                                $applicant->middle_initial . ' ' .
                                $applicant->last_name
                        );
                    ?>

                        <tr>
                            <td><?php echo $sl++; ?></td>
                            <td><?php echo esc_html($name); ?></td>
                            <td><?php echo esc_html($applicant->email); ?></td>
                            <td><?php echo esc_html($applicant->phone); ?></td>
                            <td><?php echo esc_html($applicant->created_at); ?></td>
                            <td>
                                <a class="button button-secondary watf-btn-edit" href="<?php echo esc_url($edit_url); ?>">Edit</a> |
                                <a class="button button-link-delete watf-btn-delete" href="<?php echo esc_url($delete_url); ?>"
                                    onclick="return confirm('Delete this applicant?')">
                                    Delete
                                </a>
                            </td>
                        </tr>

                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: red;">No applicants found.</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
        <?php if ($total_pages > 1) : ?>

            <div class="tablenav bottom">
                <div class="tablenav-pages" style="margin-top:15px;">

                    <?php
                    $base_url = remove_query_arg('paged');

                    $prev_page = $current_page - 1;
                    $next_page = $current_page + 1;
                    ?>

                    <?php if ($current_page > 1) : ?>
                        <a class="button"
                            href="<?php echo esc_url(add_query_arg('paged', $prev_page, $base_url)); ?>">
                            ←
                        </a>
                    <?php else : ?>
                        <span class="button disabled">←</span>
                    <?php endif; ?>


                    <span style="margin: 0 10px;">
                        Page <?php echo esc_html($current_page); ?>
                        of <?php echo esc_html($total_pages); ?>
                    </span>


                    <?php if ($current_page < $total_pages) : ?>
                        <a class="button"
                            href="<?php echo esc_url(add_query_arg('paged', $next_page, $base_url)); ?>">
                            →
                        </a>
                    <?php else : ?>
                        <span class="button disabled">→</span>
                    <?php endif; ?>

                </div>
            </div>
        <?php endif; ?>
    </div>
<?php
}
