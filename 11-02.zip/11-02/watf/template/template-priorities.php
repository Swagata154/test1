<?php
// Template Name: WATF Priorities Template

get_header();
?>

<main id="primary" class="site-main py-5">
	<div class="container-fluid px-3 px-lg-5 py-md-5">
		<?php if (function_exists('yoast_breadcrumb')) : ?>
			<nav class="breadcrumb-wrapper" aria-label="Breadcrumb">
				<?php yoast_breadcrumb('<p id="breadcrumbs">Return to ', '</p>'); ?>
			</nav>
		<?php endif; ?>
		<?php
		while (have_posts()) :
			the_post();

			get_template_part('template-parts/content', 'page');


		endwhile; // End of the loop.
		?>
	</div>
</main>





<?php
get_footer();
?>