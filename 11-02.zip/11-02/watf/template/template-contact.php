<?php
// Template Name: Contact Template
get_header();
?>

<?php
/* Template Name: Contact Page */
get_header();
?>

<section class="contact-page px-3 py-5">
    <div class="container py-5" style="max-width: 1320px !important;">
        <div class="row g-5 align-items-start">

            <!-- Left Side: Contact Form -->
            <div class="col-lg-6">
                <h2 class="fw-bold mb-3">Let's Hear From You</h2>
                <p class="mb-4">
                    Thank you for taking the time to let us know what you think.
                    We appreciate your input.
                </p>

                <?php echo do_shortcode('[contact-form-7 id="1920bcb" title="Contact form 1"]'); ?>
                <!-- Replace with your Contact Form 7 shortcode -->
            </div>

            <!-- Right Side: Contact Info -->
            <div class="col-lg-6">
                <h2 class="fw-bold mb-3">Contact Us</h2>
                <p class="mb-1 contact_details">
                    <strong>Phone:</strong>
                    <a href="tel:<?php echo preg_replace('/\D+/', '', get_field('phone_number', 'option')); ?>">
                        <?php the_field('phone_number', 'option'); ?>
                    </a>
                </p>

                <p class="mb-3 contact_details">
                    <strong>Fax:</strong>
                    <a href="tel:<?php echo preg_replace('/\D+/', '', get_field('fax_number', 'option')); ?>">
                        <?php the_field('fax_number', 'option'); ?>
                    </a>
                </p>


                <p>
                    <a href="mailto:<?php the_field('keith_mail-id', 'option'); ?>" class="team_member">
                        Keith W. Meurlin
                    </a>, <b><em><?php the_field('keith_position', 'option'); ?></em></b>
                </p>
                <p>
                    <a href="mailto:<?php the_field('mark_mail-id', 'option'); ?>" class="team_member">
                        Mark Treadaway
                    </a>, <b><em><?php the_field('mark_position', 'option'); ?></em></b>
                </p>
                <p>
                    <a href="mailto:<?php the_field('lisa_mail-id', 'option'); ?>" class="team_member">
                        Lisa Merhaut
                    </a>, <b><em><?php the_field('lisa_position', 'option'); ?></em></b>
                </p>

                <?php if ($poster = get_field('contact_poster', 'option')): ?>
                    <div class="mt-4">
                        <img src="<?php echo esc_url($poster['url']); ?>" alt="Contact Poster" class="img-fluid rounded shadow">
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>




<?php
get_footer();
?>