<?php
// Template Name: Home Template
get_header();
?>

<?php
// Get group
$home_banner = get_field('home_banner');

// Sub fields
$banner_bg   = $home_banner['banner_background'] ?? '';
$banner_title = $home_banner['banner_title'] ?? '';
$banner_desc  = $home_banner['banner_description'] ?? '';

$linkedin_link  = get_field('linkedin_link', 'option');
$facebook_link  = get_field('facebook_link', 'option');
$instagram_link = get_field('instagram_link', 'option');
?>

<section class="home-banner position-relative"
    style="background: url('<?php echo esc_url($banner_bg['url'] ?? ''); ?>') center center / cover no-repeat; ">

    <div class="container-fluid p-5 h-100">
        <div class="row banner-row d-flex align-items-end h-100">

            <!-- Left Column -->
            <div class="col-lg-8 col-md-10 d-flex flex-column justify-content-end text-white mb-2 mb-lg-5">
                <?php if ($banner_title): ?>
                    <h1 class="banner_heading fw-bold mb-3">
                        <?php echo esc_html($banner_title); ?>
                    </h1>
                    <div class="white-banner-divider mb-3"></div>
                <?php endif; ?>

                <?php if ($banner_desc): ?>
                    <div class="lead mb-0">
                        <?php echo $banner_desc; ?>
                    </div>
                <?php endif; ?>

            </div>

            <!-- Social Links (Right Side) -->
            <div class="col-lg-4 col-md-2 d-flex justify-content-md-end justify-content-start mt-4 mt-md-0">
                <div class="banner-social d-inline-flex gap-3">
                    <?php if ($linkedin_link): ?>
                        <a href="<?php echo esc_url($linkedin_link); ?>" target="_blank" class="text-white">
                            <i class="fab fa-linkedin fa-xl"></i>
                        </a>
                    <?php endif; ?>
                    <?php if ($facebook_link): ?>
                        <a href="<?php echo esc_url($facebook_link); ?>" target="_blank" class="text-white">
                            <i class="fa-brands fa-square-facebook fa-xl"></i>
                        </a>
                    <?php endif; ?>
                    <?php if ($instagram_link): ?>
                        <a href="<?php echo esc_url($instagram_link); ?>" target="_blank" class="text-white">
                            <i class="fa-brands fa-square-instagram fa-xl"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- About our mission section -->

<?php
// Get group
$our_mission = get_field('our_mission_section');

// Sub fields
$title   = $our_mission['title'] ?? '';
$subheading = $our_mission['subheading'] ?? '';
$desc  = $our_mission['description'] ?? '';

?>

<section class="our_mission">
    <div class="container-fluid">
        <div class="row inner-section">
            <div class="col-12">
                <h4 class="mission_title"><?= $title; ?></h4>
                <h1 class="mission_subheading my-4"><?= $subheading; ?></h1>
                <div class="mission_desc">
                    <?= $desc; ?>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- WATF Priorities -->

<section class="watf-section p-5 px-3 px-lg-4">
    <div class="container-fluid py-md-5">
        <div class="row g-5 align-items-streach">

            <!-- Left Images -->
            <div class="col-lg-6">
                <div class="row g-4 watf-images">
                    <?php if (have_rows('watf_priorities_section_image_gallery')): ?>
                        <?php
                        $i = 0;
                        while (have_rows('watf_priorities_section_image_gallery')): the_row();
                            $img = get_sub_field('priority_image');
                        ?>

                            <?php if ($i == 0): ?>
                                <div class="col-md-8">
                                    <div class="watf-img-wrapper">
                                        <img src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" class="watf-img">
                                    </div>
                                </div>
                            <?php elseif ($i == 1): ?>
                                <div class="col-md-4">
                                    <div class="watf-img-wrapper">
                                        <img src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" class="watf-img">
                                    </div>
                                </div>
                            <?php elseif ($i == 2): ?>
                                <div class="col-md-4">
                                    <div class="watf-img-wrapper">
                                        <img src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" class="watf-img">
                                    </div>
                                </div>
                            <?php elseif ($i == 3): ?>
                                <div class="col-md-8">
                                    <div class="watf-img-wrapper">
                                        <img src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" class="watf-img">
                                    </div>
                                </div>
                            <?php endif; ?>

                        <?php $i++;
                        endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>



            <!-- Right Priorities -->
            <div class="col-lg-6 pe-5">
                <h2 class="watf-heading mb-3">WATF Priorities</h2>
                <div class="black-banner-divider mb-5"></div>

                <div class="row">
                    <?php if (have_rows('watf_priorities_section_priorities')): ?>
                        <?php while (have_rows('watf_priorities_section_priorities')): the_row(); ?>
                            <div class="col-md-6 mb-4">
                                <h6 class="watf-tagline mb-0 text-uppercase"><?php the_sub_field('priority_tagline'); ?></h6>
                                <h5 class="watf-title mb-1"><?php the_sub_field('priority_title'); ?></h5>
                                <div class="watf-desc mb-1"><?php the_sub_field('priority_description'); ?></div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    <?php
                    $watf_priorities = get_field('watf_priorities_section');
                    if ($watf_priorities) : ?>
                        <a href="<?= site_url('/watf-priorities'); ?>" class="button1">
                            <?= esc_html($watf_priorities['button_text']); ?>
                        </a>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
</section>

<!-- Upcoming Events -->
<section class="home-event-section py-5 px-3" style="background:#1a3c6b;
    min-height:350px;
    display:flex;
    align-items:center;">
    <div class="container-fluid py-lg-5 px-3 px-lg-5">
        <h2 class="mission_subheading text-light mb-5"><?= get_field('events_heading'); ?></h2>
        <div class="white-banner-divider mb-3"></div>

        <div class="row pt-5">
            <?php
            // Array of event page IDs
            $event_pages = [445, 458];

            foreach ($event_pages as $event_id) :
                $event = get_post($event_id);
                if ($event) :
                    $event_link = get_permalink($event_id);
                    ?>
                    <div class="col-lg-6 mb-4">
						<div class="card h-100 shadow-sm d-flex flex-column flex-md-row">
							<!-- Featured Image -->
							<?php if (has_post_thumbnail($event_id)) : ?>
								<a href="<?= esc_url($event_link); ?>" class="event-img flex-shrink-0">
									<?= get_the_post_thumbnail($event_id, 'large', ['class' => 'img-fluid']); ?>
								</a>
							<?php endif; ?>

							<!-- Right side content -->
							<div class="card-body d-flex flex-column">
								<h3 class="card-title mb-3"><?= esc_html($event->post_title); ?></h3>
								<p class="card-text">
									<?= get_the_excerpt($event_id); ?>
								</p>
								<a href="<?= esc_url($event_link); ?>" class="button1 mt-auto align-self-start">Read More</a>
							</div>
						</div>
					</div>



                <?php endif;
            endforeach;
            ?>
        </div>
    </div>
</section>





<!-- Latest News Section -->

<section class="latest-news py-5 my-md-5">
  <div class="container-fluid px-3 px-lg-5">
    <h2 class="mission_subheading mb-4"><?= get_field('latest_news_heading'); ?></h2>
    <div class="white-banner-divider mb-5 bg-dark"></div>

    <div class="row g-5">
      <?php
      $args = array(
        'post_type'      => 'post',
        'posts_per_page' => 4,
        'order'          => 'DESC'
      );

      $query = new WP_Query($args);
      $i = 0;

      if ($query->have_posts()) :
        while ($query->have_posts()) : $query->the_post();

          $post_id = get_the_ID();

          $link_field   = get_field('link_of_the_image', $post_id);
          $target_field = get_field('target', $post_id);

          $link_url    = '';
          $link_target = '_self';

          if (!empty($link_field)) {
            if (is_array($link_field) && isset($link_field['url'])) {
              $link_url    = $link_field['url'];
              $link_target = !empty($link_field['target']) ? $link_field['target'] : '_self';
            } else {
              $link_url = $link_field;
            }
          }

          if ($target_field === 'New Tab') {
            $link_target = '_blank';
          }

          if ($i == 0) :
      ?>

          <!-- FIRST LARGE POST -->
          <div class="col-lg-5">
            <div class="news-card large h-100">

              <?php if (has_post_thumbnail()) : ?>
                <div class="news-thumb">
                  <?php if (!empty($link_url)) : ?>
                    <a href="<?php echo esc_url($link_url); ?>"
                       target="<?php echo esc_attr($link_target); ?>"
                       <?php if ($link_target === '_blank') echo 'rel="noopener noreferrer"'; ?>>
                      <?php the_post_thumbnail('full', ['class' => 'img-fluid w-100']); ?>
                    </a>
                  <?php else : ?>
                    <?php the_post_thumbnail('full', ['class' => 'img-fluid w-100']); ?>
                  <?php endif; ?>
                </div>
              <?php endif; ?>

              <div class="news-content mt-3">
                <p class="news-date"><?php echo get_the_date('F d, Y'); ?></p>
                <h3 class="news-title"><?php the_title(); ?></h3>
                <p class="news-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 25, '...'); ?></p>
                <a href="<?php the_permalink(); ?>" class="read-more">
                  Continue Reading <i class="fa-solid fa-arrow-right mx-1"></i>
                </a>
              </div>

            </div>
          </div>

      <?php else : ?>

          <!-- RIGHT COLUMN POSTS -->
          <?php if ($i == 1) : ?>
            <div class="col-lg-7">
              <div class="row g-4">
          <?php endif; ?>

          <div class="col-12">
            <div class="news-card news-card-right d-flex flex-column flex-md-row align-items-start">

              <?php if (has_post_thumbnail()) : ?>
  <div class="news-thumb-right me-3 flex-shrink-0">
    <?php if (!empty($link_url)) : ?>
      <a href="<?php echo esc_url($link_url); ?>"
         target="<?php echo esc_attr($link_target); ?>"
         <?php if ($link_target === '_blank') echo 'rel="noopener noreferrer"'; ?>>
        <?php the_post_thumbnail('full', ['class' => 'img-fluid']); ?>
      </a>
    <?php else : ?>
      <?php the_post_thumbnail('full', ['class' => 'img-fluid']); ?>
    <?php endif; ?>
  </div>
<?php endif; ?>


              <div class="news-content">
                <p class="news-date"><?php echo get_the_date('F d, Y'); ?></p>
                <h4 class="news-title"><?php the_title(); ?></h4>
                <p class="news-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 18, '...'); ?></p>
                <a href="<?php the_permalink(); ?>" class="read-more">
                  Continue Reading <i class="fa-solid fa-arrow-right mx-1"></i>
                </a>
              </div>

            </div>
          </div>

          <?php if ($i == 3) : ?>
              </div>
            </div>
          <?php endif; ?>

      <?php
          endif;
          $i++;
        endwhile;
        wp_reset_postdata();
      endif;
      ?>
    </div>
  </div>
</section>


<!-- History of WATF -->

<section class="history-watf py-5" style="background-color: #f0f2f5;">
    <?php $history_watf = get_field('history_watf');
    $title = $history_watf['heading'] ?? '';
    $desc = $history_watf['description'] ?? '';
    $btn_text = $history_watf['button_text'] ?? 'Read More';
    $right_image = $history_watf['right_side_image'] ?? '';
    ?>

    <div class="container-fluid px-md-5 px-3 py-md-5">
        <div class="row align-items-center">

            <!-- Left Content -->
            <div class="col-lg-6 mb-5">
                <div class="history-content pe-md-5">
                    <?php if (!empty($title)) : ?>
                        <h2 class="history-title mb-3"><?php echo $title; ?></h2>
                    <?php endif; ?>

                    <?php if (!empty($desc)) : ?>
                        <div class="history-desc mb-4 mb-md-5"><?php echo $desc; ?></div>
                    <?php endif; ?>

                    <?php if (!empty($btn_text)) : ?>
                        <a href="<?= site_url('/history-of-watf'); ?>" class="button1"><?php echo $btn_text; ?></a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right Image -->
            <div class="col-lg-6">
                <div class="history-image">
                    <?php if (!empty($right_image)) : ?>
                        <img src="<?php echo esc_url($right_image['url']); ?>" alt="<?php echo esc_attr($right_image['alt']); ?>" class="img-fluid">
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</section>


<!-- Grantors section -->
<section class="grantors-section py-5">
    <div class="container-fluid px-3 px-lg-5 py-md-5">
        <?php
        $grantors = get_field('grantors_section');
        if ($grantors):
            $heading = $grantors['heading'] ?? '';
        ?>

            <?php if ($heading): ?>
                <h2 class="mission_subheading mb-4"><?php echo esc_html($heading); ?></h2>
                <div class="white-banner-divider mb-5 bg-dark"></div>
            <?php endif; ?>

            <?php if (have_rows('grantors_section_logos_section')): ?>
                <?php
                // Collect all logos
                $logos = [];
                while (have_rows('grantors_section_logos_section')): the_row();
                    $logos[] = [
                        'logo'      => get_sub_field('logo'),
                        'logo_link' => get_sub_field('logo_link'),
                    ];
                endwhile;

                $count = count($logos);

                // If only 5 or less, repeat the array so Slick has more to work with
                if ($count <= 5) {
                    $logos = array_merge($logos, $logos); 
                }
                ?>
                <div class="grantors-slider">
                    <?php foreach ($logos as $item):
                        $logo = $item['logo'];
                        $logo_link = $item['logo_link'];
                        if ($logo): ?>
                            <div class="grantor-logo text-center">
                                <?php if ($logo_link): ?>
                                    <a href="<?php echo esc_url($logo_link); ?>" target="_blank" rel="noopener">
                                        <img src="<?php echo esc_url($logo['url']); ?>" alt="<?php echo esc_attr($logo['alt']); ?>" class="img-fluid" />
                                    </a>
                                <?php else: ?>
                                    <img src="<?php echo esc_url($logo['url']); ?>" alt="<?php echo esc_attr($logo['alt']); ?>" class="img-fluid" />
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>


        <?php endif; ?>
    </div>
</section>











<?php
get_footer();
?>

<style>
	
	.card.d-flex.flex-column.flex-lg-row {
    flex-direction: column; /* mobile default */
}

@media (min-width: 992px) {
    .card.d-flex.flex-column.flex-lg-row {
        flex-direction: row; /* horizontal on desktop */
    }
}

.event-img {
    width: 100%; /* mobile full width */
}

.event-img img {
    width: 100%;
    height: 350px;
    object-fit: cover;
    border-radius: .25rem .25rem 0 0; /* mobile top corners */
}

@media (min-width: 768px) {
    .event-img {
        width: 40%; /* desktop: image 40%, content 60% */
    }

    .event-img img {
        height: 100%; /* fill the image container vertically */
        border-radius: .25rem 0 0 .25rem; /* rounded left corners */
    }
}

.card-body {
    flex: 1; /* let body take remaining space */
    padding: 1rem;
}
	
@media (max-width: 768px) {
	.event-img img {
		height: 250px !important;
		object-fit: contain !important;
	}
	}

	</style>

<script>
    jQuery(document).ready(function($) {
        if ($('.grantors-slider').length) {
            $('.grantors-slider').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                arrows: false,
                infinite: true,
                dots: false,
                autoplay: true,
                autoplaySpeed: 2000,
                speed: 800,
                pauseOnHover: true, 
                responsive: [{
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1
                        }
                    }
                ]
            });
        }
    });
</script>