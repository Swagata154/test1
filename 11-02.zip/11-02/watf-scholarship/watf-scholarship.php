<?php

/**
 * Plugin Name: WATF Scholarship
 * Description: Scholarship-related tools for the WATF site.
 * Version: 1.0.0
 * Author: WATF
 * Text Domain: watf-scholarship
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WATF_SCHOLARSHIP_VERSION', '1.0.0');
define('WATF_SCHOLARSHIP_PLUGIN_FILE', __FILE__);
define('WATF_SCHOLARSHIP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('WATF_SCHOLARSHIP_PLUGIN_URL', plugin_dir_url(__FILE__));

register_activation_hook(__FILE__, 'watf_scholarship_activate');
register_deactivation_hook(__FILE__, 'watf_scholarship_deactivate');
add_action('init', 'watf_scholarship_register_roles');
add_action('watf_scholarship_cleanup_tokens', 'watf_scholarship_cleanup_tokens');

function watf_scholarship_activate()
{
    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $table_name      = $wpdb->prefix . 'watf_applicants';
    $charset_collate = $wpdb->get_charset_collate();

    dbDelta("
        CREATE TABLE $table_name (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            first_name VARCHAR(100) NOT NULL,
            middle_initial VARCHAR(10) DEFAULT '',
            last_name VARCHAR(100) NOT NULL,
            phone VARCHAR(30) DEFAULT '',
            email VARCHAR(190) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_applicant_user (user_id),
            UNIQUE KEY uq_applicant_email (email)
        ) $charset_collate;
    ");

    // OTP / Auth Tokens Table
    $tokens_table = $wpdb->prefix . 'watf_auth_tokens';
    dbDelta("
        CREATE TABLE $tokens_table (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,

            token_hash VARCHAR(255) NOT NULL,
            token_type ENUM('login_otp','email_verification','password_reset') 
                NOT NULL DEFAULT 'login_otp',

            expires_at DATETIME NOT NULL,
            used TINYINT(1) DEFAULT 0,

            ip_address VARCHAR(45) DEFAULT NULL,
            user_agent TEXT DEFAULT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            KEY idx_user (user_id),
            KEY idx_expires (expires_at),
            KEY idx_type (token_type)
        ) $charset_collate;
    ");
    watf_scholarship_register_roles();

    if (!wp_next_scheduled('watf_scholarship_cleanup_tokens')) {
        wp_schedule_event(time(), 'hourly', 'watf_scholarship_cleanup_tokens');
    }
}

add_action('wp_enqueue_scripts', 'watf_enqueue_login_scripts');

function watf_enqueue_login_scripts()
{

    if (!is_page('scholarship-login')) {
        return;
    }

    wp_enqueue_script(
        'watf-login-js',
        WATF_SCHOLARSHIP_PLUGIN_URL . 'assets/js/watf-login.js',
        ['jquery'],
        WATF_SCHOLARSHIP_VERSION,
        true
    );

    wp_localize_script(
        'watf-login-js',
        'watf_ajax',
        [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('watf_scholarship_login'),
        ]
    );
}

function watf_scholarship_register_roles()
{
    remove_role('watf_applicant');
    add_role('scholarship_applicant', 'Scholarship Applicant', [
        'read' => true,
    ]);
}

function watf_scholarship_deactivate()
{
    $timestamp = wp_next_scheduled('watf_scholarship_cleanup_tokens');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'watf_scholarship_cleanup_tokens');
    }
}

function watf_scholarship_cleanup_tokens()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'watf_auth_tokens';
    $now        = current_time('mysql');

    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM $table_name WHERE used = 1 OR expires_at <= %s",
            $now
        )
    );
}

require_once WATF_SCHOLARSHIP_PLUGIN_PATH . 'frontend/frontend-registration.php';
require_once WATF_SCHOLARSHIP_PLUGIN_PATH . 'frontend/frontend-login.php';

if (is_admin()) {
    require_once WATF_SCHOLARSHIP_PLUGIN_PATH . 'admin/admin-menu.php';
}
