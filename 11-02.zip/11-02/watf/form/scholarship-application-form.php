<?php

/**
 * Scholarship application form shortcode.
 *
 * Usage: [scholarship_application_form]
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('watf_register_scholarship_application_form_shortcode')) {
    function watf_register_scholarship_application_form_shortcode()
    {
        add_shortcode('scholarship_application_form', 'watf_render_scholarship_application_form_shortcode');
    }
    add_action('init', 'watf_register_scholarship_application_form_shortcode');
}

if (!function_exists('watf_render_scholarship_application_form_shortcode')) {
    /**
     * Render the scholarship application form.
     *
     * @param array<string, mixed> $atts Shortcode attributes.
     * @return string
     */
    function watf_render_scholarship_application_form_shortcode($atts = [])
    {
        ob_start();
?>
        <div class="container px-3 pb-5">
            <form class="agm-registration-form scholarship-registration-form" method="post">
                <?php wp_nonce_field('watf_scholarship_register', 'watf_register_nonce'); ?>
                <input type="hidden" name="action" value="watf_scholarship_register">

                <div class="row g-4 align-items-end">

                    <div class="col-12 col-md-4">
                        <label class="form-label">First Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="first_name">
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">Middle Initial</label>
                        <input type="text" class="form-control" name="middle_initial" maxlength="1">
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">Last Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="last_name">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Are you a legal U.S. resident? <span class="text-danger">*</span></label>
                        <select name="resident" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="">Yes</option>
                            <option value="">No</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Date of Birth (MM/DD/YYYY) <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" name="date">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Phone <span class="text-danger">*</span></label>
                        <input type="tel" class="form-control" name="phone">
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" name="email">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Parent Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="parent_name">
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Street <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="street">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">City <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="city">
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">State <span class="text-danger">*</span></label>
                        <select name="resident" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="">Yes</option>
                            <option value="">No</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-3">
                        <label class="form-label">Zip <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="zip">
                    </div>
                    <span class="application_form_font">
                        Applicant must be an employee, volunteer, or dependent of one at a business within the Washington Dulles Airport
                        perimeter (inside the airport fence).
                    </span>

                    <div class="col-12 col-md-12">
                        <label class="form-label">Who is the employee/volunteer at Dulles Airport/perimeter? <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="vol">
                    </div>

                    <div class="col-12 col-md-12">
                        <label class="form-label">What is the employee’s/volunteer’s email address? <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="vol_email">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Relationship to Applicant <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="relation">
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Employer <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="employer">
                    </div>

                    <div class="col-12 col-md-5">
                        <label class="form-label">Position <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="position">
                    </div>

                    <div class="col-12 col-md-7">
                        <label class="form-label">Phone <span class="text-danger">*</span></label>
                        <input type="tel" class="form-control" name="phone">
                    </div>

                    <label class="form-label application_form_textarea_label">Please list any colleges, universities, and/or trade schools you have been accepted to attend. <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea></textarea>
                    </div>

                    <span class="application_form_font">
                        Please use the four sections below to provide details that showcase your leadership and commitment to the
                        community through extracurricular activities, employment, and/or volunteer work.
                    </span>

                    <label class="form-label application_form_textarea_label">1. List scholastic honors and scholarships. <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">2. List extra-curricular activities and/or employment history (include number of years and offices held). <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">3. List community activities (include number of years and offices held, if any). <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">4. Highlight instances where you took initiative, led a team, or made a meaningful impact through your leadership. <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">Describe your planned course of studies and educational goals. <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea></textarea>
                    </div>

                    <label class="form-label application_form_textarea_label">Describe how you will benefit from this scholarship opportunity <span class="text-danger">*</span></label>
                    <div class="mt-1 application_form_textarea">
                        <textarea></textarea>
                    </div>

                    <label for="" class="application_form_textarea_label">
                        Please upload a PDF of your transcripts, available from your school counseling office.
                        <label for="watf_file" class="watf-upload-btn float-end">
                            UPLOAD <span class="arrow">→</span>
                        </label>
                    </label>
                    <div class="watf-upload-wrapper col-12">
                        <div class="watf-upload-top w-100">
                            <input type="file" id="watf_file" class="w-100" name="watf_file" accept="application/pdf">
                        </div>
                    </div>


                    <span class="application_form_textarea_label col-10">
                        Please upload a letter of recommendation (as a PDF or Word file) from a teacher or school
                        administrator. If you are unable to upload this document due to sensitivity constraints, a
                        school representative may email the letter directly to cfdco@washingtonairports.com.
                    </span>
                    <label for="watf_file" class="watf-upload-btn float-end col-2">
                        UPLOAD <span class="arrow">→</span>
                    </label>

                    <div class="watf-upload-wrapper col-12">
                        <div class="watf-upload-top w-100">
                            <input type="file" id="watf_file" class="w-100" name="watf_file" accept="application/pdf">
                        </div>
                    </div>

                    <div class="col-12">
                        <label class="form-label application_form_textarea_label w-100">
                            Students’ personal and scholastic information remains confidential. However, the CFDCO promotes the
                            scholarship<br> applicants’ and winners’ names and photos if available. Please acknowledge that you and your parents
                            authorize the<br> CFDO to use such information.
                        </label>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">Student Release: <span class="text-danger">*</span></label>
                        <select name="resident" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="">Yes</option>
                            <option value="">No</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label">Parent Release: <span class="text-danger">*</span></label>
                        <select name="resident" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="">Yes</option>
                            <option value="">No</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-10">
                        <label class="form-label">Applicant acknowledges information provided is true and accurate: <span class="text-danger">*</span></label>
                        <select name="resident" id="" class="form-control">
                            <option value="">Select</option>
                            <option value="">Yes</option>
                            <option value="">No</option>
                        </select>
                    </div>

                    <div class="watf-agm-sponsorship-form container px-3">
                        <p class="text-danger fw-bold text-center mb-2">QUESTIONS?</p>
                    </div>

                    <label for="" class="fw-bold fst-italic text-center mt-0">
                        For questions or concerns, please email CFDCO@washingtonairports.com or call 703-572-8714.
                    </label>

                    <div class="col-12 text-center">
                        <button type="submit" class="btn btn-primary px-5 button1">
                            SUBMIT
                        </button>
                    </div>
                </div>
            </form>
        </div>
<?php
        return ob_get_clean();
    }
}
