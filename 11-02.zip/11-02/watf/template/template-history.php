<?php
// Template Name: History Template
get_header();
?>





<?php
get_footer();
?>